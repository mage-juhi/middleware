<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Laravel\Lumen\Console\Kernel as ConsoleKernel;
use Illuminate\Support\Facades\DB;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        'App\Console\Commands\Tester',
        'App\Console\Commands\MagentoProducts',
        'App\Console\Commands\MagentoFullProducts',
        'App\Console\Commands\SapProducts',
        'App\Console\Commands\SapSubrange',
        'App\Console\Commands\SapGetSwatchImages',
        'App\Console\Commands\BackupDB',
        'App\Console\Commands\MagentoAvailOnline',
        // 'App\Console\Commands\ProcessConfigurableCsv',
        // 'App\Console\Commands\ProcessConfigurableMapper',
        // 'App\Console\Commands\ShopifyProductCount',
        // 'App\Console\Commands\ShopifyProductIndex',
        // 'App\Console\Commands\ShopifyWebhookInit',
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // Run the Webhook Job Queue
        $stores = DB::table('stores')->where('is_active',1)->get();
        // $stores = [5];

        $schedule->command('queue:work --queue=full_sync_country --stop-when-empty --tries=1 --once')
                ->withoutOverlapping(1);
        $schedule->command('queue:work --queue=full_sync_magento --stop-when-empty --tries=1 --once')
                ->withoutOverlapping(1);

        $schedule->command('queue:work --queue=product_sync_to_magento --stop-when-empty --tries=1 --once')
                ->withoutOverlapping(1);

        $schedule->command('queue:work --queue=sync_to_magento --stop-when-empty --tries=1')
            ->withoutOverlapping();

        $schedule->command('queue:work --queue=product_sync_from_sap --stop-when-empty --tries=1 --timeout=600 --once')
            ->withoutOverlapping(2);


        // Start queue get SAP subrange API
        //should we use --once? double up the sync throughput for four stores 10 queue per mins
        // this should have 10 times queue -> its important
        $schedule->command('queue:work --queue=product_sync_from_sub_range --tries=2 --timeout=600 --once')
            ->cron('*/1 * * * *');

        $schedule->command('queue:work --queue=product_sync_from_sub_range --tries=2 --timeout=600 --once')
            ->cron('*/1 * * * *');

        $schedule->command('queue:work --queue=product_sync_from_sub_range --tries=2 --timeout=600 --once')
            ->cron('*/1 * * * *');

        $schedule->command('queue:work --queue=product_sync_from_sub_range --tries=2 --timeout=600 --once')
            ->cron('*/1 * * * *');

        $schedule->command('queue:work --queue=product_sync_from_sub_range --tries=2 --timeout=600 --once')
            ->cron('*/1 * * * *');

        $schedule->command('queue:work --queue=product_sync_from_sub_range --tries=2 --timeout=600 --once')
            ->cron('*/1 * * * *');

        $schedule->command('queue:work --queue=product_sync_from_sub_range --tries=2 --timeout=600 --once')
            ->cron('*/1 * * * *');

        $schedule->command('queue:work --queue=product_sync_from_sub_range --tries=2 --timeout=600 --once')
            ->cron('*/1 * * * *');

        $schedule->command('queue:work --queue=product_sync_from_sub_range --tries=2 --timeout=600 --once')
            ->cron('*/1 * * * *');

        $schedule->command('queue:work --queue=product_sync_from_sub_range --tries=2 --timeout=600 --once')
            ->cron('*/1 * * * *');

        // end queue get SAP subrange API

        foreach ($stores as $store) {
//            $schedule->command('app:sap:product ' . $store->id)
//            ->cron('0 1 * * *');
            //end scheduled daily syncs

            // Sync all product with status = 0 every 3 hour
            // cron for each store
            // $storeTime = $store->id;
            // $cron = "30 $storeTime * * *";
            // $schedule->command('app:magento:full-product '. $store->id)
            //    ->cron($cron)
            //    ->withoutOverlapping();

            // Sync all sub range with status = 0 every 2 hour
            $schedule->command('app:sap:subrange ' . $store->id)
                ->cron('0 */12 * * *');
        }

        foreach ($stores as $store) {
            switch ($store->id) {
                case '3':
                    //Sync all product with status = 0 every 3 hour
                    // 1. sync AU
                    $schedule->command('app:sap:product ' . $store->id)
                        ->timezone('Australia/Sydney')
                        ->dailyAt('00:30')
                        ->withoutOverlapping();

                    $schedule->command('app:magento:full-product ' . $store->id)
                        ->timezone('Australia/Sydney')
                        ->dailyAt('05:05')
                        ->withoutOverlapping();

                    $schedule->command('app:magento:availonline ' . $store->id)
                        ->timezone('Australia/Sydney')
                        ->dailyAt('1:00');
                    break;
                case '4':
                    // 2. sync NZ

                    $schedule->command('app:sap:product ' . $store->id)
                        ->timezone('Pacific/Auckland')
                        ->dailyAt('00:30')
                        ->withoutOverlapping();

                    $schedule->command('app:magento:full-product ' . $store->id)
                        ->timezone('Pacific/Auckland')
                        ->dailyAt('05:05')
                        ->withoutOverlapping();

                    $schedule->command('app:magento:availonline ' . $store->id)
                        ->timezone('Pacific/Auckland')
                        ->dailyAt('1:00');
                    break;
                case '5':
                    // 3. sync MY

                    $schedule->command('app:sap:product ' . $store->id)
                        ->timezone('Asia/Kuala_Lumpur')
                        ->dailyAt('00:30')
                        ->withoutOverlapping();

                    // $schedule->command('app:magento:full-product ' . $store->id)
                    //     ->timezone('Asia/Kuala_Lumpur')
                    //     ->dailyAt('06:05')
                    //     ->withoutOverlapping();

                    $schedule->command('app:magento:availonline ' . $store->id)
                        ->timezone('Asia/Kuala_Lumpur')
                        ->dailyAt('2:00');

                    break;
                case '6':
                    // 4. sync SG
                    $schedule->command('app:sap:product ' . $store->id)
                        ->timezone('Asia/Singapore')
                        ->dailyAt('00:30')
                        ->withoutOverlapping();

                    // $schedule->command('app:magento:full-product ' . $store->id)
                    //     ->timezone('Asia/Singapore')
                    //     ->dailyAt('05:05')
                    //     ->withoutOverlapping();

                    $schedule->command('app:magento:availonline ' . $store->id)
                        ->timezone('Asia/Singapore')
                        ->dailyAt('1:00');

                    break;
                case '8':
                    // 5. sync CA

                    $schedule->command('app:sap:product ' . $store->id)
                        ->timezone('Canada/Central')
                        ->dailyAt('00:30')
                        ->withoutOverlapping();

                    // $schedule->command('app:magento:full-product ' . $store->id)
                    //     ->timezone('Canada/Central')
                    //     ->dailyAt('05:05')
                    //     ->withoutOverlapping();

                    $schedule->command('app:magento:availonline ' . $store->id)
                        ->timezone('Canada/Central')
                        ->dailyAt('1:00');

                    break;
            }
        }

        //schedule daily backups of our database
        $schedule->command('app:backupsapdb')->daily();
    }
}
