<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CoreController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     *
     */
    public function showDashboard(Request $request)
    {
        $data = array('dashboard'=>'home');
        return view('master', $data);
    }
}
