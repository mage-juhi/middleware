<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateExteriorFinishLink extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('exterior_link', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('product_id')->unsigned();
            $table->integer('store_id')->unsigned();
            $table->integer('exterior_id')->unsigned();
        });
        Schema::create('finish_link', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('product_id')->unsigned();
            $table->integer('store_id')->unsigned();
            $table->integer('finish_id')->unsigned();
        });

        Schema::table('exterior_link', function (Blueprint $table) {
            $table->foreign('product_id')->references('id')->on('package_products');
            $table->foreign('exterior_id')->references('id')->on('exterior');
            $table->foreign('store_id')->references('id')->on('stores');
        });

        Schema::table('finish_link', function (Blueprint $table) {
            $table->foreign('product_id')->references('id')->on('package_products');
            $table->foreign('finish_id')->references('id')->on('finish');
            $table->foreign('store_id')->references('id')->on('stores');
        });

        Schema::table('exterior', function (Blueprint $table) {
            $table->dropForeign('exterior_product_id_foreign');
            $table->dropColumn('product_id');
        });

        Schema::table('finish', function (Blueprint $table) {
            $table->dropForeign('finish_product_id_foreign');
            $table->dropColumn('product_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('exterior_link');
        Schema::dropIfExists('finish_link');
    }
}
