<?php

namespace App\Sap\Client;

use App\Sap\Client;

class Products extends Client
{

    public function getItem($item_code=null){

        $item_data = $this->request('POST','king_get_item_prices/', ['test_mode' => 1]);

        $ItemData = json_decode($item_data['message'], true);

        return $ItemData;
    }


    public function getItemSubRange($sub_range=null){

        $item_data = $this->request('POST','king_get_item_prices/', ['where' => ["U_SubRangeCode"=>$sub_range]]);

        $ItemData = json_decode($item_data['message'], true);

        return $ItemData;
    }

    public function getAllItemSubRange() {

        $item_data = $this->request('POST','king_get_sub_range/');

        $AllItemData = json_decode($item_data['message'], true);

        return $AllItemData;
    }
}