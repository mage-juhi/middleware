<?php

namespace App\Http\Controllers;

use App\Sap\OptionShowFrontendMapping;
use App\Sap\ProductOptionTypeIndex;
use Illuminate\Support\Facades\Hash;

use Illuminate\Http\Request;

use App\Sap\Users;

use Auth;

use Image;

use App\Sap\Product\Material\Option;

use App\Sap\Product\Material\Option\Value;

use App\Jobs\ProcessSyncToMagento;
use App\Jobs\ProcessSyncFromSap;
use App\Jobs\ProcessProductLines;
use App\Sap\Product\Legs;
use App\Sap\Product\Cushioning;
use App\Sap\Product\Exterior;
use App\Sap\Product\Finish;
use App\Sap\Product\MaterialLink;
use App\Sap\Product\ExtraOption;
use App\Sap\ProductAttribute;
use App\Sap\ProductEntityValue;
use App\Sap\Product;
use App\Sap\ProductOptionIndex;
use Illuminate\Support\Facades\Validator;

use App\Sap\Product\ConfigurableMapping;
use App\Sap\Product\Finish\Color as FinishGroupColor;
use App\Sap\Product\Exterior\Color;
use App\Sap\OptionEntityValue;
use App\Sap\OptionTypeRequiredMapping;
use App\Sap\OptionalUpgrades;
use App\Sap\OptionalUpgradeType;

class SapHomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function showLogin()
    {
        // show the form
        return view('pages/login');
    }

    public function doLogin()
    {
        if(isset($_POST['username']) && isset($_POST['pwd'])){
            $user = Users::where('username', $_POST['username'])->first();
            //return $user->password;
            if(Hash::check($_POST['pwd'], $user->password)){
                session_start();
                $_SESSION['username'] = $_POST['username'];
                return redirect('dashboard');
                //return response()->json(['status' => 'success'],200);

            }else{
                return response()->json(['status' => 'fail'],401);
            }

        }

    }

    public function doLogout(){

        session_start();
        unset($_SESSION['username']);
        session_destroy();

        return redirect('/');
        exit;

    }

    public function removeProduct($id) {
        $product = Product::where('id', $id)->first();
        $product->delete();
        return redirect('/dashboard/');
    }


    public function uploadSwatchImages(Request $request){
        $idOption = $request['id'];
        $this->validate($request, [
            'group_custom_image' => 'image|mimes:jpeg,png,jpg|max:2048',
            'option_value_custom_image.*' => 'image|mimes:jpeg,png,jpg|max:2048',
            'des_value_custom_image.*' => 'image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $response = null;
        if($request['option_value_custom_image']){
            foreach($request['option_value_custom_image'] as $key => $val){
                if($request->hasFile('option_value_custom_image.'.$key)){

                    $image = $request->file('option_value_custom_image.'.$key)->getClientOriginalName();
                    $destination_path = "upload/images";
                    if($this->createPath($destination_path)){
                        if ($request->file('option_value_custom_image.'.$key)->move($destination_path, $image)) {
                            Value::where('id', $key)
                                ->update(['custom_image' => $image]);
                        } else {
                            return $this->responseRequestError('Cannot upload file');
                        }
                    }else{
                        if ($request->file('option_value_custom_image.'.$key)->move($destination_path, $image)) {
                            Value::where('id', $key)
                                ->update(['custom_image' => $image]);
                        } else {
                            return $this->responseRequestError('Cannot upload file');
                        }
                    }

                }else {
                    return $this->responseRequestError('File not found');
                }

            }

        }
        if($request['des_value_custom_image']){
            foreach($request['des_value_custom_image'] as $key => $val){
                if ($request->hasFile('des_value_custom_image.'.$key)) {
                    $image = $request->file('des_value_custom_image.'.$key)->getClientOriginalName();
                    $destination_path = "upload/images";
                    if($this->createPath($destination_path)){
                        if ($request->file('des_value_custom_image.'.$key)->move($destination_path, $image)) {
                            Value::where('id', $key)
                                ->update(['colour_description_image' => $image]);
                        } else {
                            return $this->responseRequestError('Cannot upload file');
                        }
                    } else {
                        if ($request->file('des_value_custom_image.'.$key)->move($destination_path, $image)) {
                            Value::where('id', $key)
                                ->update(['colour_description_image' => $image]);
                        } else {
                            return $this->responseRequestError('Cannot upload file');
                        }
                    }
                } else {
                    return $this->responseRequestError('File not found');
                }
            }
        }

        if($request['group_custom_image']) {
            if ($request->hasFile('group_custom_image')) {
                $image = $request->file('group_custom_image')->getClientOriginalName();
                $destination_path = "upload/images";
                if ($this->createPath($destination_path)) {
                    if ($request->file('group_custom_image')->move($destination_path, $image)) {
                        Option::where('id', $request['group_id'])
                            ->update(['custom_image' => $image]);
                    } else {
                        return $this->responseRequestError('Cannot upload file');
                    }
                } else {
                    if ($request->file('group_custom_image')->move($destination_path, $image)) {
                        Option::where('id', $request['group_id'])
                            ->update(['custom_image' => $image]);
                    } else {
                        return $this->responseRequestError('Cannot upload file');
                    }
                }

            } else {
                return $this->responseRequestError('File not found');
            }
        }
        if($request['cylindo_data']){
            foreach($request['cylindo_data'] as $key => $val){
                Value::where('id', $key)
                    ->update(['cylindo_data' => $val]);
            }
        }
        if($request['cylindo_data_optional']){
            foreach($request['cylindo_data_optional'] as $key => $val){
                Value::where('id', $key)
                    ->update(['cylindo_data_optional' => $val]);
            }
        }
        $arrSwatch = [];
        $option = Option::where('id', $idOption)->first();
        $valueOption = Value::where('group_option_id', $idOption)->orderBy('position')->get();
        if($option->custom_image != '') { 
            $arrSwatch['pswatch-editor-custom-image-'.$idOption] = $option->custom_image;
        }

        foreach($valueOption as $key => $val) {
            if($val->custom_image != '') {
                $arrSwatch['swatch-editor-custom-image-'.$val->id] = $val->custom_image;
            }
            if($val->colour_description_image != '') {
                $arrSwatch['swatch-description-colour-image-'.$val->id] = $val->colour_description_image;
            }  
        }
        return response()->json([
            'data'  => $arrSwatch
        ]);
    }

    public function aasort (&$array, $key) {
        $sorter=array();
        $ret=array();
        reset($array);
        foreach ($array as $ii => $va) {
            $sorter[$ii]=$va[$key];
        }

        asort($sorter);

        foreach ($sorter as $ii => $va) {
            $ret[$ii]=$array[$ii][0];
        }
        return $ret;
    }
    public function insertProductOptionIndex(&$sortName, $idProduct,$optionType) {
        ProductOptionIndex::where('product_id',$idProduct)->where('option_type',$optionType)->delete();
        $storeId = Product::where('id', $idProduct)->first()->store_id;
        $i = 1;
        foreach ($sortName as $key => $value) {
            ProductOptionIndex::insert(
                array(
                    'store_id' => $storeId,
                    'product_id' => $idProduct,
                    'option_id' => $key,
                    'option_type' => $optionType,
                    'position' => $i,
                )
                );
            $i++;
        }
    }

    public function optionTypeMappingSave(Request $request){
        try {
            $idProduct = $request->product_id;
            $optionType = $request->option_type;
            $isRequired = $request->is_required;
            $showOptionOnFrontEnd = $request->show_option_on_frontend;
            $storeId = Product::where('id', $idProduct)->first()->store_id;

            OptionTypeRequiredMapping::where('product_id',$idProduct)->where('option_type',$optionType)->delete();
            OptionTypeRequiredMapping::insert(
                array(
                    'store_id' => $storeId,
                    'product_id' => $idProduct,
                    'option_type' => $optionType,
                    'is_required' => $isRequired,
                )
            );

            $test = OptionShowFrontendMapping::updateOrCreate([
                'store_id' => $storeId,
                'product_id' => $idProduct,
                'option_type' => $optionType,
            ], ['is_show' => $showOptionOnFrontEnd ?? 0]);

            return redirect('/product-detail/view/id/'.$idProduct);
        }
        catch (Exception $e) {
            return response()->json([
                'message' =>  $e->getMessage()
            ]);;
        }
    }

    public function swatchSort(Request $request) {
        try {
            $idProduct = $request->product_id;
            $sortType = $request->sort;
            $optionType = $request->option_type;
            $product = Product::where('id',$idProduct)->first();
            $optionArray = [];
            switch ($optionType) {
                case 'legs':
                    $optionTypeValue = $optionType;
                    $legs = $product->legs;
                    $optionArray = $legs;
                    foreach ($optionArray as $key => $value) {
                        if ($value->is_active == 0) continue;
                        $sort[$value->id] = $value->legs_name;
                    }
                    break;
                case 'cushionings':
                    $optionTypeValue = $optionType;
                    $cushionings = $product->cushioning;
                    $optionArray = $cushionings;
                    foreach ($optionArray as $key => $value) {
                        if ($value->is_active == 0) continue;
                        $sort[$value->id] = $value->cushioning_name;
                    }
                case 'extraOptions':
                    $optionTypeValue = $request->option_type_value;
                    $extraOptions = $product->extraOptions;
                    $optionArray = $extraOptions;
                    foreach ($optionArray as $key => $value) {
                        if ($value->is_active == 0) continue;
                        if($value->type == $optionTypeValue) {
                            $sort[$value->id] = $value->name;
                        }
                    }
                    break;
                case 'exterior':
                    $optionTypeValue = $request->option_type_value;
                    $exteriorLinks = $product->exteriorLinks;
                    foreach ($exteriorLinks as $index => $exteriorLink) {
                        $exterior = $exteriorLink->exterior;
                        if ($exterior->is_active == 0) continue;
                        if ($exterior->exterior_name == $optionTypeValue) {
                            foreach($exterior->exteriorColor as $key => $exteriorsColor){
                                $sort[$exteriorsColor->id] = $exteriorsColor->colour_name;
                            }
                        }
                    }
                    break;
                case 'finish':
                    $optionTypeValue = $request->option_type_value;
                    $finishLinks = $product->finishLinks;
                    foreach ($finishLinks as $index => $finishLink) {
                        $finish = $finishLink->finish;
                        if ($finish->is_active == 0) continue;
                        if ($finish->finish_name == $optionTypeValue) {
                            foreach($finish->finishColor as $key => $finishColor){
                                $sort[$finishColor->id] = $finishColor->colour_name;
                            }
                        }
                    }
                    break;
                case 'cover':
                    $optionTypeValue = $request->option_type_value;
                    $optionTypeValueId = $request->option_type_value_id;
                    $materialLinks = $product->materialLinks;
                    foreach($materialLinks as $materialLink) {
                        $option = $materialLink->option;
                        if ($option->is_active == 0) continue;
                        if ($option->type_id == $optionTypeValueId ) {
                            $sort[$option->id] = $option->name;
                        }
                    }
                    if($sortType == 3) {
                        foreach($materialLinks as $materialLink) {
                            $option = $materialLink->option;
                            if ($option->is_active == 0) continue;
                            if ($option->type_id == $optionTypeValueId ) {
                                $swatchSortPrice[$materialLink->material_group_option_id] = $materialLink->sell_price;
                            }
                        }
                        asort($swatchSortPrice);
                        $this->insertProductOptionIndex($swatchSortPrice,$idProduct,$optionTypeValue);
                    } else if ($sortType == 4) {
                        foreach($materialLinks as $materialLink) {
                            $option = $materialLink->option;
                            if ($option->is_active == 0) continue;
                            if ($option->type_id == $optionTypeValueId ) {
                                $swatchSortPrice[$materialLink->material_group_option_id] = $materialLink->sell_price;
                            }
                        }
                        arsort($swatchSortPrice);
                        $this->insertProductOptionIndex($swatchSortPrice,$idProduct,$optionTypeValue);
                    } else if ($sortType == 5) {
                        foreach($materialLinks as $materialLink) {
                            $option = $materialLink->option;
                            if ($option->is_active == 0) continue;
                            if ($option->type_id == $optionTypeValueId ) {
                                $code = $materialLink->code;
                                $arrCode = explode(" ",$code);
                                $swatchSortCode[$materialLink->material_group_option_id] = [$materialLink->code,end($arrCode)];
                            }
                        }
                        $resultCode = $this->aasort($swatchSortCode, '1');
                        $this->insertProductOptionIndex($resultCode, $idProduct, $optionTypeValue);
                    }
                    break;
            }
            if($optionType == 'legs' || $optionType == 'cushionings') {
                $optionTypeValue = $optionType;
            }
            switch ($sortType) {
                case '1':
                    asort($sort);
                    $this->insertProductOptionIndex($sort,$idProduct,$optionTypeValue);
                    break;
                case '2':
                    arsort($sort);
                    $this->insertProductOptionIndex($sort,$idProduct,$optionTypeValue);
                    break;
            }
            return redirect('/product-detail/view/id/'.$idProduct.'?optionTypeValue='.$optionTypeValue.'&sort='.$sortType.'&optionType='.$optionType);
        }
        catch (Exception $e) {
            return response()->json([
                'message' =>  $e->getMessage()
            ]);;
        }
    }

    public function updateProductOptionType(Request $request){
        $idProduct = $request->product_id;
        $sortedIDs = json_decode($request->sortedIDs);
        try {
            ProductOptionTypeIndex::where('product_id',$idProduct)->delete();
            $storeId = Product::where('id', $idProduct)->first()->store_id;
            foreach ($sortedIDs as $key => $value) {
                ProductOptionTypeIndex::insert(
                    array(
                        'store_id' => $storeId,
                        'product_id' => $idProduct,
                        'option_type' => $value,
                        'position' => $key+1,
                    )
                );
            }


        }catch (Exception $e) {
            return response()->json([
                'message' =>  $e->getMessage()
            ]);;
        }

    }

    //update swatch sort index
    public function updateSwatchSortIndex(Request $request){
        $groupOptionId = $request->groupOptionId;
        $sortedItemIds = json_decode($request->sortedItemIds);
        try {
            foreach ($sortedItemIds as $key => $value) {
                if($value == "") {
                    continue;
                }
                Value::where('group_option_id', $groupOptionId)->where('id', $value)
                                    ->update(['position' => $key+1]);
            }
        }catch (Exception $e) {
            return response()->json([
                'message' =>  $e->getMessage()
            ]);;
        }

    }

    public function updateSwatchParentSortIndex(Request $request) {
        $sortedSwatchIds = json_decode($request->sortedSwatchIds);
        try {
            foreach ($sortedSwatchIds as $key => $value) {
                if($value == "") {
                    continue;
                }
                Option::where('id', $value)->update(['position' => $key+1]);
            }
        }catch (Exception $e) {
            return response()->json([
                'message' =>  $e->getMessage()
            ]);;
        }
    }

    public function sorterSwatchOptions(Request $request) {
        $groudOptionId = $request->groudOptionId;
        $typeSort = $request->typeSort;
        $groudOption = value::where('group_option_id',$groudOptionId)->get();
        foreach ($groudOption as $key => $value) {
            $sort[$value->id] = $value->colour_name;
        }

        switch ($typeSort) {
            case '1':
                asort($sort);
                $i=1;
                foreach ($sort as $key => $value) {
                    if($value == "") {
                        continue;
                    }
                    Value::where('group_option_id', $groudOptionId)->where('colour_name', $value)
                                        ->update(['position' => $i]);
                    $i++;
                }
                break;
            case '2':
                arsort($sort);
                $i=1;
                foreach ($sort as $key => $value) {
                    if($value == "") {
                        continue;
                    }
                    Value::where('group_option_id', $groudOptionId)->where('colour_name', $value)
                                        ->update(['position' => $i]);
                    $i++;
                }
                break;
        }
        return response()->json([
            'success' => 'Record has been updated successfully!'
        ]);
    }

    //update product option index
    public function updateProductOptionIndex(Request $request){
        $idProduct = $request->product_id;
        $sortedIDs = json_decode($request->sortedIDs);
        $optionType = $request->optionType;
        try {
            ProductOptionIndex::where('product_id',$idProduct)->where('option_type',$optionType)->delete();
            $storeId = Product::where('id', $idProduct)->first()->store_id;
            foreach ($sortedIDs as $key => $value) {
                ProductOptionIndex::insert(
                    array(
                        'store_id' => $storeId,
                        'product_id' => $idProduct,
                        'option_id' => $value,
                        'option_type' => $optionType,
                        'position' => $key+1,
                    )
                    );
            }
        }catch (Exception $e) {
            return response()->json([
                'message' =>  $e->getMessage()
            ]);;
        }

    }

    public function updateEditOption(Request $request) {
        $idProduct = $request->id;
        $type = $request->type;
        $name = $request->name;
        $des = $request->des;
        $entity_id = $request->entity_id;
        $e_field = $request->entity_field;
        $cylindoData = $request->cylindoData;
        $cylindoType = $request->cylindoType;
        $cylindoDataOptional = $request->cylindoDataOptional;
        $cylindoTypeOptional = $request->cylindoTypeOptional;
        $this->validate($request, [
            'custom_image' => 'image|mimes:jpeg,png,jpg|max:2048'
        ]);
        try {
            if($request['custom_image']){
	            if ($request->hasFile('custom_image')) {
	                $image = $request->file('custom_image')->getClientOriginalName();
	                $destination_path = "upload/images/".$type;
                    $this->createPath($destination_path);
                    if(!$request->file('custom_image')->move($destination_path, $image)){
                        return $this->responseRequestError('Cannot upload file');
                    }
	            }else {
	                return $this->responseRequestError('File not found');
	            }
	        }
            switch ($type) {
                case 'finish':
                    $templateTable = "";
                    $templateImage = "";
                    $entity_table = "finish_group_color";
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $idProduct, 'entity_field' => 'finish_colour_name', 'product_id' => $entity_id],
                        ['value' => $name]
                    );
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $idProduct, 'entity_field' => 'cylindo_data', 'product_id' => $entity_id],
                        ['value' => $cylindoData]
                    );
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $idProduct, 'entity_field' => 'cylindo_type', 'product_id' => $entity_id],
                        ['value' => $cylindoType]
                    );
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $idProduct, 'entity_field' => 'cylindo_type_optional', 'product_id' => $entity_id],
                        ['value' => $cylindoTypeOptional]
                    );
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $idProduct, 'entity_field' => 'cylindo_data_optional', 'product_id' => $entity_id],
                        ['value' => $cylindoDataOptional]
                    );
                    $finish = FinishGroupColor::where('id', $idProduct)->get()->first();
                    $name = OptionEntityValue::getValue($finish, 'finish_colour_name', $entity_id);
                    $html = "";
                    $image = $finish->custom_image;
                    if($finish->custom_image != ""){
                        $templateImage = '<p><img style= "height:80px;" src="/upload/images/finish/'.$image.'"/></p><a class="btn btn-danger deleteCustomImage" data-type="finish" data-id="'.$idProduct.'">X</a>';
                        $html = '<p><img style= "height:80px;" src="/upload/images/finish/'.$image.'"/></p>';
                    }
                    $tempName = $name ? $name->value : $finish->colour_name;
                    $templateTable = '
                            <td class="first-row"><div class="move-heading-item"></div>'.$idProduct.'</td>
                            <td>'.$finish->colour_code.'</td>
                            <td>'.$tempName.'</td>
                            <td class="finish-custom-image-'.$idProduct.' StyleCustomImage">
                                '.$html.'
                            </td>
                            <td><button type="button" class="btn btn-primary collapsed" data-toggle="collapse" data-target="#option-value-'.$idProduct.'" aria-expanded="false">Edit</button></td>';
                    return response()->json([
                        'success' => 'Record has been updated successfully!',
                        'template_table'  => $templateTable,
                        'template_image'  => null
                    ]);
                case 'exterior':
                    $templateTable = "";
                    $templateImage = "";
                    $entity_table = "exterior_group_color";
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $idProduct, 'entity_field' => 'exterior_colour_name', 'product_id' => $entity_id],
                        ['value' => $name]
                    );
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $idProduct, 'entity_field' => 'cylindo_data', 'product_id' => $entity_id],
                        ['value' => $cylindoData]
                    );
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $idProduct, 'entity_field' => 'cylindo_type', 'product_id' => $entity_id],
                        ['value' => $cylindoType]
                    );
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $idProduct, 'entity_field' => 'cylindo_type_optional', 'product_id' => $entity_id],
                        ['value' => $cylindoTypeOptional]
                    );
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $idProduct, 'entity_field' => 'cylindo_data_optional', 'product_id' => $entity_id],
                        ['value' => $cylindoDataOptional]
                    );
                    $exterior = Color::where('id', $idProduct)->get()->first();
                    $name = OptionEntityValue::getValue($exterior, 'exterior_colour_name', $entity_id);
                    $html = "";
                    $image = $exterior->custom_image;
                    if($exterior->custom_image != ""){
                        $templateImage = '<p><img style= "height:80px;" src="/upload/images/exterior/'.$image.'"/></p><a class="btn btn-danger deleteCustomImage" data-type="exterior" data-id="'.$idProduct.'">X</a>';
                        $html = '<p><img style= "height:80px;" src="/upload/images/exterior/'.$image.'"/></p>';
                    }
                    $tempName = $name ? $name->value : $exterior->colour_name;
                    $templateTable = '
                            <td class="first-row"><div class="move-heading-item"></div>'.$idProduct.'</td>
                            <td>'.$exterior->colour_code.'</td>
                            <td>'.$tempName.'</td>
                            <td class="exterior-custom-image-'.$idProduct.' StyleCustomImage">
                                '.$html.'
                            </td>
                            <td><button type="button" class="btn btn-primary collapsed" data-toggle="collapse" data-target="#option-value-'.$idProduct.'" aria-expanded="false">Edit</button></td>';
                    return response()->json([
                        'success' => 'Record has been updated successfully!',
                        'template_table'  => $templateTable,
                        'template_image'  => null
                    ]);
                case 'legs':
                    $templateTable = "";
                    $templateImage = "";
                    if(isset($image)){
                        Legs::where('id', $idProduct)
                        ->update(['legs_name' => $name,'description' => $des,'custom_image' => $image,'cylindo_data' => $cylindoData,'cylindo_type' => $cylindoType, 'cylindo_data_optional' => $cylindoDataOptional,'cylindo_type_optional' => $cylindoTypeOptional]);
                    }else{
                        Legs::where('id', $idProduct)
                        ->update(['legs_name' => $name,'description' => $des,'cylindo_data' => $cylindoData,'cylindo_type' => $cylindoType, 'cylindo_data_optional' => $cylindoDataOptional,'cylindo_type_optional' => $cylindoTypeOptional]);
                    }
                    $entity_table = "legs";
                    $entity_field = $e_field;
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $entity_id, 'entity_field' => $entity_field],
                        ['value' => $name]
                    );
                    $legs = Legs::where('id', $idProduct)->get();
                    foreach($legs as $leg){
                        $html = "";
                        $image = $leg->custom_image;
                        if($leg->custom_image != ""){
                            $templateImage = '<p><img style= "height:80px;" src="/upload/images/legs/'.$image.'"/></p><a class="btn btn-danger deleteCustomImage" data-type="leg" data-id="'.$idProduct.'">X</a>';
                            $html = '<p><img style= "height:80px;" src="/upload/images/legs/'.$image.'"/></p>';
                        }
                        $templateTable .= '
                                <td class="data-grid-checkbox-cell">
                                    <label class="data-grid-checkbox-cell-inner">
                                    <input class="input-checkbox-legs" type="checkbox" value="'.$idProduct.'">
                                    </label>
                                </td>
                                <td class="first-row"><div class="move-heading-item"></div>'.$idProduct.'</td>
                                <td>'.$leg->legs_code.'</td>
                                <td>'.$leg->legs_name.'</td>
                                <td class="leg-custom-image-'.$idProduct.' StyleCustomImage">
                                    '.$html.'
                                </td>
                                <td><button type="button" class="btn btn-primary collapsed" data-toggle="collapse" data-target="#option-value-'.$idProduct.'" aria-expanded="false">Edit</button></td>';
                    }
                    return response()->json([
                        'success' => 'Record has been updated successfully!',
                        'template_table'  => $templateTable,
                        'template_image'  => $templateImage
                    ]);
                case 'cushioning':
                    $templateTable = "";
                    $templateImage = "";
                    $html = "";
                    if(isset($image)){
                        Cushioning::where('id', $idProduct)
                        ->update(['cushioning_name' => $name,'description' => $des,'custom_image' => $image,'cylindo_data' => $cylindoData,'cylindo_type' => $cylindoType, 'cylindo_data_optional' => $cylindoDataOptional,'cylindo_type_optional' => $cylindoTypeOptional]);
                    }
                    else{
                        Cushioning::where('id', $idProduct)
                        ->update(['cushioning_name' => $name,'description' => $des,'cylindo_data' => $cylindoData,'cylindo_type' => $cylindoType, 'cylindo_data_optional' => $cylindoDataOptional,'cylindo_type_optional' => $cylindoTypeOptional]);
                    }
                    $entity_table = "cushioning";
                    $entity_field = $e_field;
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $entity_id, 'entity_field' => $entity_field],
                        ['value' => $name]
                    );
                    $cushionings = Cushioning::where('id', $idProduct)->get();
                    foreach($cushionings as $cushioning){
                        $image = $cushioning->custom_image;
                        $onActive = $cushioning->is_active ? 'show' : 'hide';
                        $offActive = $cushioning->is_active ? 'hide' : 'show';
                        if($cushioning->custom_image != ""){
                            $html = '<p><img style= "height:80px;" src="/upload/images/cushioning/'.$image.'"/></p>';
                            $templateImage = '<p><img style= "height:80px;" src="/upload/images/cushioning/'.$image.'"/></p><a class="btn btn-danger deleteCustomImage" data-type="cushioning" data-id="'.$idProduct.'">X</a>';
                        }
                        $templateTable .= '
                                <td class="data-grid-checkbox-cell">
                                    <label class="data-grid-checkbox-cell-inner">
                                    <input class="input-checkbox-cushionings" type="checkbox" value="'.$idProduct.'">
                                    </label>
                                </td>
                                <td class="first-row"><div class="move-heading-item"></div>'.$idProduct.'</td>
                                <td>'.$cushioning->cushioning_code.'</td>
                                <td>'.$cushioning->cushioning_name.'</td>
                                <td class="cushioning-custom-image-'.$idProduct.' StyleCustomImage">
                                    '.$html.'
                                </td>
                                <td><button type="button" class="btn btn-primary collapsed" data-toggle="collapse" data-target="#option-value-'.$idProduct.'" aria-expanded="false">Edit</button></td>
                                <td>
                                    <div class="extra-option-switch-on-'.$idProduct.' '.$onActive.'">
                                        <svg
                                                data-id="'.$idProduct.'"
                                                data-active="'.$cushioning->is_active.'"
                                                class="extra-option-active-toggle extra-option-'.$idProduct.'" style="margin-top: -8px; cursor: pointer" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 511.999 511.999">
                                            <path d="M376.5 120.5h-241C60.785 120.5 0 181.285 0 256s60.785 135.5 135.5 135.5h241c74.715 0 135.5-60.785 135.5-135.5s-60.785-135.5-135.5-135.5zm0 241C318.327 361.5 271 314.174 271 256c0-58.172 47.327-105.5 105.5-105.5S482 197.828 482 256c0 58.174-47.327 105.5-105.5 105.5z" fill="#2e6da4" data-original="#000000" xmlns="http://www.w3.org/2000/svg"/>
                                        </svg>
                                    </div>
                                    <div class="extra-option-switch-off-'.$idProduct.' '.$offActive.'">
                                        <svg
                                                data-id="'.$idProduct.'"
                                                data-active="'.$cushioning->is_active.'"
                                                class="extra-option-active-toggle extra-option-'.$idProduct.'" style="margin-top: -8px; cursor: pointer" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 511.999 511.999">
                                            <path d="M376.499 120.5h-241C60.784 120.5 0 181.286 0 256s60.784 135.5 135.499 135.5h241c74.715 0 135.5-60.785 135.5-135.5s-60.785-135.5-135.5-135.5zm-241 241.001C77.326 361.501 30 314.173 30 256s47.326-105.5 105.499-105.5c58.173 0 105.5 47.327 105.5 105.5s-47.327 105.501-105.5 105.501z" fill="#9f9f9f" data-original="#000000" xmlns="http://www.w3.org/2000/svg"/>
                                        </svg>
                                    </div>
                                </td>';
                                
                    }
                    return response()->json([
                        'success' => 'Record has been updated successfully!',
                        'template_table'  => $templateTable,
                        'template_image'  => $templateImage
                    ]);
                case 'extraOption':
                    $templateTable = "";
                    $templateImage = "";
                    $html = "";
                    if(isset($image)){
                        ExtraOption::where('id', $idProduct)
                        ->update(['name' => $name,'description' => $des,'custom_image' => $image,'cylindo_data' => $cylindoData,'cylindo_type' => $cylindoType, 'cylindo_data_optional' => $cylindoDataOptional,'cylindo_type_optional' => $cylindoTypeOptional]);
                    }
                    else{
                        ExtraOption::where('id', $idProduct)
                        ->update(['description' => $des,'cylindo_data' => $cylindoData,'cylindo_type' => $cylindoType, 'cylindo_data_optional' => $cylindoDataOptional,'cylindo_type_optional' => $cylindoTypeOptional]);
                    }
                    $entity_table = "extra_group_option";
                    $entity_field = $e_field;
                    OptionEntityValue::updateOrCreate(
                        ['entity_table' => $entity_table, 'entity_id' => $entity_id, 'entity_field' => $entity_field],
                        ['value' => $name]
                    );
                    $extraOptions = ExtraOption::where('id', $idProduct)->get();
                    foreach($extraOptions as $extraOption){
                        $image = $extraOption->custom_image;
                        $isRequired = $extraOption->is_required== '1'  ? 'Yes' :'No';
                        $onActive = $extraOption->is_active ? 'show' : 'hide';
                        $offActive = $extraOption->is_active ? 'hide' : 'show';
                        if($extraOption->custom_image != ""){
                            $templateImage = '<p><img style= "height:80px;" src="/upload/images/extraOption/'.$image.'"/></p><a class="btn btn-danger deleteCustomImage" data-type="extraOption" data-id="'.$idProduct.'">X</a>';
                            $html = '<p><img style= "height:80px;" src="/upload/images/extraOption/'.$image.'"/></p>';
                        }
                        $templateTable .= '
                                <td class="data-grid-checkbox-cell">
                                    <label class="data-grid-checkbox-cell-inner">
                                    <input class="input-checkbox-extraOptions" type="checkbox" value="'.$idProduct.'">
                                    </label>
                                </td>
                                <td class="first-row"><div class="move-heading-item"></div>'.$idProduct.'</td>
                                <td>'.$extraOption->sku.'</td>
                                <td>'.$name.'</td>
                                <td>'.$isRequired.'</td>
                                <td>'.$extraOption->cylindo_type.'</td> 
                                <td>'.$cylindoData.'</td>
                                <td class="extraOption-custom-image-'.$idProduct.' StyleCustomImage">
                                    '.$html.'
                                </td>
                                <td><button type="button" class="btn btn-primary collapsed" data-toggle="collapse" data-target="#option-value-'.$idProduct.'" aria-expanded="false">Edit</button></td>
                                <td>
                                    <div class="extra-option-switch-on-'.$idProduct.' '.$onActive.'">
                                        <svg
                                                data-id="'.$idProduct.'"
                                                data-active="'.$extraOption->is_active.'"
                                                class="extra-option-active-toggle extra-option-'.$idProduct.'" style="margin-top: -8px; cursor: pointer" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 511.999 511.999">
                                            <path d="M376.5 120.5h-241C60.785 120.5 0 181.285 0 256s60.785 135.5 135.5 135.5h241c74.715 0 135.5-60.785 135.5-135.5s-60.785-135.5-135.5-135.5zm0 241C318.327 361.5 271 314.174 271 256c0-58.172 47.327-105.5 105.5-105.5S482 197.828 482 256c0 58.174-47.327 105.5-105.5 105.5z" fill="#2e6da4" data-original="#000000" xmlns="http://www.w3.org/2000/svg"/>
                                        </svg>
                                    </div>
                                    <div class="extra-option-switch-off-'.$idProduct.' '.$offActive.'">
                                        <svg
                                                data-id="'.$idProduct.'"
                                                data-active="'.$extraOption->is_active.'"
                                                class="extra-option-active-toggle extra-option-'.$idProduct.'" style="margin-top: -8px; cursor: pointer" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 511.999 511.999">
                                            <path d="M376.499 120.5h-241C60.784 120.5 0 181.286 0 256s60.784 135.5 135.499 135.5h241c74.715 0 135.5-60.785 135.5-135.5s-60.785-135.5-135.5-135.5zm-241 241.001C77.326 361.501 30 314.173 30 256s47.326-105.5 105.499-105.5c58.173 0 105.5 47.327 105.5 105.5s-47.327 105.501-105.5 105.501z" fill="#9f9f9f" data-original="#000000" xmlns="http://www.w3.org/2000/svg"/>
                                        </svg>
                                    </div>
                                </td>';
                                

                    }

                    return response()->json([
                        'success' => 'Record has been updated successfully!',
                        'template_table'  => $templateTable,
                        'template_image'  => $templateImage
                    ]);
            }

        }
        catch (Exception $e) {
            return response()->json([
                'message' =>  $e->getMessage()
            ]);;
        }
    }
    public function uploadLegsImages(Request $request){
        $idProduct = $request->id;
        $type = $request->type;
        $des = $request->des;
        $cylindoData = $request->cylindoData;
        $cylindoType = $request->cylindoType;
        $cylindoDataOptional = $request->cylindoDataOptional;
        $cylindoTypeOptional = $request->cylindoTypeOptional;

        $this->validate($request, [
            'custom_image' => 'image|mimes:jpeg,png,jpg|max:2048'
        ]);
        Legs::where('id', $idProduct)
        ->update(['cylindo_data' => $cylindoData,'cylindo_type' => $cylindoType, 'cylindo_data_optional' => $cylindoDataOptional, 'cylindo_type_optional' => $cylindoTypeOptional]);

        if($request['custom_image']){
            if ($request->hasFile('custom_image')) {
                $image = $request->file('custom_image')->getClientOriginalName();
                $destination_path = "upload/images/legs";
                if ($this->createPath($destination_path)) {
                    if ($request->file('custom_image')->move($destination_path, $image)) {
                        Legs::where('id', $idProduct)
                            ->update(['custom_image' => $image]);
                    } else {
                        return $this->responseRequestError('Cannot upload file');
                    }
                } else {
                    if ($request->file('custom_image')->move($destination_path, $image)) {
                        Legs::where('id', $idProduct)
                            ->update(['custom_image' => $image]);
                    } else {
                        return $this->responseRequestError('Cannot upload file');
                    }
                }
            }else {
                return $this->responseRequestError('File not found');
            }

        }
        Legs::where('id', $idProduct)
            ->update(['description' => $des]);
        $templateImage = "";
        $legs = Legs::where('id', $idProduct)->get();
        foreach($legs as $leg){
            $image = $leg->custom_image;
            if($leg->custom_image != ""){
                $templateImage = '<p><img style= "height:80px;" src="/upload/images/legs/'.$image.'"/></p><a class="btn btn-danger deleteCustomImage" data-type="leg" data-id="'.$idProduct.'">X</a>';
            }
        }

        return response()->json([
            'success' => 'Record has been updated successfully!',
            'template_image'  => $templateImage
        ]);
    }

    public function uploadCushioningImages(Request $request){
        $this->validate($request, [
            'cushioning_custom_image' => 'image|mimes:jpeg,png,jpg|max:2048'
        ]);
        Cushioning::where('id', $request['cushioning_id'])
        ->update(['cylindo_data' => $request['cylindo_data'],'cylindo_type' => $request['cylindo_type'],'cylindo_type_optional' => $request['cylindoTypeOptional'],'cylindo_data_optional' => $request['cylindoDataOptional']]);

        if($request['cushioning_custom_image']){
            if ($request->hasFile('cushioning_custom_image')) {
                $image = $request->file('cushioning_custom_image')->getClientOriginalName();
                $destination_path = "upload/images/cushioning";
                if ($this->createPath($destination_path)) {
                    if ($request->file('cushioning_custom_image')->move($destination_path, $image)) {
                        Cushioning::where('id', $request['cushioning_id'])
                            ->update(['custom_image' => $image]);
                    } else {
                        return $this->responseRequestError('Cannot upload file');
                    }
                } else {
                    if ($request->file('cushioning_custom_image')->move($destination_path, $image)) {
                        Cushioning::where('id', $request['cushioning_id'])
                            ->update(['custom_image' => $image]);
                    } else {
                        return $this->responseRequestError('Cannot upload file');
                    }
                }
            }else {
                return $this->responseRequestError('File not found');
            }

        }
        Cushioning::where('id', $request['cushioning_id'])
            ->update(['description' => $request['description']]);

        $templateImage = "";
        $cushionings = Cushioning::where('id', $request['cushioning_id'])->get();
        foreach($cushionings as $cushioning){
            $image = $cushioning->custom_image;
            if($cushioning->custom_image != ""){
                $templateImage = '<p><img style= "height:80px;" src="/upload/images/cushioning/'.$image.'"/></p><a class="btn btn-danger deleteCustomImage" data-type="cushioning" data-id="'.$request['cushioning_id'].'">X</a>';
            }
        }

        return response()->json([
            'success' => 'Record has been updated successfully!',
            'template_image'  => $templateImage
        ]);
    }


    public function uploadExteriorImagesBK(Request $request){
        $this->validate($request, [
            'exterior_custom_image' => 'image|mimes:jpeg,png,jpg|max:2048'
        ]);

        if($request['exterior_custom_image']){
            if ($request->hasFile('exterior_custom_image')) {
                $image = $request->file('exterior_custom_image')->getClientOriginalName();
                $destination_path = "upload/images/exterior";
                if ($this->createPath($destination_path)) {
                    if ($request->file('exterior_custom_image')->move($destination_path, $image)) {
                        Exterior::where('id', $request['exterior_id'])
                            ->update(['custom_image' => $image]);
                    } else {
                        return $this->responseRequestError('Cannot upload file');
                    }
                } else {
                    if ($request->file('exterior_custom_image')->move($destination_path, $image)) {
                        Exterior::where('id', $request['exterior_id'])
                            ->update(['custom_image' => $image]);
                    } else {
                        return $this->responseRequestError('Cannot upload file');
                    }
                }
            }else {
                return $this->responseRequestError('File not found');
            }

        }

        return redirect('/exterior');
    }


    public function uploadExtraOptionsImages(Request $request){
        $this->validate($request, [
            'extraOption_custom_image' => 'image|mimes:jpeg,png,jpg|max:2048'
        ]);
        ExtraOption::where('id', $request['extraOption_id'])
        ->update(['cylindo_data' => $request['cylindo_data'],'cylindo_type' => $request['cylindo_type'], 'cylindo_type_optional' => $request['cylindoTypeOptional'],'cylindo_data_optional' => $request['cylindoDataOptional']]);

        if($request['extraOption_custom_image']){
            if ($request->hasFile('extraOption_custom_image')) {
                $image = $request->file('extraOption_custom_image')->getClientOriginalName();
                $destination_path = "upload/images/extraOption";
                if ($this->createPath($destination_path)) {
                    if ($request->file('extraOption_custom_image')->move($destination_path, $image)) {
                        ExtraOption::where('id', $request['extraOption_id'])
                            ->update(['custom_image' => $image]);
                    } else {
                        return $this->responseRequestError('Cannot upload file');
                    }
                } else {
                    if ($request->file('extraOption_custom_image')->move($destination_path, $image)) {
                        ExtraOption::where('id', $request['extraOption_id'])
                            ->update(['custom_image' => $image]);
                    } else {
                        return $this->responseRequestError('Cannot upload file');
                    }
                }
            }else {
                return $this->responseRequestError('File not found');
            }

        }
        ExtraOption::where('id', $request['extraOption_id'])
            ->update(['description' => $request['description']]);

        $templateImage = "";
        $extraOptions = ExtraOption::where('id', $request['extraOption_id'])->get();
        foreach($extraOptions as $extraOption){
            $image = $extraOption->custom_image;

            if($extraOption->custom_image != ""){
                $templateImage = '<p><img style= "height:80px;" src="/upload/images/extraOption/'.$image.'"/></p><a class="btn btn-danger deleteCustomImage" data-type="extraOption" data-id="'.$request['extraOption_id'].'">X</a>';
            }
        }
        return response()->json([
            'success' => 'Record has been updated successfully!',
            'template_image'  => $templateImage
        ]);
    }


    protected function responseRequestError($message = 'Bad request', $statusCode = 200)
    {
        return response()->json(['status' => 'error', 'error' => $message], $statusCode)
            ->header('Access-Control-Allow-Origin', '*')
            ->header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    }

    protected function createPath($dir){
        if ( !file_exists( $dir ) && !is_dir( $dir ) ) {
            mkdir( $dir, 0777, true );
            return true;
        }else{
            return false;
        }
    }

    public function doTriggerMangeto()
    {
        if(isset($_GET['store'])){
            $process = new ProcessSyncToMagento($_GET['store']);
            dispatch($process);
            return redirect('jobs');
        }
    }

    public function doTriggerSingleProductToMagento($id)
    {
        if(isset($id)){
            $product = Product::where('id',$id)->first();
            $process = new ProcessSyncToMagento($product->store_id,$id);
            dispatch($process);
            return redirect('jobs');
        }
    }

    public function doTriggerSingleProductFromSap($id)
    {
        if(isset($id)){
            $product = Product::where('id',$id)->first();
            $process = new ProcessSyncToMagento($product->store_id,$id);
            $process = new \App\Jobs\ProcessSubRangeLines($product->store_id, $product->sub_range_code, 0, $product->sku);
            dispatch($process);
            return redirect('jobs');
        }
    }

    public function doTriggerSyncSubRangeMagento($sub_range_code, $store_id)
    {
        if(isset($sub_range_code)){
            $productSubRange = Product::where('sub_range_code',$sub_range_code)->where('store_id',$store_id)->where('status',1)->get();
            if (count($productSubRange) > 0)
                foreach ($productSubRange as $product) {
                    $process = new ProcessSyncToMagento($store_id,$product->id);
                    dispatch($process);
                }
            return redirect('jobs');
        }
    }

    public function doTriggerSyncSubRangeSAP($id)
    {
        if(isset($id)){
            $subRange = \App\Sap\ParentProductPackage::where('id', $id)->first();
            if ($subRange){
                $productSubRange = new \App\Jobs\ProcessSubRangeLines($subRange->store_id, $subRange->sub_range_code, 0);
                dispatch($productSubRange);
                return redirect('jobs');
            }
        }
        return redirect('subrange');
    }

    public function doTriggerSAP()
    {
        if(isset($_GET['store'])){
            $process = new ProcessSyncFromSap($_GET['store']);
            dispatch($process);
            return redirect('jobs');
        }
    }
    public function createProductAttribute (Request $request){
        $validator = Validator::make($request->all(), [
            'code' => 'bail|required|min:3',
            'name' => 'bail|required|min:3',
            'type' => 'bail|required',
            'isrequired' => 'bail|required'
        ]);
        if ($validator->fails()) {
            return redirect('/add-product-attribute');
        }
        $attr = new ProductAttribute();
        $attr->code = $request->input('code');
        $attr->name = $request->input('name');
        $attr->type = $request->input('type');
        $attr->is_required = $request->input('isrequired');
        $attr->default_value = $request->input('defaultvalue');
        $attr->save();
        return redirect('/product-attribute');
    }
    public function createOptionalUpgrades (Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'bail|required',
            'price' => 'bail|required|numeric',
            'type_id' => 'bail|required',
            'image' => 'image|mimes:jpeg,png,jpg|max:2048'
        ]);
        if ($validator->fails()) {
            return redirect('/add-optional-upgrades/id/'.$request->input('product_id'));
        }
        $optional = new OptionalUpgrades();
        if($request['image']){
            if ($request->hasFile('image')) {
                $image = $request->file('image')->getClientOriginalName();
                $image = uniqid() . '_' . $image;
                $destination_path = "upload/images/optionalUpgrade/";
                $this->createPath($destination_path);
                if(!$request->file('image')->move($destination_path, $image)){
                    return $this->responseRequestError('Cannot upload file');
                }else{
                    $optional->image = $image;
                }
            }else {
                return $this->responseRequestError('File not found');
            }
        }
        $optional->store_id = $request->input('store_id');
        $optional->product_id = $request->input('product_id');
        $optional->name = $request->input('name');
        $optional->price = $request->input('price');
        $optional->sale_price = 0;
        $optional->type_id = $request->input('type_id');
        $optional->active = $request->input('active');
        $optional->save();
        return redirect('/product-detail/view/id/'.$request->input('product_id'));
    }
    public function createOptionalUpgradeType (Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'bail|required|min:3'
        ]);
        if ($validator->fails()) {
            return redirect('/add-optional-upgrade-type');
        }
        $type = new OptionalUpgradeType();       
        $type->name = $request->input('name');
        $type->save();
        return redirect('/optional-upgrade-type');
    }
    public function updateOptionalUpgrades (Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'bail|required',
            'price' => 'bail|required|numeric',
            'type_id' => 'bail|required',
            'image' => 'image|mimes:jpeg,png,jpg|max:2048'
        ]);
        if ($validator->fails()) {
            return redirect('/edit-optional-upgrades/'.$request->input('id'));
        }      
        try {
            $optional = OptionalUpgrades::find($request->input('id'));
            if($request['image']){
	            if ($request->hasFile('image')) {
	                $image = $request->file('image')->getClientOriginalName();
                    $image = uniqid() . '_' . $image;
	                $destination_path = "upload/images/optionalUpgrade/";
                    $this->createPath($destination_path);
                    if(!$request->file('image')->move($destination_path, $image)){
                        return $this->responseRequestError('Cannot upload file');
                    }else{
                        $oldImage = $optional->image;
                        $optional->image =$image;
                        if(is_file($destination_path . $oldImage)){
                            unlink($destination_path . $oldImage);
                        }
                    }
	            }else {
	                return $this->responseRequestError('File not found');
	            }
	        }

            $optional->store_id = $request->input('store_id');
            $optional->product_id = $request->input('product_id');
            $optional->name = $request->input('name');
            $optional->price = $request->input('price');
            $optional->type_id = $request->input('type_id');
            $optional->active = $request->input('active');
            $optional->update();
            return redirect('/product-detail/view/id/'.$request->input('product_id'));
        }catch (Exception $e) {
            return $this->responseRequestError($e->getMessage());
        }
        
        
    }
    public function updateProductAttribute (Request $request) {
        $validator = Validator::make($request->all(), [
            'code' => 'bail|required|min:3',
            'name' => 'bail|required|min:3',
            'type' => 'bail|required',
            'isrequired' => 'bail|required',
        ]);
        if ($validator->fails()) {
            return redirect('/product-attribute/'.$request->input('id'));
        }
        $attr = ProductAttribute::find($request->input('id'));
        $attr->id = $request->input('id');
        $attr->code = $request->input('code');
        $attr->name = $request->input('name');
        $attr->type = $request->input('type');
        $attr->is_required = $request->input('isrequired');
        $attr->default_value = $request->input('defaultvalue');
        $attr->update();
        return redirect('/product-attribute/'); 
    } 
    public function updateProductEntity(Request $request){
        $store_id = $request->input('store_id');
        $product_id = $request->input('product_id');
        if($request['product_entity_value']){
            foreach($request['product_entity_value'] as $key => $val){
                if (empty($val) && $val!=0){
                    $attr = ProductEntityValue::find($key);
                    if ($attr)
                        $attr->delete();
                }else{
                    $attr = ProductEntityValue::find($key);
                    $attr->value = $val;
                    $attr->update();
                }
            }
        }
        if($request['new_product_entity_value']){
            foreach($request['new_product_entity_value'] as $key => $val){
                if (empty($val)) continue;
                $attr = new ProductEntityValue();
                $attr->attribute_id = $key;
                $attr->store_id = $store_id;
                $attr->product_id = $product_id;
                $attr->value = $val;
                $attr->save();
            }
        }        
        return redirect('/product/'.'?store='.$store_id);
    }
    public function updateOptionalUpgradeType (Request $request) {
        $validator = Validator::make($request->all(), [
            'name' => 'bail|required|min:3'
        ]);
        if ($validator->fails()) {
            return redirect('/optional-upgrade-type/'.$request->input('id'));
        }
        $type = OptionalUpgradeType::find($request->input('id'));
        $type->name = $request->input('name');
        $type->update();
        return redirect('/optional-upgrade-type/'); 
    }

    public function deleteCustomImage(Request $request) {
    	  try {
    	  	$id = $request->id;
    	  	$option = $request->option;
    	  	switch ($option) {
    	  		case 'swatch':
    	  			$attr = Value::find($id);
    	  			break;
    	  		case 'pswatch':
    	  			$attr = Option::find($id);
    	  			break;
    	  		case 'leg':
    	  			$attr = Legs::find($id);
    	  			break;
    	  		case 'cushioning':
    	  			$attr = Cushioning::find($id);
    	  			break;
    	  		case 'exterior':
    	  			$attr = Exterior::find($id);
    	  			break;
                case 'exteriorgroupcolor':
                    $attr = Color::find($id);
                    break;
    	  		case 'extraOption':
    	  			$attr = ExtraOption::find($id);
    	  			break;
                case 'finishgroupcolor':
                    $attr = FinishGroupColor::find($id);
                    break;
                case 'childc':
                    $attr = Value::find($id);
                    break;
    	  	}
            if($option == 'childc') {
                $attr = Value::find($id);
                $attr->colour_description_image = "";
            } else {
                $attr->custom_image = "";
            }
	        $attr->update();
	        return response()->json([
	            'success' => 'Record has been deleted successfully!'
	        ]);;
		  }
		  catch (Exception $e) {
		        return response()->json([
		            'message' =>  $e->getMessage()
		        ]);;
		  }
    }

    public function deleteOptionalUpgrades(Request $request) {
        try {
            $id_optional = $request->id_optional;
            $optional = OptionalUpgrades::find($id_optional);
            $oldImage = $optional->image; 
            $destination_path = "upload/images/optionalUpgrade/";
            if(is_file($destination_path . $oldImage)){
                unlink($destination_path . $oldImage);
            }
            $optional->delete();
            $optional->update();
            return response()->json([
                'success' => 'Record has been deleted successfully!'
            ]);
        }
        catch (Exception $e) {
              return response()->json([
                  'message' =>  $e->getMessage()
              ]);
        }
    }

    public function updateActive(Request $request) {
        try {
            $id = $request->id;
            $option = $request->option;
            switch ($option) {
                case 'swatch':
                    $attr = Option::find($id);
                    break;
                case 'cswatch':
                    $attr = Value::find($id);
                    break;
                case 'leg':
                    $attr = Legs::find($id);
                    break;
                case 'cushioning':
                    $attr = Cushioning::find($id);
                    break;
                case 'extraOption':
                    $attr = ExtraOption::find($id);
                    break;
                case 'exterior':
                    $attr = Exterior::find($id);
                    break;
                case 'exterior_group_color':
                        $attr = Color::find($id);
                        break;
                case 'finish':
                    $attr = Finish::find($id);
                    break;
                case 'finish_group_color':
                    $attr = FinishGroupColor::find($id);
                    break;
            }

          $attr->is_active = !$attr->is_active;
          $attr->update();
          return response()->json([
              'success' => 'Record has been deleted successfully!',
              'value' => $attr->is_active
          ]);;
        }
        catch (Exception $e) {
              return response()->json([
                  'message' =>  $e->getMessage()
              ]);;
        }
  }

    public function findConfigurableLink(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id' => 'bail|required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'failed' => 'Failed to find link',
            ]);;
        }

        $link = new ConfigurableMapping($request->input('id'));

        if ($link)
        {
            return response()->json(
                $link->toArray()
            );
        }
    }

    public function insertConfigurableLink(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'parent_id' => 'bail|required',
            'product_id' => 'bail|required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'failed' => 'Failed to create link'
            ]);;
        }
    }

    public function dashboardConfigurableLink()
    {
        $link = ConfigurableMapping::all();

        return view('configurables/dash', ["link"=>$link]);
    }
    public function uploadFinishGroupImages(Request $request){
        $this->validate($request, [
            'colour_value_custom_image.*' => 'image|mimes:jpeg,png,jpg|max:2048',
        ]);
        $response = null;
        $templateImage = [];
        if($request['colour_value_custom_image']){
            foreach($request['colour_value_custom_image'] as $key => $val){
                if($request->hasFile('colour_value_custom_image.'.$key)){
                    $image = $request->file('colour_value_custom_image.'.$key)->getClientOriginalName();
                    $destination_path = "upload/images/finish";
                    if($this->createPath($destination_path)){
                        if ($request->file('colour_value_custom_image.'.$key)->move($destination_path, $image)) {
                            FinishGroupColor::where('id', $key)
                                ->update(['custom_image' => $image]);
                                $templateImage[] = [
                                    'image' => $image,
                                    'name'  => $key
                                ];
                        } else {
                            return $this->responseRequestError('Cannot upload file');
                        }
                    }else{
                        if ($request->file('colour_value_custom_image.'.$key)->move($destination_path, $image)) {
                            FinishGroupColor::where('id', $key)
                                ->update(['custom_image' => $image]);
                                $templateImage[] = [
                                    'image' => $image,
                                    'name'  => $key
                                ];
                        } else {
                            return $this->responseRequestError('Cannot upload file');
                        }
                    }

                }else {
                    return $this->responseRequestError('File not found');
                }

            }

        }
        if($request['description']){
            foreach($request['description'] as $key => $val){
                FinishGroupColor::where('id', $key)
                    ->update(['description' => $val]);
            }
        }
        if($request['cylindo_data']){
            foreach($request['cylindo_data'] as $key => $val){
                FinishGroupColor::where('id', $key)
                    ->update(['cylindo_data' => $val]);
            }
        }
        if($request['cylindo_type']){
            foreach($request['cylindo_type'] as $key => $val){
                FinishGroupColor::where('id', $key)
                    ->update(['cylindo_type' => $val]);
            }
        }
        if($request['cylindo_data_optional']){
            foreach($request['cylindo_data_optional'] as $key => $val){
                FinishGroupColor::where('id', $key)
                    ->update(['cylindo_data_optional' => $val]);
            }
        }
        if($request['cylindo_type_optional']){
            foreach($request['cylindo_type_optional'] as $key => $val){
                FinishGroupColor::where('id', $key)
                    ->update(['cylindo_type_optional' => $val]);
            }
        }
        return response()->json([
            'template_image'  => $templateImage
        ]);
    }
    public function uploadExteriorImages(Request $request){
        $this->validate($request, [
            'colour_value_custom_image.*' => 'image|mimes:jpeg,png,jpg|max:2048',
        ]);
        $templateImage = [];
        $response = null;
        if($request['colour_value_custom_image']){
            foreach($request['colour_value_custom_image'] as $key => $val){
                if($request->hasFile('colour_value_custom_image.'.$key)){
                    $image = $request->file('colour_value_custom_image.'.$key)->getClientOriginalName();
                    $destination_path = "upload/images/exterior";
                    if($this->createPath($destination_path)){
                        if ($request->file('colour_value_custom_image.'.$key)->move($destination_path, $image)) {
                            Color::where('id', $key)
                                ->update(['custom_image' => $image]);
                                $templateImage[] = [
                                    'image' => $image,
                                    'name'  => $key
                                ];

                        } else {
                            return $this->responseRequestError('Cannot upload file');
                        }
                    }else{
                        if ($request->file('colour_value_custom_image.'.$key)->move($destination_path, $image)) {
                            Color::where('id', $key)
                                ->update(['custom_image' => $image]);
                                $templateImage[] = [
                                    'image' => $image,
                                    'name'  => $key
                                ];
                        } else {
                            return $this->responseRequestError('Cannot upload file');
                        }
                    }

                }else {
                    return $this->responseRequestError('File not found');
                }

            }

        }
        if($request['description']){
            foreach($request['description'] as $key => $val){
                Color::where('id', $key)
                    ->update(['description' => $val]);
            }
        }

        if($request['cylindo_data']){
            foreach($request['cylindo_data'] as $key => $val){
                Color::where('id', $key)
                    ->update(['cylindo_data' => $val]);
            }
        }
        if($request['cylindo_type']){
            foreach($request['cylindo_type'] as $key => $val){
                Color::where('id', $key)
                    ->update(['cylindo_type' => $val]);
            }
        }
        if($request['cylindo_data_optional']){
            foreach($request['cylindo_data_optional'] as $key => $val){
                Color::where('id', $key)
                    ->update(['cylindo_data_optional' => $val]);
            }
        }
        if($request['cylindo_type_optional']){
            foreach($request['cylindo_type_optional'] as $key => $val){
                Color::where('id', $key)
                    ->update(['cylindo_type_optional' => $val]);
            }
        }
        return response()->json([
            'template_image'  => $templateImage
        ]);
    }

    public function updateOptionEntityValue(Request $request) {
          try {
            $entity_id = $request->entity_id;
            $e_table = $request->entity_table;
            $e_field = $request->entity_field;
            $entity_value = $request->entity_value;
            $description_colour = $request->description_colour;
            switch ($e_table) {
                case 'finish':
                    $entity_table = "finish";
                    $entity_field = "finish_name";
                    break;
                case 'finishgroupcolor':
                    $entity_table = "finish_group_color";
                    $entity_field = "finish_colour_name";
                    break;
                case 'extraOption':
                    $entity_table = "extra_group_option";
                    $entity_field = $e_field;
                    break;
                case 'exterior':
                    $entity_table = "exterior";
                    $entity_field = "exterior_name";
                    break;
                case 'exteriorgroupcolor':
                    $entity_table = "exterior_group_color";
                    $entity_field = "exterior_colour_name";
                    break;
                case 'cushioning':
                    $entity_table = "cushioning";
                    $entity_field = "cushioning_name";
                    break;
                case 'leg':
                    $entity_table = "legs";
                    $entity_field = "leg_name";
                    break;
                case 'materialgroupoption':
                    $entity_table = "material_group_options";
                    $entity_field = "material_group_option_name";
                    break;
                case 'materialgroupoptionvalue':
                    $entity_table = "material_group_option_value";
                    $entity_field = "material_group_option_colour_name";
                    break;
            }            
            if ($e_table == 'materialgroupoptionvaluedes') {
                Value::where('id', $entity_id)
                        ->update(['colour_description' => $description_colour]);
            } else {
                OptionEntityValue::updateOrCreate(
                    ['entity_table' => $entity_table, 'entity_id' => $entity_id, 'entity_field' => $entity_field],
                    ['value' => $entity_value]
                );
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);;
          }
          catch (Exception $e) {
                return response()->json([
                    'message' =>  $e->getMessage()
                ]);;
          }
    }

    public function updateSelectName(Request $request) {
        try {
          $entity_id = $request->entity_id;
          $e_table = $request->entity_table;
          $e_field = $request->entity_field;
          $entity_value = $request->entity_value;
          switch ($e_table) {
            case 'extraOption':
                $entity_table = "extra_group_option";
                $entity_field = "extra_option_name";
                break;

            case 'cushioning':
                $entity_table = "cushioning";
                $entity_field = "cushioning_name";
                break;
            case 'leg':
                $entity_table = "legs";
                $entity_field = "leg_name";
                break;
            case 'materialgroupoption':
                $entity_table = "material_group_options";
                $entity_field = "material_group_option_name";
                break;
            case 'finish':
                $entity_table = "finish";
                $entity_field = "finish_name";
                break;
            case 'exterior':
                $entity_table = "exterior";
                $entity_field = "exterior_name";
                break;
        }

        foreach ($entity_id as $id) {
            OptionEntityValue::updateOrCreate(
                ['entity_table' => $entity_table, 'entity_id' => $id, 'entity_field' => $entity_field],
                ['value' => $entity_value]
            );
        }
          return response()->json([
              'success' => 'Record has been updated successfully!'
          ]);
        }
        catch (Exception $e) {
              return response()->json([
                  'message' =>  $e->getMessage()
              ]);
        }
    }

    public function updateExteriorName(Request $request){
        $exterior_name = $request->exterior_name;
        $exterior_id = $request->exterior_id;

        try {
            foreach ($exterior_id as $id) {
                Exterior::where('id', $id)
                    ->update(['exterior_name' => $exterior_name]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateFinishName(Request $request){
        $name = $request->name;
        $name_id = $request->name_id;

        try {
            foreach ($name_id as $id) {
                Finish::where('id', $id)
                    ->update(['finish_name' => $name]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateSelectLegsDesc (Request $request) {
        $description = $request->description;
        $legId = $request->leg_id;
        try {
            foreach ($legId as $id) {
                Legs::where('id', $id)
                    ->update(['description' => $description]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };

    }

    public function updateSelectLegsImage(Request $request) {
        $this->validate($request, [
            'custom_image' => 'image|mimes:jpeg,png,jpg|max:2048',
        ]);
        $legId = explode(",",$request->leg_id);
        try {
            if($request->hasFile('custom_image')){
                $image = $request->file('custom_image')->getClientOriginalName();
                $destination_path = "upload/images/legs";
                if($this->createPath($destination_path)){
                    if ($request->file('custom_image')->move($destination_path, $image)) {
                        foreach ($legId as $id) {
                            Legs::where('id', $id)
                                ->update(['custom_image' => $image]);
                        }
                    } else {
                        return response()->json([
                            'success' => false
                        ]);
                    }
                }else{
                    if ($request->file('custom_image')->move($destination_path, $image)) {
                        foreach ($legId as $id) {
                            Legs::where('id', $id)
                                ->update(['custom_image' => $image]);
                        }
                    } else {
                        return response()->json([
                            'success' => false
                        ]);
                    }
                }

            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };

    }

    public function updateSelectSwatchImage(Request $request) {
        $this->validate($request, [
            'custom_image' => 'image|mimes:jpeg,png,jpg|max:2048',
        ]);
        $swatchId = explode(",",$request->swatch_id);
        try {
            if($request->hasFile('custom_image')){
                $image = $request->file('custom_image')->getClientOriginalName();
                $destination_path = "upload/images";
                if($this->createPath($destination_path)){
                    if ($request->file('custom_image')->move($destination_path, $image)) {
                        foreach ($swatchId as $id) {
                            Option::where('id', $id)
                                ->update(['custom_image' => $image]);
                        }
                    } else {
                        return response()->json([
                            'success' => false
                        ]);
                    }
                }else{
                    if ($request->file('custom_image')->move($destination_path, $image)) {
                        foreach ($swatchId as $id) {
                            Option::where('id', $id)
                                ->update(['custom_image' => $image]);
                        }
                    } else {
                        return response()->json([
                            'success' => false
                        ]);
                    }
                }

            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };

    }

    public function updateSelectCushioningImage(Request $request) {
        $this->validate($request, [
            'custom_image' => 'image|mimes:jpeg,png,jpg|max:2048',
        ]);
        $cushioningId = explode(",",$request->cushioning_id);
        try {
            if($request->hasFile('custom_image')){
                $image = $request->file('custom_image')->getClientOriginalName();
                $destination_path = "upload/images/cushioning";
                if($this->createPath($destination_path)){
                    if ($request->file('custom_image')->move($destination_path, $image)) {
                        foreach ($cushioningId as $id) {
                            Cushioning::where('id', $id)
                                ->update(['custom_image' => $image]);
                        }
                    } else {
                        return response()->json([
                            'success' => false
                        ]);
                    }
                }else{
                    if ($request->file('custom_image')->move($destination_path, $image)) {
                        foreach ($cushioningId as $id) {
                            Cushioning::where('id', $id)
                                ->update(['custom_image' => $image]);
                        }
                    } else {
                        return response()->json([
                            'success' => false
                        ]);
                    }
                }

            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };

    }

    public function updateSelectExtraoptionsImage(Request $request) {
        $this->validate($request, [
            'custom_image' => 'image|mimes:jpeg,png,jpg|max:2048',
        ]);
        $extraoptionId = explode(",",$request->extraoption_id);
        try {
            if($request->hasFile('custom_image')){
                $image = $request->file('custom_image')->getClientOriginalName();
                $destination_path = "upload/images/extraOption";
                if($this->createPath($destination_path)){
                    if ($request->file('custom_image')->move($destination_path, $image)) {
                        foreach ($extraoptionId as $id) {
                            ExtraOption::where('id', $id)
                                ->update(['custom_image' => $image]);
                        }
                    } else {
                        return response()->json([
                            'success' => false
                        ]);
                    }
                }else{
                    if ($request->file('custom_image')->move($destination_path, $image)) {
                        foreach ($extraoptionId as $id) {
                            ExtraOption::where('id', $id)
                                ->update(['custom_image' => $image]);
                        }
                    } else {
                        return response()->json([
                            'success' => false
                        ]);
                    }
                }

            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };

    }

    public function updateSelectCushioningDesc (Request $request) {
        $description = $request->description;
        $cushioningId = $request->cushioning_id;
        try {
            foreach ($cushioningId as $id) {
                Cushioning::where('id', $id)
                    ->update(['description' => $description]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };

    }

    public function updateSelectExtraoptionsDesc (Request $request) {
        $description = $request->description;
        $extraoptionId = $request->extraoption_id;
        try {
            foreach ($extraoptionId as $id) {
                ExtraOption::where('id', $id)
                    ->update(['description' => $description]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };

    }

    public function updateLegsCylindoData (Request $request) {
        $cylindoData = $request->cylindoData;
        $legId = $request->leg_id;
        try {
            foreach ($legId as $id) {
                Legs::where('id', $id)
                    ->update(['cylindo_data' => $cylindoData]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };

    }

    public function updateLegsCylindoType (Request $request) {
        $cylindoType = $request->cylindoType;
        $legId = $request->leg_id;
        try {
            foreach ($legId as $id) {
                Legs::where('id', $id)
                    ->update(['cylindo_type' => $cylindoType]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };

    }

    public function updateCushioningCylindoData (Request $request) {
        $cylindoData = $request->cylindoData;
        $cushioningId = $request->cushioning_id;
        try {
            foreach ($cushioningId as $id) {
                Cushioning::where('id', $id)
                    ->update(['cylindo_data' => $cylindoData]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };

    }

    public function updateCushioningCylindoType (Request $request) {
        $cylindoType = $request->cylindoType;
        $cushioningId = $request->cushioning_id;
        try {
            foreach ($cushioningId as $id) {
                Cushioning::where('id', $id)
                    ->update(['cylindo_type' => $cylindoType]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };

    }

    public function updateExtraoptionsCylindoData (Request $request) {
        $cylindoData = $request->cylindoData;
        $extraoptionId = $request->extraoption_id;
        try {
            foreach ($extraoptionId as $id) {
                ExtraOption::where('id', $id)
                    ->update(['cylindo_data' => $cylindoData]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateExtraoptionsCylindoType (Request $request) {
        $cylindoType = $request->cylindoType;
        $extraoptionId = $request->extraoption_id;
        try {
            foreach ($extraoptionId as $id) {
                ExtraOption::where('id', $id)
                    ->update(['cylindo_type' => $cylindoType]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateFinishCylindoData (Request $request) {
        $cylindoData = $request->cylindoData;
        $finishId = $request->finish_id;
        try {
            foreach ($finishId as $id) {
                FinishGroupColor::where('finish_id', $id)
                    ->update(['cylindo_data' => $cylindoData]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateFinishCylindoType (Request $request) {
        $cylindoType = $request->cylindoType;
        $finishId = $request->finish_id;
        try {
            foreach ($finishId as $id) {
                FinishGroupColor::where('finish_id', $id)
                    ->update(['cylindo_type' => $cylindoType]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateExteriorCylindoData (Request $request) {
        $cylindoData = $request->cylindoData;
        $exteriorId = $request->exterior_id;
        try {
            foreach ($exteriorId as $id) {
                Color::where('exterior_id', $id)
                    ->update(['cylindo_data' => $cylindoData]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateExteriorCylindoType (Request $request) {
        $cylindoType = $request->cylindoType;
        $exteriorId = $request->exterior_id;
        try {
            foreach ($exteriorId as $id) {
                Color::where('exterior_id', $id)
                    ->update(['cylindo_type' => $cylindoType]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateStatusLegs (Request $request) {
        $status = $request->status;
        $legId = $request->leg_id;
        try {
            foreach ($legId as $id) {
                Legs::where('id', $id)
                    ->update(['is_active' => $status]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateStatusCushioning (Request $request) {
        $status = $request->status;
        $cushioningId = $request->cushioning_id;
        try {
            foreach ($cushioningId as $id) {
                Cushioning::where('id', $id)
                    ->update(['is_active' => $status]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateStatusExtraOptions (Request $request) {
        $status = $request->status;
        $extraoptionId = $request->extraoption_id;
        try {
            foreach ($extraoptionId as $id) {
                ExtraOption::where('id', $id)
                    ->update(['is_active' => $status]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateStatusExterior (Request $request) {
        $status = $request->status;
        $exteriorId = $request->exterior_id;
        try {
            foreach ($exteriorId as $id) {
                Exterior::where('id', $id)
                    ->update(['is_active' => $status]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateStatusFinish (Request $request) {
        $status = $request->status;
        $finishId = $request->finish_id;
        try {
            foreach ($finishId as $id) {
                Finish::where('id', $id)
                    ->update(['is_active' => $status]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    public function updateStatusSwatches (Request $request) {
        $status = $request->status;
        $swatchId = $request->swatch_id;
        try {
            foreach ($swatchId as $id) {
                Option::where('id', $id)
                    ->update(['is_active' => $status]);
            }
            return response()->json([
                'success' => 'Record has been update successfully!'
            ]);
        }

        catch (Exception $e) {
            return response()->json([
                'success' => false,
                'messenger' => $e->getMessage()
            ]);
        };
    }

    /**
     * Bulk Update for Extra Option Type
     * @param Request $request
     */
    public function updateSelectExtraoptionsType(Request $request)
    {
        try {
            foreach ($request->extra_option_ids as $extraOptionId) {
                OptionEntityValue::updateOrCreate(
                    ['entity_table' => 'extra_group_option', 'entity_id' => $extraOptionId, 'entity_field' => 'extra_option_type'],
                    ['value' => $request->type]
                );
            }
            return response()->json([
                'status' => 200,
                'message' => 'Record has been update successfully!'
            ]);
        } catch (Exception $error) {
            return response()->json([
                'success' => false,
                'message' => $error->getMessage()
            ]);
        }
    }

    public function updateFullSync(Request $request)
    {
        $storeId = $request->store_id;
        try {
            if ($storeId){
                $process = new \App\Jobs\ProcessFullSync($storeId);
                dispatch($process);
            }

            return response()->json([
                'success' => true,
                'message' => '',
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function updateSyncToMagento(Request $request)
    {
        $storeId = $request->store_id;
        try {
            if ($storeId){
                $process = new \App\Jobs\ProcessFullSyncMagento($storeId);
                dispatch($process);
            }

            return response()->json([
                'success' => true,
                'message' => '',
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function updateProductOptionStatus(Request $request)
    {
        try {

            switch ($request->type) {
                case 'legs':
                    Legs::where('id', $request->id)
                        ->update([
                            'is_active' => filter_var($request->is_active, FILTER_VALIDATE_BOOLEAN)
                        ]);

                    $isActive = Legs::select('is_active')
                        ->where('id', $request->id)
                        ->first()->is_active;
                    break;

                case 'cushioning':
                    Cushioning::where('id', $request->id)
                        ->update([
                            'is_active' => filter_var($request->is_active, FILTER_VALIDATE_BOOLEAN)
                        ]);

                    $isActive = Cushioning::select('is_active')
                        ->where('id', $request->id)
                        ->first()->is_active;

                    break;
                case 'extraOption':
                    ExtraOption::where('id', $request->id)
                        ->update([
                            'is_active' => filter_var($request->is_active, FILTER_VALIDATE_BOOLEAN)
                        ]);

                    $isActive = ExtraOption::select('is_active')
                        ->where('id', $request->id)
                        ->first()->is_active;

                    break;
                default:
                    $isActive = false;
                    break;
            }

            return response()->json([
                'id' => $request->id,
                'type' => $request->type,
                'is_active' => $isActive,
                'success' => true,
                'message' => 'Option successfully updated',
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }
}
