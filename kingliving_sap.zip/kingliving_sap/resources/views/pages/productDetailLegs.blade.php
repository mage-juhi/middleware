<?php
use App\Sap\OptionEntityValue;
use App\Sap\ProductOptionIndex;
use App\Sap\OptionTypeRequiredMapping;
$optionTypeValue = "";
if(isset($_GET['optionTypeValue'])){
    $optionTypeValue = $_GET['optionTypeValue'];
}
$sort = "";
if(isset($_GET['sort'])){
    $sort = $_GET['sort'];
}
$legs = ProductOptionIndex::sortOptions($product->legs,$product->id,'legs');
$cushionings = ProductOptionIndex::sortOptions($product->cushioning,$product->id,'cushionings');
$extraOptions = $product->extraOptions;
$exteriorLinks = $product->exteriorLinks;
$finishLinks = $product->finishLinks;
$materialTypes = DB::table('material_group_types')->get();
$materialLinks = $product->materialLinks;
$cylindoType = cylindoTypeList();
?>
@section('legs')
<?php if (count($legs) > 0) : ?>
 <li id = 'legs' class="border-table">
                <div class="move-heading"></div>
                <a class="card-link" data-toggle="collapse" href="#collapseOne">Legs</a>
                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                    <?php $OptionTypeRequiredMapping = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type', 'legs')->first();?>
                    <?php $optionTypeRequired = (isset($OptionTypeRequiredMapping->is_required)) ? $OptionTypeRequiredMapping->is_required : 1;?>
                    <?php $optionShowOnFrontEnd = \App\Sap\OptionShowFrontendMapping::where('product_id',$product->id)->where('option_type', 'legs')->first();?>
                    <form method="post" enctype="multipart/form-data" action="/optionTypeMappingSave">
                        <input type='hidden' value='0' name='is_required'>
                        <input type="checkbox" id="optionTypeRequired" name="is_required" value="1" <?php echo ($optionTypeRequired == 1) ?'checked' : '';?> onchange="this.form.submit()"><label for="is_required"> Is Required</label>
                        @if (count($legs) <= 1)
                            <input type="checkbox" name="show_option_on_frontend" value="1" style="margin-right:5px; margin-left:10px;"  <?php echo ($optionShowOnFrontEnd && $optionShowOnFrontEnd->is_show) ? 'checked' : '';?> onchange="this.form.submit()"><label for="show_option_on_frontend"> Always Show Option On Frontend (if only one option within)</label>
                        @endif()
                        <input type = "hidden" name="product_id" value="<?= $product->id ?>"/>
                        <input type = "hidden" name="option_type" value="legs"/>
                    </form>
                    <div style=" margin-left: 15px; " class="dropdown-action">
                        <div class="action-select-wrap-legs">
                            <button class="action-select-action-legs">
                            <span>Actions</span>
                            </button>
                            <div class="action-menu-items">
                                <ul class="action-menu">
                                    <li><span class="btn-des-legs action-menu-item">Update Description</span></li>
                                    <li><span class="btn-img-legs action-menu-item">Update Image</span></li>
                                    <li><span class="btn-name-legs action-menu-item">Update Name</span></li>
                                    <li><span class="btn-cylindo-data-legs action-menu-item">Update Cylindo Data</span></li>
                                    <li><span class="btn-cylindo-type-legs action-menu-item">Update Cylindo Type</span></li>
                                    <li><span class="btn-active-legs action-menu-item">Update Status</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>


                    <form action="/swatch-sort" method="post" enctype="multipart/form-data">
                        <div class="toolbar-sorter sorter">
                            <select id="sorter" name="sort" data-role="sorter" class="sorter-options" onchange='this.form.submit()'>
                                <?php
                                $sort = "";
                                if(isset($_GET['sort'])){
                                    $sort = $_GET['sort'];
                                }
                                ?>
<option value="#">Please choose sort</option>
<option <?php echo ($sort==1 && $optionTypeValue=='legs') ? "selected" : "" ?> value="1">A -> Z</option>
<option <?php echo ($sort==2 && $optionTypeValue=='legs') ? "selected" : "" ?> value="2">Z -> A</option>
</select>
<noscript><input type="submit" value="Submit"></noscript>
<input type = "hidden" name="option_type" value="legs"/>
<input type = "hidden" name="product_id" value="<?= $product->id ?>"/>
</div>
<table class="table table-leg sortable-index">
    <thead>
    <tr>
        <th class="data-grid-multicheck-cell">
            <div class="action-multicheck-wrap">
                <input id="select-all-legs" class="input-checkbox-legs" type="checkbox" >
                <button class="action-multicheck-toggle" data-toggle="dropdown"></button>
                <ul class="action-menu">
                    <li>
                        <span id="selectall-legs" class="action-menu-item">Select All</span>
                    </li>

                    <li>
                        <span id="deselect-all-legs" class="action-menu-item">Deselect All</span>
                    </li>

                </ul>
            </div>
        </th>
        <th>Legs ID</th>
        <th>Legs Code</th>
        <th>Legs Name</th>
        <th>Legs Custom Image</th>
    </tr>
    </thead>

    <?php foreach($legs as $key => $leg){?>
    <?php if ($leg->is_active == 0)
        continue;
    ?>
    <tbody id="<?php echo $leg->id;?>">
    <input type = "hidden" name="leg_id" value="<?php echo $leg->id;?>"/>
    <input type = "hidden" name="leg_name" value="<?php echo $leg->legs_name; ?>"/>
    <tr id="option-id-<?php echo $leg->id; ?>">
        <td class="data-grid-checkbox-cell">
            <label class="data-grid-checkbox-cell-inner">
            <input class="input-checkbox-legs" type="checkbox" value="<?php echo $leg->id; ?>"/>
            </label>
        </td>
        <td class="first-row"><div class="move-heading-item"></div><?php echo $leg->id;?></td>
        <td><?php echo $leg->legs_code; ?></td>
        <?php
            $get_name = OptionEntityValue::getValue($leg,'leg_name');
            $leg_name = $get_name ? $get_name->value : $leg->legs_name;
        ?>
        <td class="name-<?php echo $leg->id;?>"><?php echo $leg_name; ?></td>
        <td class="leg-custom-image-<?php echo $leg->id;?> StyleCustomImage">
            <?php if($leg->custom_image):?>
            <p><img style= "height:80px;" src="/upload/images/legs/<?php echo $leg->custom_image != null ? $leg->custom_image : "noimage.jpg" ?>"/></p>
            <?php endif;?>
        </td>
        <td><button type="button" class="btn btn-primary collapsed" data-toggle="collapse" data-target="#option-value-<?php echo $leg->id; ?>" aria-expanded="false">Edit</button></td>
    </tr>
    <tr id="option-value-<?php echo $leg->id; ?>" class="collapse edit-product-detail">
        <td colspan="10">
            <table class="table">
                <thead>
                <tr>
                    <th>Attribute Name</th>
                    <th>Attribute Value</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>Name</td>
                    <td><textarea id = "name-<?php echo $leg->id;?>" class="name-<?php echo $leg->id;?>" data-id="<?php echo $leg->id;?>" data-colour="<?php echo $leg->legs_code; ?>"><?php echo $leg_name; ?></textarea></td>
                </tr>
                <tr>
                    <td>Image</td>
                    <td id="custom-image-<?php echo $leg->id;?>" class="leg-custom-image-<?php echo $leg->id;?> StyleCustomImage">
                        <?php if($leg->custom_image):?>
                        <p ><img style= "height:80px;" src="/upload/images/legs/<?php echo $leg->custom_image != null ? $leg->custom_image : "noimage.jpg" ?>"/></p>
                        <a class="btn btn-danger deleteCustomImage" data-type="leg" data-id="<?php echo $leg->id;?>" href="javascript:void();">X</a>
                        <?php endif;?>
                    </td>
                </tr>
                <tr>
                    <td>Custom Image</td>
                    <td><input style=" width: 200px; " type="file" class="custom-image-<?php echo $leg->id;?>" name="legs_custom_image" value="<?php echo $leg->custom_image; ?>"/></td>
                </tr>
                <tr>
                    <td>Description</td>
                    <td><textarea class="description-<?php echo $leg->id;?>" data-id="<?php echo $leg->id;?>"><?php echo $leg->description; ?></textarea></td>
                </tr>
                <tr>
                    <td>Cylindo Data</td>
                    <td>
                        <div class="custom-select">
                            <select id="cylindo_type" data-id="<?php echo $leg->id;?>" name="cylindo_type" class="cylindo-type-<?php echo $leg->id;?>">
                                <option value="">CHOOSE CYLINDO TYPE</option>
                                <?php foreach ($cylindoType as $value) { ?>
                                <option <?= $leg->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <textarea style=" margin-top: 10px; " data-id="<?php echo $leg->id;?>" name="cylindo_data" class="cylindo-data-<?php echo $leg->id;?>"><?php echo $leg->cylindo_data; ?></textarea>
                        <div class="custom-select" style=" margin-top: 20px; ">
                            <select id="cylindo_type_optional" data-id="<?php echo $leg->id;?>" name="cylindo_type_optional" class="cylindo-type-optional-<?php echo $leg->id;?>">
                                <option value="">CHOOSE CYLINDO TYPE</option>
                                <?php foreach ($cylindoType as $value) { ?>
                                <option <?= $leg->cylindo_type_optional == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <textarea style=" margin-top: 10px; " data-id="<?php echo $leg->id;?>" name="cylindo_data_optional" class="cylindo-data-optional-<?php echo $leg->id;?>"><?php echo $leg->cylindo_data_optional; ?></textarea>
                    </td>
                </tr>
                <tr>
                    <td colspan="2"><button entity_field="leg_name"  entity_id="<?php echo $leg->id;?>" type="submit-edit" product-type="legs" data-id="<?php echo $leg->id;?>" class="btn btn-primary btn-save">Save</button></td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    </tbody>
    <?php } ?>

</table>
</form>
</div>
<div id="myModalDesLegs" class="modal fade" tabindex="-1">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h3 class="modal-title">Update Description</h3>
        <button type="button" class="close" data-dismiss="modal">
            &times;
        </button>
        </div>
        <div class="modal-body">
            <textarea id="des-leg"></textarea>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">
            Cancel
        </button>
        <button type="button" class="update-des-leg btn btn-primary">Save</button>
        </div>
    </div>
    </div>
</div>

<div id="myModalNameLegs" class="modal fade" tabindex="-1">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Update Name</h3>
            <button type="button" class="close" data-dismiss="modal">
                &times;
            </button>
        </div>
        <div class="modal-body">
            <input id="name-leg" type="text">
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">
            Cancel
        </button>
        <button type="button" entity_table="leg" entity_id="<?php echo $leg->id;?>" class="update-name-leg btn btn-primary">Save</button>
        </div>
    </div>
    </div>
</div>

<div id="myModalImageLegs" class="modal fade" tabindex="-1">
    <div class="modal-dialog">
    <div class="modal-content">
        <form method="post" action="" enctype="multipart/form-data">
        <div class="modal-header">
        <h3 class="modal-title">Update Image</h3>
        <button type="button" class="close" data-dismiss="modal">
            &times;
        </button>
        </div>
        <div class="modal-body">
            <input type="file" id="image-leg" name="legs_custom_image" value="<?php echo $leg->custom_image; ?>"/>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">
            Cancel
        </button>
        <button type="button" class="update-image-leg btn btn-primary">Save</button>
        </div>
        </form>
    </div>
    </div>
</div>

<div id="myModalCylindoDataLegs" class="modal fade" tabindex="-1">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h3 class="modal-title">Update Cylindo Data</h3>
        <button type="button" class="close" data-dismiss="modal">
            &times;
        </button>
        </div>
        <div class="modal-body">
            <textarea id="cylindoData-leg"></textarea>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">
            Cancel
        </button>
        <button type="button" class="update-cylindoData-leg btn btn-primary">Save</button>
        </div>
    </div>
    </div>
</div>

<div id="myModalCylindoTypeLegs" class="modal fade" tabindex="-1">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h3 class="modal-title">Update Cylindo Type</h3>
        <button type="button" class="close" data-dismiss="modal">
            &times;
        </button>
        </div>
        <div class="modal-body">
            <select name="cylindoType-legs" id="cylindoType-legs">
                <option value="">CHOOSE CYLINDO TYPE</option>
                <?php foreach ($cylindoType as $value) { ?>
                    <option <?= $leg->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">
            Cancel
        </button>
        <button type="button" class="update-cylindoType-legs btn btn-primary">Save</button>
        </div>
    </div>
    </div>
</div>

<div id="myModalActiveLegs" class="modal fade" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Update Status</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
            </div>
            <div class="modal-body">
                <select name="active-legs" id="active-legs">
                    <option value="">CHOOSE STATUS</option>
                    <option value="1">TRUE</option>
                    <option value="0">FALSE</option>
                </select>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-active-legs btn btn-primary">Save</button>
            </div>
        </div>
    </div>
</div>
</li>

 <?php endif ?>
 <script>
        jQuery(document).ready(function($) {

            $(".btn-des-legs").click(function(){
                $("#myModalDesLegs").modal('show');
            });

            $(".btn-name-legs").click(function(){
                $("#myModalNameLegs").modal('show');
            });

            $(".btn-img-legs").click(function(){
                $("#myModalImageLegs").modal('show');
            });


            $(".btn-cylindo-data-legs").click(function(){
                $("#myModalCylindoDataLegs").modal('show');
            });

            $(".btn-cylindo-type-legs").click(function(){
                $("#myModalCylindoTypeLegs").modal('show');
            });

            $(".btn-active-legs").click(function(){
                $("#myModalActiveLegs").modal('show');
            });

            $(".update-des-leg").click(function() {
                var des_leg = $("#des-leg").val();

                if(des_leg == '') {
                    alert("Please enter your content?");
                    return false;
                }
                var result = confirm("Are you sure?");
                if (result) {
                    var des = [];
                    $.each($(".table-leg tbody input[type='checkbox']:checked"), function() {
                        if ($(this).attr('id') != 'select-all-legs') des.push($(this).val());
                    });

                    $.ajax(
                    {
                        url: "/updateselect-legs-desc",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "leg_id" : des,
                            "description": des_leg,
                        },
                        success: function (response)
                        {
                            console.log(response);
                            $.each( des, function( key, value ) {
                                $(".description-"+value).val(des_leg);
                            });
                            alert("You have successfully updated!");
                            $("#myModalDesLegs").modal('hide');
                            $('#des-leg').val('');
                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                }
            });
            $(".update-name-leg").click(function() {
                var name_leg = $("#name-leg").val();

                if(name_leg == '') {
                    alert("Please enter your content?");
                    return false;
                }
                var result = confirm("Are you sure?");
                if (result) {
                    var name = [];
                    $.each($(".table-leg tbody input[type='checkbox']:checked"), function() {
                        if ($(this).attr('id') != 'select-all-legs') name.push($(this).val());
                    });

                    var entity_table = $(this).attr("entity_table");

                    $.ajax(
                    {
                        url: "/updateselect-legs-name",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "entity_id" : name,
                            "entity_table": entity_table,
                            "entity_field": "",
                            "entity_value"     : name_leg
                        },
                        success: function (response)
                        {
                            console.log(response);
                            $.each( name, function( key, value ) {
                                $("textarea.name-"+value).val(name_leg);
                                $(".name-"+value).html(name_leg);
                            });
                            alert("You have successfully updated!");
                            $("#myModalNameLegs").modal('hide');
                            $('#name-leg').val('');
                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                }
            });
            $(".update-image-leg").click(function() {
                var path = $("#image-leg").val();
                var image_cushioning = path.replace(/C:\\fakepath\\/, '');

                if(image_cushioning == '') {
                    alert("Please enter your content?");
                    return false;
                }
                var result = confirm("Are you sure?");
                if (result) {
                    var image = [];
                    $.each($(".table-leg tbody input[type='checkbox']:checked"), function() {
                        if ($(this).attr('id') != 'select-all-legs') image.push($(this).val());
                    });
                    var formData = new FormData();
                    var imageFile = $('#image-leg')[0].files;
                    formData.append('custom_image',imageFile[0]);
                    formData.append('leg_id',image);
                    var imageName = imageFile[0]["name"];

                    $.ajax(
                    {
                        url: "/updateselect-legs-image",
                        type: 'post',
                        dataType: "json",
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function (response)
                        {
                            console.log(response);
                            $.each( image, function( key, value ) {
                                $(".leg-custom-image-"+value).html('<p><img style= "height:80px;" src="/upload/images/legs/'+imageName+'"/></p>');;
                                $("#option-value-"+value+" .leg-custom-image-"+value).html('<p><img style= "height:80px;" src="/upload/images/legs/'+imageName+'"/></p><a class="btn btn-danger deleteCustomImage" data-type="leg" data-id="'+value+'" href="javascript:void();">X</a>');
                            });
                            $("#myModalImageLegs").modal('hide');
                            alert("You have successfully updated!");
                            //location.reload();

                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                }
            });
            $(".update-cylindoData-leg").click(function() {
                var cylindoData = $("#cylindoData-leg").val();
                if(cylindoData == '') {
                    alert("Please enter your content?");
                    return false;
                }
                var result = confirm("Are you sure?");
                if (result) {
                    var data = [];
                    $.each($(".table-leg input[type='checkbox']:checked"), function() {
                        data.push($(this).val());
                    });

                    $.ajax({
                        url: "/update-legs-cylindodata",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "leg_id" : data,
                            "cylindoData": cylindoData,
                        },
                        success: function (response)
                        {
                            console.log(response);
                            alert("You have successfully updated!");
                            $.each( data, function( key, value ) {
                                $(".cylindo-data-"+value).val(cylindoData);
                            });
                            $("#myModalCylindoDataLegs").modal('hide');
                            $('#cylindoData-leg').val('');

                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                }
            });
            $(".update-cylindoType-legs").click(function() {
                var cylindoType = $("#cylindoType-legs").val();
                if(cylindoType == '') {
                    alert("Please choose your option?");
                    return false;
                }
                var result = confirm("Are you sure?");
                if (result) {
                    var type = [];
                    $.each($(".table-leg tbody input[type='checkbox']:checked"), function() {
                        type.push($(this).val());
                    });

                    $.ajax(
                    {
                        url: "/update-legs-cylindotype",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "leg_id" : type,
                            "cylindoType": cylindoType,
                        },
                        success: function (response)
                        {
                            console.log(response);
                            $.each( type, function( key, value ) {
                                $(".cylindo-type-"+value).val(cylindoType);
                            });
                            $("#myModalCylindoTypeLegs").modal('hide');
                            $('#cylindoType-leg').val('');
                            alert("You have successfully updated!");
                            //location.reload();

                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                }
            });
            $(".update-active-legs").click(function() {
                var status = $("#active-legs").val();
                console.log(status);
                if(status == '') {
                    alert("Please choose your option?");
                    return false;
                }
                var result = confirm("Are you sure?");
                if (result) {
                    var data = [];
                    $.each($(".table-leg tbody input[type='checkbox']:checked"), function() {
                        data.push($(this).val());
                    });

                    $.ajax(
                    {
                        url: "/update-active-legs",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "leg_id" : data,
                            "status": status,
                        },
                        success: function (response)
                        {
                            console.log(response);
                            $.each( data, function( key, value ) {
                                if(status == true) {
                                    $(".leg-switch-on-"+value).removeClass("show hide").addClass('show');
                                    $(".leg-switch-off-"+value).removeClass("show hide").addClass('hide');
                                } else {
                                    $(".leg-switch-on-"+value).removeClass("show hide").addClass('hide');
                                    $(".leg-switch-off-"+value).removeClass("show hide").addClass('show');
                                }
                            });
                            $("#myModalActiveLegs").modal('hide');
                            alert("You have successfully updated!");
                            //location.reload();

                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                }
            });

            $("#legs .action-select-action-legs").click(function () {
                var isChecked = $("#legs .input-checkbox-legs").is(":checked");
                    if (!isChecked) {
                        return false;
                    }
            });

            $('#legs .action-select-wrap-legs').click(function(e) {
                e.stopPropagation();
                $(this).toggleClass('active');
            });

            $('body').click(function(e) {
                $("#legs .action-select-wrap-legs").removeClass('active');
            });


            $('#legs #select-all-legs').click(function(event) {
                if(this.checked) {
                    $('#legs .input-checkbox-legs').each(function() {
                        this.checked = true;
                    });
                } else {
                    $('#legs .input-checkbox-legs').each(function() {
                        this.checked = false;
                    });
                }
            });

            $('#legs #selectall-legs').click(function(event) {
                $('#legs .input-checkbox-legs').each(function() {
                    this.checked = true;
                });
            });

            $('#legs #deselect-all-legs').click(function(event) {
                $('#legs .input-checkbox-legs').each(function() {
                    this.checked = false;
                });
            });
        });
    </script>
@stop
