<?php

use Laravel\Lumen\Testing\DatabaseMigrations;
use Laravel\Lumen\Testing\DatabaseTransactions;

use \App\DB\Store;

use GuzzleHttp\Client as httpClient;
use GuzzleHttp\Pool as httpPool;
use GuzzleHttp\Psr7\Request as httpRequest;
use GuzzleHttp\Psr7\Uri as httpUri;
use GuzzleHttp\Exception\RequestException;

use App\Sap\Services\Index\Products;
use App\Sap\Product;
use App\Sap\Product\Material\Option;

class SapProductTest extends TestCase
{
    use DatabaseTransactions;
    private $storeIdArray = [1];


    /**
     * A basic test example.
     *
     * @return void
     */
    public function testConnections()
    {
        foreach ($this->storeIdArray as $storeId)
        {
            $product = App\Sap\Product::where('store_id',$storeId)->where('id',21)->first();

            $data = Products::convertData($product);

            //print_r($data);

            $this->assertIsArray($data);
        }
    }

    public function testIndexPackageProduct(){
        $product['item']['store_id'] = 1;
        $product['item']['sku'] = 'testSKU';
        $product['item']['name'] = 'testName';
        $product['item']['type'] = 'testType';
        $product['item']['item_group_name'] = 'test_item_group_name';
        $product['item']['sub_range_code'] = 'test_sub_range_code';
        $prodObj = new Product();
        $prodObj->indexPackageProduct($product);
        $this->seeInDatabase('package_products', ['sku' => 'testSKU']);
    }

    public function testIndexMaterial(){
        $product['item']['store_id'] = 1;
        $product['item']['sku'] = 'testSKU';
        $product['item']['name'] = 'testName';
        $product['item']['type'] = 'testType';
        $product['item']['item_group_name'] = 'test_item_group_name';
        $product['item']['sub_range_code'] = 'test_sub_range_code';

        $product['material']['CodeTest']['type'] = 'Fabric';
        $product['material']['CodeTest']['code'] = 'MaterialCodeTest';
        $product['material']['CodeTest']['range']['rangeCocde']['code'] = 'testCode';
        $product['material']['CodeTest']['range']['rangeCocde']['name'] = 'testName';
        $product['material']['CodeTest']['sell_price'] = '0';
        $product['material']['CodeTest']['meterage'] = '0';
        $product['material']['CodeTest']['king_guard_price'] = '0';
        $product['material']['CodeTest']['rrp_price'] = '0';
        $product['material']['CodeTest']['range']['rangeCocde']['colours']['colourValue'][0]['allow_king_guard']= '1';
        $product['material']['CodeTest']['range']['rangeCocde']['colours']['colourValue'][0]['colour_code']= 'testColour_code';
        $product['material']['CodeTest']['range']['rangeCocde']['colours']['colourValue'][0]['colour_name']= 'testColour_name';
        $product['material']['CodeTest']['range']['rangeCocde']['colours']['colourValue'][0]['colour_image']= 'testColour_image';

        $OptionObj = new Option();

        $OptionObj->indexMaterial($product, 1);

        $this->seeInDatabase('material_group_options', ['range_code' => 'testCode']);
        $this->seeInDatabase('material_group_options', ['name' => 'testName']);
        $this->seeInDatabase('material_group_option_value',['colour_name' => 'testColour_name']);
        $this->seeInDatabase('material_group_option_value',['colour_code' => 'testColour_code']);
    }

}
