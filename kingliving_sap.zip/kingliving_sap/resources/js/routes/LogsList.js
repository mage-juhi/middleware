import React from 'react';
import {Card, FilterType, ResourceList, Select, TextField, TextStyle,Layout,Page} from '@shopify/polaris';

const API_BASE_URL = '/logs/';
class LogsList extends React.Component{
    state = {
        selectedItems: [],
        sortValue: 'DATE_MODIFIED_DESC',
        searchValue: '',
        colls: null,
        isLoading: false,
        error: null,
        listItems: []
    };

    componentDidMount(){
        this.getSubscriptions();
    }

    async getSubscriptions(){
        if(!this.state.colls){
            try{
                this.setState({isLoading: true});
                const response = await fetch(API_BASE_URL + 'list');
                const subslist = await response.json();
                let newArr = []
                for (var i=0; i<subslist.collection.data.length; i++)
                {
                    subslist.collection.data[i].url= API_BASE_URL + 'view/' + subslist.collection.data[i].id;
                    newArr.push(subslist.collection.data[i]);

                }

                this.setState({ listItems:newArr, isLoading:false });
            }catch(err){
                this.setState({isLoading:false});
                console.error(err);
            }
        }else{
            console.log('exists');
        }
    }

    handleSearchChange = (searchValue) => {
        this.setState({searchValue});
    }
    handleSortChange = (sortValue) => {
        this.setState({sortValue});
    }
    handleSelectionChange = (selectedItems) => {
        this.setState({selectedItems});
    }

    renderItem = (item) => {
        const {id,url,label,method,event,level,message,caller} = item;

        const shortcutActions = id
            ? [{content: 'Remove', url: API_BASE_URL +'delete/' + id}]
            : null;

        //editables >> label, closure
        return (
            <ResourceList.Item
                id={id}
                url={url}
                label = {label}
                event = {event}
                level = {level}
                message = {message}
                caller = {caller}
                accessibilityLabel={`View details for ${label}`}
                shortcutActions = {shortcutActions}
                persistActions
            >
                <div className="bold">{message}</div><div>{caller}</div><div>{level}</div><div>{event}</div>
            </ResourceList.Item>
        );
    };

    render(){

        const resourceName = {
            singular: 'log',
            plural: 'logs'
        };

        const bulkActions = [
            {
                content: 'Delete Logs',
                onAction: () => console.log('Delete bugs'),
            }
        ];
        const primaryAction = {content: 'Clear All Logs', url: '/logs/clear'};
        const secondaryActions = [{content: 'Export Logs', icon: 'export'}];

        return (
            <Page
                title="Logs"
                primaryAction={primaryAction}
                secondaryActions={secondaryActions}
                description="A history of collected logs for the integration that have run over the last 7 days."
            >

                    <ResourceList
                        resourceName = {resourceName}
                        items = {this.state.listItems}
                        renderItem = {this.renderItem}
                        selectedItems = {this.state.selectedItems}
                        onSelectionChange = {this.handleSelectionChange}
                        bulkActions = {bulkActions}
                        sortValue = {this.state.sortValue}
                        onSortChange = {(selected) =>{
                            this.setState({sortValue : selected});
                            console.log(`Sort option chagned to ${selected}`);
                        }}

                    />

            </Page>
        );
    }
}

export default LogsList;