<?php
use App\Sap\OptionalUpgradeType;

$optionalUpgradeTypes = OptionalUpgradeType::get();
?>
@extends('layouts.default')
@section('content')

<div class="row">
 <div class="col-sm-8 offset-sm-2">
    <h1 class="display-3">Edit Optional Upgrades</h1>
  <div>
      <form id="updateOptionalUpgrades" method="post" action="{{route('updateOptionalUpgrades')}}" enctype="multipart/form-data">
            <input type="hidden"  name="id" value="<?php if (isset($optionalUpgrades)) echo $optionalUpgrades->id;?>">
            <input type="hidden" name="product_id" value="<?php if (isset($optionalUpgrades)) echo $optionalUpgrades->product_id;?>">
            <input type="hidden" name="store_id" value="<?php if (isset($optionalUpgrades)) echo $optionalUpgrades->store_id;?>"> 
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="name" value="<?php if (isset($optionalUpgrades)) echo $optionalUpgrades->name;?>">
            </div>
            <div class="form-group">    
                <label for="price">Price</label>
                <input type="text" class="form-control" name="price" value="<?php if (isset($optionalUpgrades)) echo $optionalUpgrades->price;?>">
            </div>
            <div class="form-group">
                <label for="type_id">Type:</label>
                <div class="input-group" style="display:flex">                    
                    <select class="select form-control" name="type_id" id="type">
                        <option value="">Please select type</option>
                        <?php foreach($optionalUpgradeTypes as $type):?>
                            <option value="<?= $type->id;?>" <?php if (isset($optionalUpgrades)&& $type->id == $optionalUpgrades->type_id) echo "selected";?>><?= $type->name?></option>
                        <?php endforeach;?>
                    </select>                  
                    <div class="input-group-append">
                        <a href="/optional-upgrade-type"  class="btn btn-outline-primary" type="button">Manager Type</a>
                    </div>
                </div>
            </div>
            <div class="form-group">    
                <label for="image">Image</label>
                <?php
                    if($optionalUpgrades->image):?>
                        <p><img style= "height:80px;" src="/upload/images/optionalUpgrade/<?php echo $optionalUpgrades->image ?>"/></p>    
                        <span class="file-name"> <?php echo $optionalUpgrades->image ?></span>                   
                    <?php endif;?>                
                <input type="file" class="form-control" name="image" value="" accept="image/png, image/jpeg">
            </div>
            <div class="form-group">
              <label for="active">Active:</label>
              <div class="col-sm-12 form-group">
	              <div class="col-sm-6 radio-inline">
	              		<input type="radio" id="yes" name="active" value="1" <?php if (isset($optionalUpgrades) && $optionalUpgrades->active == "1") echo "checked";?> /> Yes
	              </div>
	              <div class="radio-inline">
                        <input type="radio" id="no" name="active" value="0" <?php if (isset($optionalUpgrades) && $optionalUpgrades->active == "0")echo "checked";?> /> No
	              </div>
              </div>
          </div>
          <button style="margin-bottom:10px;" type="submit" class="btn btn-primary">Save</button>
      </form>
  </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function($) {
    $("#updateOptionalUpgrades").validate({
        rules: {
            name : {
                required: true,
                minlength: 3
            },      
            price : {
                required: true,
                number: true 
            },
            type_id: {
                required: true
            }
        }, 
        messages : {
            name: {
                required: "Please enter field name",
                minlength: "Name should be at least 3 characters"
            },
            price: {
                required: "Please enter field price",
                number: "Please enter the number"
       
            },
            type_id: {
                required: "Please select field type"
            } 
        }
  });
});
</script>
@stop