<?php

namespace App\Console\Commands;

use App\Console\AbstractCommand;
use App\DB\Logger;
use Monolog\Handler\StreamHandler;
use App\Sap\Services\Index\Products;

class MagentoFullProducts extends AbstractCommand
{
    const PROGRESS_BAR_FORMAT = 'debug';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:magento:full-product
                              {store_id : The integrations Store ID for the Sap Store}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync all product from middleware to magento';

    /**
     * Execute the console command.
     *
     * @param  \App\DripEmailer $drip
     * @return mixed
     */
    public function handle()
    {
        parent::handle();
        $logger = self::getLogger();

        $logger->info('Magento Full sync Products::handle() EXECUTED');
        $time_start = microtime(true);
        $store_id = $this->argument('store_id');
        Products::syncToMagento($store_id);

        $time_end = microtime(true);
        $execution_time = $time_end - $time_start;

        $logger->info("Magento Full sync Products COMPLETED in {$execution_time}");
        date_default_timezone_set('Australia/Sydney');
        $cron_run_at = date('m/d/Y h:i:s a', time());
        $logger->info("Magento Full sync Products Cronrun time at {$cron_run_at} store id: {$store_id}");
        return;
    }

    static private function getLogger()
    {
        $logger = new Logger('Magento_Log');
        $loggerFilename = storage_path(
            'logs/Magento_SyncProduct.log'
        );
        $logger->pushHandler(new StreamHandler($loggerFilename), Logger::INFO);

        return $logger;
    }
}