<?php
use App\Sap\ProductEntityValue;
use App\Sap\ProductAttribute;
session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}

$status = [
    0 => 'AVAILABLE',
    1 => 'SYNCED',
    2 => 'UNAVAILABLE',
    3 => 'DISABLED'
];

$sycnStatus = [
        0 => 'Syncing',
        1 => 'Synced'
]
?>
@extends('layouts.default')
@section('content')
    <?php
    $arr_id_attribute = array();
    foreach($listproductattributes as $key => $value){
        array_push($arr_id_attribute, $value->id);
    }
    ?>
    <div class="container mt-3">

        <div class="row">
            <div class="col-md-6">
                @include('includes.search')
            </div>
            <div class="col-md-6">
                <?php echo $package_products->appends(array('store' => $store_id))->links();?>
            </div>
        </div>
        <div>
            <form id="select-store" action="" method="post">
                <label for="store">Store</label>
                <select name="store">
                    <?php foreach($stores as $key => $store){?>
                    <option <?php if ($store_id == $store->id ) echo 'selected';?> value="<?php echo $store->id;?>"><?php echo $store->name.' '.$store->id;?></option>
                    <?php } ?>
                </select>
            </form>
        </div>


        <table class="table" id="package_products_table">
            <thead>
            <tr>
                <th>Id</th>
                <th>Sku</th>
                <th>Item Type</th>
                <th>Name</th>
                <th>Status</th>
                <th>Group Name</th>
                <th>Sub Range Code</th>
                <th>Magento Sync Status</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($package_products as $key => $product){?>
            <form action="/product/material-group-options/<?php echo $product->id;?>" method="get" enctype="multipart/form-data">
                <input type="hidden" id="store" name="store" value="<?php echo $store_id;?>">
                <tr >
                    <td><?php echo $product->id;?></td>
                    <td><?php echo $product->sku; ?></td>
                    <td><?php echo $product->item_type; ?></td>
                    <td><?php echo $product->name; ?></td>
                    <td><?php echo $status[$product->status]; ?></td>
                    <td><?php echo $product->item_group_name; ?></td>
                    <td><?php echo $product->sub_range_code; ?></td>
                    <td <?php if ($product->magento_sync_status == 1) echo 'style="color: green;"'; else echo 'style="color: orange;"'; ?>><?php echo $sycnStatus[$product->magento_sync_status]; ?></td>
                    <td>
                        <?php if ($product->has_material ==  1): ?>
                        <button type="submit" class="btn btn-primary">View Materials</button>
                        <?php endif; ?>
                        <button type="button" class="btn btn-primary" data-toggle="collapse" data-target="#list-product-entity-value-<?php echo $product->id;?>">Edit Magento Mappings</button>
                        <button type="button" class="btn btn-primary synctomagento" data-product-id="<?php echo $product->id;?>">Sync to Magento</button>
                        <button type="button" class="btn btn-primary syncfromsap" data-product-id="<?php echo $product->id;?>">Sync from SAP</button>
                        <?php if ($product->status) : ?>
                        <button type="button" class="btn btn-primary findinmagento" data-point-url="<?php echo str_replace("/rest/default/V1/middleware-connector/", "/middleware/index/", $current_store->domain) . "findproduct/"; ?>" data-sku="<?= $product->sku ?>">Find magento Product</button>
                        <?php endif; ?>
                        <a href="/product-detail/view/id/{{ $product->id }}" data-product-id="<?php echo $product->id;?>" class="btn btn-primary detail-product">View Product Options</a>
                    </td>
                </tr>
            </form>
            <form action="/updateProductEntity" class="form-updateProductEntity form-updateProductEntity-<?php echo $product->id;?>" method="post">
                <input type="hidden" name="store_id" value="<?php echo $store_id;?>">
                <input type="hidden" name="product_id" value="<?php echo $product->id;?>">
                <tr class="list-product-entity-value collapse" id="list-product-entity-value-<?php echo $product->id;?>">
                    <td colspan="10">
                        <table class="table">
                            <thead>
                            <tr>
                                <th>Attribute Name</th>
                                <th>Attribute Value</th>
                            </tr>
                            </thead>
                            <?php
                            $ProductEntityValue = ProductEntityValue::where('product_id',$product->id)->where('store_id',$store_id)->get();
                            if(count($ProductEntityValue) > 0)
                            {
                            $arr_attibute_id_product_entity_value = array();
                            foreach($ProductEntityValue as $l => $v)
                            {
                            array_push($arr_attibute_id_product_entity_value, $v->attribute_id);
                            $ProductAttribute = ProductAttribute::find($v->attribute_id);
                            if($ProductAttribute->is_required == "1")
                            {
                                $is_required = "required";
                            }
                            else
                            {
                                $is_required = "";
                            }
                            if($ProductAttribute->type == "int")
                            {
                                $is_type = "min='0'";
                                $set_type ="number";
                            }
                            else
                            {
                                $is_type = "minlength='3'";
                                $set_type ="text";
                            }
                            ?>
                            <tr>
                                <td><?php echo $ProductAttribute->name;?></td>
                                <?php if ($ProductAttribute->code == 'default_cover') :?>
                                    <td><select class="form-control" name="product_entity_value[<?php echo $v->id;?>]">
                                        <option value="Fabric" <?php if ($v->value == 'Fabric') echo 'selected'; ?>>Fabric</option>
                                        <option value="Leather" <?php if ($v->value == 'Leather') echo 'selected'; ?>>Leather</option>
                                    </select></td>
                                <?php else: ?>
                                <td><input class="form-control" type="<?php echo $set_type;?>" <?php echo $is_required;?> <?php echo $is_type;?> name="product_entity_value[<?php echo $v->id;?>]" value="<?php echo $v->value;?>"/></td>
                                <?php endif; ?>
                            </tr>
                            <?php
                            }
                            $array_diff = array_diff($arr_id_attribute, $arr_attibute_id_product_entity_value);
                            sort($array_diff);
                            if(count($array_diff) > 0)
                            {
                            for ($i=0; $i < count($array_diff) ; $i++) {
                            $NewProductAttribute = ProductAttribute::find($array_diff[$i]);
                            if($NewProductAttribute->is_required == "1")
                            {
                                $is_required = "required";
                            }
                            else
                            {
                                $is_required = "";
                            }
                            if($NewProductAttribute->type == "int")
                            {
                                $is_type = "min='0'";
                                $set_type ="number";
                            }
                            else
                            {
                                $is_type = "minlength='3'";
                                $set_type ="text";
                            }
                            ?>
                            <tr>
                                <td><?php echo $NewProductAttribute->name; ?></td>
                                <?php if ($NewProductAttribute->code == 'default_cover') :?>
                                    <td><select class="form-control" name="new_product_entity_value[<?php echo $NewProductAttribute->id;?>]">
                                        <option value="Fabric" <?php if ($NewProductAttribute->default_value == 'Fabric') echo 'selected'; ?>>Fabric</option>
                                        <option value="Leather" <?php if ($NewProductAttribute->default_value == 'Leather') echo 'selected'; ?>>Leather</option>
                                    </select></td>
                                <?php else: ?>
                                <td><input class="form-control" type="text" <?php echo $is_required;?> <?php echo $is_type;?> name="new_product_entity_value[<?php echo $NewProductAttribute->id;?>]" value="<?php echo $NewProductAttribute->default_value;?>"/></td>
                                <?php endif; ?>
                            </tr>
                            <?php
                            }
                            }
                            }
                            else
                            {
                            ?>
                            <?php foreach($listproductattributes as $k => $value){
                            if($value->is_required == "1")
                            {
                                $is_required = "required";
                            }
                            else
                            {
                                $is_required = "";
                            }
                            if($value->type == "int")
                            {
                                $is_type = "min='0'";
                                $set_type ="number";
                            }
                            else
                            {
                                $is_type = "minlength='3'";
                                $set_type ="text";
                            }
                            ?>
                            <tr>
                                <td><?php echo $value->name; ?></td>
                                <?php if ($value->code == 'default_cover') :?>
                                    <td><select class="form-control" name="new_product_entity_value[<?php echo $value->id;?>]">
                                        <option value="Fabric" <?php if ($value->default_value == 'Fabric') echo 'selected'; ?>>Fabric</option>
                                        <option value="Leather" <?php if ($value->default_value == 'Leather') echo 'selected'; ?>>Leather</option>
                                    </select></td>
                                <?php else: ?>
                                <td><input class="form-control" type="text" <?php echo $is_required;?> <?php echo $is_type;?> name="new_product_entity_value[<?php echo $value->id;?>]" value="<?php echo $value->default_value;?>"/></td>
                                <?php endif; ?>
                            </tr>
                            <?php } ?>
                            <?php } ?>
                            <tr>
                                <td colspan="2"><button type="submit" class="updateProductEntity btn btn-primary">Update</button></td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </form>
            <?php } ?>
            </tbody>
        </table>
    </div>
@stop
