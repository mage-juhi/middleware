<?php

namespace App\Shopify\Product\Image;

use Illuminate\Database\Eloquent\Model;

class Variant extends Model
{
    protected $table = 'shopify_product_image_variants';
    protected $primaryKey = 'id';

    protected $fillable = [
        'image_id',
        'variant_id'
    ];

    public $timestamps = false;

    public function Image()
    {
        return $this->belongsTo('App\Shopify\Product\Image', 'image_id');
    }
}
