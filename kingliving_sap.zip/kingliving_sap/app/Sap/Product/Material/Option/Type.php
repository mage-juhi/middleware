<?php

namespace App\Sap\Product\Material\Option;

use Illuminate\Database\Eloquent\Model;

class Type extends Model
{
    protected $table = 'material_group_types';
    protected $primaryKey = 'id';

    protected $fillable = [
        'title'
    ];




}