<?php
use App\Sap\OptionEntityValue;
use App\Sap\ProductOptionIndex;
use App\Sap\OptionTypeRequiredMapping;
$optionTypeValue = "";
if(isset($_GET['optionTypeValue'])){
    $optionTypeValue = $_GET['optionTypeValue'];
}
$sort = "";
if(isset($_GET['sort'])){
    $sort = $_GET['sort'];
}
$legs = ProductOptionIndex::sortOptions($product->legs,$product->id,'legs');
$cushionings = ProductOptionIndex::sortOptions($product->cushioning,$product->id,'cushionings');
$extraOptions = $product->extraOptions;
$exteriorLinks = $product->exteriorLinks;
$finishLinks = $product->finishLinks;
$materialTypes = DB::table('material_group_types')->get();
$materialLinks = $product->materialLinks;
$cylindoType = cylindoTypeList();
?>
@section('extraOptions')
    <?php if (count($extraOptions) > 0) : ?>
    <li id = 'extraOptions' class="border-table">
        <?php
        $type = [];
        foreach($extraOptions as $key => $extraOption){
            // if ($extraOption->is_active == 0)
            //     continue;
            $name = OptionEntityValue::getValue($extraOption,'extra_option_type');
            $type[] = $name ? $name->value : $extraOption->type;
        }
        $type = array_unique($type);
        ?>
        <div class="move-heading"></div>
        <a class="card-link" data-toggle="collapse" href="#collapseThree">Extra Options</a>
        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
            <div class="dropdown-action">
                <div style=" margin-left: 15px; " class="action-select-wrap-extraOptions">
                    <button class="action-select-action-extraOptions">
                    <span>Actions</span>
                    </button>
                    <div class="action-menu-items">
                        <ul class="action-menu">
                            <li><span class="btn-des-extraoption action-menu-item">Update Description</span></li>
                            <li><span class="btn-img-extraoption action-menu-item">Update Image</span></li>
                            <li><span class="btn-name-extraoption action-menu-item">Update Name</span></li>
                            <li><span class="btn-cylindo-data-extraoption action-menu-item">Update Cylindo Data</span></li>
                            <li><span class="btn-cylindo-type-extraoption action-menu-item">Update Cylindo Type</span></li>
                            <li><span class="btn-active-extraoption action-menu-item">Update Status</span></li>
                            <li><span class="btn-type-extraoption action-menu-item">Update Type</span></li>
                        </ul>
                    </div>
                </div>
            </div>
            <?php $i = 0;  foreach ($type as $index => $value) { ?>
            <?php
                $mutilInput = "";
                if($i > 0) {
                    $mutilInput = "mutil-input";
                }
            ?>
            <?php $OptionTypeRequiredMapping = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type', $value)->first();?>
            <?php $optionTypeRequired = (isset($OptionTypeRequiredMapping->is_required)) ? $OptionTypeRequiredMapping->is_required : 0;?>
            <?php $optionShowOnFrontEnd = \App\Sap\OptionShowFrontendMapping::where('product_id',$product->id)->where('option_type', $value)->first();?>
           <?php $extraOptionType = ProductOptionIndex::sortOptions($extraOptions,$product->id,$value); ?>
            <form method="post" enctype="multipart/form-data" action="/optionTypeMappingSave">
                <input type='hidden' value='0' name='is_required'>
                <input type="checkbox" id="optionTypeRequired" name="is_required" value="1" <?php echo ($optionTypeRequired == 1) ?'checked' : '';?> onchange="this.form.submit()"><label for="is_required"> Is Required</label>
                @if (count($extraOptionType) <= 1)
                    <input type="checkbox" name="show_option_on_frontend" value="1" style="margin-right:5px; margin-left:10px;"  <?php echo ($optionShowOnFrontEnd && $optionShowOnFrontEnd->is_show) ? 'checked' : '';?> onchange="this.form.submit()"><label for="show_option_on_frontend"> Always Show Option On Frontend (if only one option within)</label>
                @endif()
                <input type = "hidden" name="product_id" value="<?= $product->id ?>"/>
                <input type = "hidden" name="option_type" value="{{$value}}"/>
            </form>
            <form action="/swatch-sort" method="post" enctype="multipart/form-data">
                <h3><?= $value ?></h3>
                <div class="toolbar-sorter sorter">
                    <select id="sorter" name="sort" data-role="sorter" class="sorter-options" onchange='this.form.submit()'>
                        <?php
                        $sort = "";
                        if(isset($_GET['sort'])){
                            $sort = $_GET['sort'];
                        }
                        ?>
                        <option value="#">Please choose sort</option>
                        <option <?php echo ($sort==1 && $optionTypeValue==$value) ? "selected" : "" ?> value="1">A -> Z</option>
                        <option <?php echo ($sort==2 && $optionTypeValue==$value) ? "selected" : "" ?> value="2">Z -> A</option>
                    </select>
                    <input type = "hidden" name="option_type" value="extraOptions"/>
                    <input type = "hidden" name="option_type_value" value="<?= $value; ?>"/>
                    <input type = "hidden" name="product_id" value="<?= $product->id ?>"/>
                    <noscript><input type="submit" value="Submit"></noscript>
                </div>
                <table class="table table-extraOptions sortable-index">
                    <thead>
                    <tr>
                        <th class="data-grid-multicheck-cell">
                            <div class="action-multicheck-wrap <?= $mutilInput ?>">
                                <input id="select-all-extraOptions" class="input-checkbox-extraOptions" type="checkbox" >
                                <button class="action-multicheck-toggle" data-toggle="dropdown"></button>
                                <ul class="action-menu">
                                    <li>
                                        <span id="selectall-extraOptions" class="action-menu-item">Select All</span>
                                    </li>

                                    <li>
                                        <span id="deselect-all-extraOptions" class="action-menu-item">Deselect All</span>
                                    </li>

                                </ul>
                            </div>
                        </th>
                        <th>Extra Options ID</th>
                        <th>Extra Options Sku</th>
                        <th>Extra Options Name</th>
                        <th>Is Required</th>
                        <th>Cylindo Type</th>
                        <th>Cylindo Data</th>
                        <th>Extra Options Custom Image</th>
                        <th>Edit</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <?php
                    $i++;
                    foreach($extraOptionType as $key => $extraOption){
                        $name = OptionEntityValue::getValue($extraOption,'extra_option_type');
                        $extraOptionType = $name ? $name->value : $extraOption->type;
                    ?>
                    <?php if ($extraOptionType == $value ){ ?>
                    <tbody id="<?php echo $extraOption->id;?>">
                    <tr id="option-id-<?php echo $extraOption->id; ?>">
                        <td class="data-grid-checkbox-cell">
                            <label class="data-grid-checkbox-cell-inner">
                            <input class="input-checkbox-extraOptions" type="checkbox" value="<?php echo $extraOption->id;?>"/>
                            </label>
                        </td>
                        <td class="first-row"><div class="move-heading-item"></div><?= $extraOption->id;?></td>
                        <td><?= $extraOption->sku;?></td>
                        <?php  $get_extraOption_name = OptionEntityValue::getValue($extraOption,'extra_option_name');
                               $extra_option_name = $get_extraOption_name ? $get_extraOption_name->value : $extraOption->name;?>
                        <td class="name-<?php echo $extraOption->id;?>"><?= $extra_option_name?></td>
                        <td><?= $extraOption->is_required== '1'  ? 'Yes' :'No'; ?></td>
                        <td><?= $extraOption->cylindo_type;?></td>
                        <td><?= $extraOption->cylindo_data;?></td>
                        <td class="extraOption-custom-image-<?php echo $extraOption->id;?> StyleCustomImage">
                            <?php if($extraOption->custom_image):?>
                            <p><img style= "height:80px;" src="/upload/images/extraOption/<?php echo $extraOption->custom_image?>"/></p>
                            <?php endif;?>
                        </td>
                        <td><button type="button" class="btn btn-primary collapsed" data-toggle="collapse" data-target="#option-value-<?php echo $extraOption->id; ?>" aria-expanded="false">Edit</button></td>
                        <td>
                            <div class="extra-option-switch-on-<?php echo $extraOption->id; ?> <?php echo $extraOption->is_active ? 'show' : 'hide';?>">
                                <svg
                                        data-id="<?php echo $extraOption->id; ?>"
                                        data-active="<?php echo $extraOption->is_active; ?>"
                                        class="extra-option-active-toggle extra-option-<?php echo $extraOption->id?>" style="margin-top: -8px; cursor: pointer" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 511.999 511.999">
                                    <path d="M376.5 120.5h-241C60.785 120.5 0 181.285 0 256s60.785 135.5 135.5 135.5h241c74.715 0 135.5-60.785 135.5-135.5s-60.785-135.5-135.5-135.5zm0 241C318.327 361.5 271 314.174 271 256c0-58.172 47.327-105.5 105.5-105.5S482 197.828 482 256c0 58.174-47.327 105.5-105.5 105.5z" fill="#2e6da4" data-original="#000000" xmlns="http://www.w3.org/2000/svg"/>
                                </svg>
                            </div>
                            <div class="extra-option-switch-off-<?php echo $extraOption->id; ?> <?php echo $extraOption->is_active ? 'hide' : 'show';?>">
                                <svg
                                        data-id="<?php echo $extraOption->id; ?>"
                                        data-active="<?php echo $extraOption->is_active; ?>"
                                        class="extra-option-active-toggle extra-option-<?php echo $extraOption->id?>" style="margin-top: -8px; cursor: pointer" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 511.999 511.999">
                                    <path d="M376.499 120.5h-241C60.784 120.5 0 181.286 0 256s60.784 135.5 135.499 135.5h241c74.715 0 135.5-60.785 135.5-135.5s-60.785-135.5-135.5-135.5zm-241 241.001C77.326 361.501 30 314.173 30 256s47.326-105.5 105.499-105.5c58.173 0 105.5 47.327 105.5 105.5s-47.327 105.501-105.5 105.501z" fill="#9f9f9f" data-original="#000000" xmlns="http://www.w3.org/2000/svg"/>
                                </svg>
                            </div>
                        </td>
                    </tr>
                    <tr id="option-value-<?php echo $extraOption->id; ?>" class="collapse edit-product-detail">
                        <td colspan="10">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Attribute Name</th>
                                    <th>Attribute Value</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Name</td>
                                    <?php  $get_extraOption_name = OptionEntityValue::getValue($extraOption,'extra_option_name');
                                    $extra_option_name = $get_extraOption_name ? $get_extraOption_name->value : $extraOption->name;?>
                                    <td><textarea id="name-<?php echo $extraOption->id;?>"  class="name-<?php echo $extraOption->id;?>"><?php echo $extra_option_name; ?></textarea></td>
                                </tr>
                                <tr>
                                    <td>Image</td>
                                    <td id="custom-image-<?php echo $extraOption->id;?>" class="extraOption-custom-image-<?php echo $extraOption->id;?> StyleCustomImage">
                                        <?php if($extraOption->custom_image):?>
                                        <p><img style= "height:80px;" src="/upload/images/extraOption/<?php echo $extraOption->custom_image ?>"/></p>
                                        <a class="btn btn-danger deleteCustomImage" data-type="extraOption" data-id="<?php echo $extraOption->id;?>" href="javascript:void();">X</a>
                                        <?php endif;?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Custom Image</td>
                                    <td><input style=" width: 200px; " type="file" class="custom-image-<?php echo $extraOption->id;?>" name="extraOption_custom_image" value="<?php echo $extraOption->custom_image; ?>"/></td>
                                </tr>

                                <tr>
                                    <td>Description</td>
                                    <td><textarea class="description-<?php echo $extraOption->id;?>" data-id="<?php echo $extraOption->id;?>"><?php echo $extraOption->description; ?></textarea></td>
                                </tr>
                                <tr>
                                    <td>Cylindo Data</td>
                                    <td>
                                        <div class="custom-select">
                                            <select name="cylindo_type" id="cylindo_type" class="cylindo-type-<?php echo $extraOption->id;?>">
                                                <option value="">CHOOSE CYLINDO TYPE</option>
                                                <?php foreach ($cylindoType as $cylindo) { ?>
                                                <option <?= $extraOption->cylindo_type == $cylindo ? 'selected' : ''; ?> value="<?= $cylindo ?>"><?= $cylindo ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <textarea style=" margin-top: 10px; " name="cylindo_data"  class="cylindo-data-<?php echo $extraOption->id;?>"><?php echo $extraOption->cylindo_data; ?></textarea>
                                        <div class="custom-select" style=" margin-top: 20px; ">
                                            <select name="cylindo_type_optional" id="cylindo_type_optional" class="cylindo-type-optional-<?php echo $extraOption->id;?>">
                                                <option value="">CHOOSE CYLINDO TYPE</option>
                                                <?php foreach ($cylindoType as $cylindo) { ?>
                                                <option <?= $extraOption->cylindo_type_optional == $cylindo ? 'selected' : ''; ?> value="<?= $cylindo ?>"><?= $cylindo ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <textarea style=" margin-top: 10px; " name="cylindo_data_optional"  class="cylindo-data-optional-<?php echo $extraOption->id;?>"><?php echo $extraOption->cylindo_data_optional; ?></textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2"><button type="submit-edit" product-type="extraOption" data-id="<?php echo $extraOption->id;?>" entity-data-id="extra_option_name_<?php echo $extraOption->id;?>" entity_field="extra_option_name"  entity_id="<?php echo $extraOption->id;?>" class="btn btn-primary btn-save">Save</button></td>
                                </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    </tbody>
                    <?php } ?>
                    <?php } ?>
                </table>
            </form>
            <?php } ?>
        </div>
         <div id="myModalDesExtraoption" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h3 class="modal-title">Update Description</h3>
            <button type="button" class="close" data-dismiss="modal">
                &times;
            </button>
            </div>
            <div class="modal-body">
                <textarea id="des-extraoption"></textarea>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                Cancel
            </button>
            <button type="button" class="update-des-extraoption btn btn-primary">Save</button>
            </div>
        </div>
        </div>
    </div>

    <div id="myModalNameExtraoption" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h3 class="modal-title">Update Name</h3>
            <button type="button" class="close" data-dismiss="modal">
                &times;
            </button>
            </div>
            <div class="modal-body">
                <input id="name-extraoption" type="text">
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                Cancel
            </button>
            <button type="button" entity_table="extraOption" entity_id="<?php echo $extraOption->id;?>" class="update-name-extraoption btn btn-primary">Save</button>
            </div>
        </div>
        </div>
    </div>

    <div id="myModalTypeExtraoption" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post" action="">
                    <div class="modal-header">
                        <h3 class="modal-title">Update Type</h3>
                        <button type="button" class="close" data-dismiss="modal">
                            &times;
                        </button>
                    </div>
                    <div class="modal-body">
                        <input type="text" id="extraoption_type_text" class="form-control" name="extraoption_type" value="" placeholder="Type" />
                        <small class="update-type-error text-danger py-3"></small>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            Cancel
                        </button>
                        <button type="button" class="update-type-extraoption btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="myModalImageExtraoption" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="" enctype="multipart/form-data">
            <div class="modal-header">
            <h3 class="modal-title">Update Image</h3>
            <button type="button" class="close" data-dismiss="modal">
                &times;
            </button>
            </div>
            <div class="modal-body">
                <input type="file" id="image-extraoption" name="extraoption_custom_image" value="<?php echo $extraOption->custom_image; ?>"/>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                Cancel
            </button>
            <button type="button" class="update-image-extraoption btn btn-primary">Save</button>
            </div>
            </form>
        </div>
        </div>
    </div>

    <div id="myModalCylindoDataExtraoption" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h3 class="modal-title">Update Cylindo Data</h3>
            <button type="button" class="close" data-dismiss="modal">
                &times;
            </button>
            </div>
            <div class="modal-body">
                <textarea id="cylindoData-extraoptions"></textarea>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                Cancel
            </button>
            <button type="button" class="update-cylindoData-extraoptions btn btn-primary">Save</button>
            </div>
        </div>
        </div>
    </div>

    <div id="myModalCylindoTypeExtraoption" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h3 class="modal-title">Update Cylindo Type</h3>
            <button type="button" class="close" data-dismiss="modal">
                &times;
            </button>
            </div>
            <div class="modal-body">
                <select name="cylindoType-extraoptions" id="cylindoType-extraoptions">
                    <option value="">CHOOSE CYLINDO TYPE</option>
                    <?php foreach ($cylindoType as $value) { ?>
                        <option <?= $extraOption->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                Cancel
            </button>
            <button type="button" class="update-cylindoType-extraoptions btn btn-primary">Save</button>
            </div>
        </div>
        </div>
    </div>

    <div id="myModalActiveExtraoption" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Update Status</h3>
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>
                <div class="modal-body">
                    <select name="active-extraOptions" id="active-extraOptions">
                        <option value="">CHOOSE STATUS</option>
                        <option value="1">TRUE</option>
                        <option value="0">FALSE</option>
                    </select>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        Cancel
                    </button>
                    <button type="button" class="update-active-extraOptions btn btn-primary">Save</button>
                </div>
            </div>
        </div>
    </div>

    <div id="myModalTypeExtraoption" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post" action="">
                    <div class="modal-header">
                        <h3 class="modal-title">Update Type</h3>
                        <button type="button" class="close" data-dismiss="modal">
                            &times;
                        </button>
                    </div>
                    <div class="modal-body">
                        <input type="text" id="extraoption_type_text" class="form-control" name="extraoption_type" value="" placeholder="Type" />
                        <small class="update-type-error text-danger py-3"></small>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            Cancel
                        </button>
                        <button type="button" class="update-type-extraoption btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </li>

    <?php endif; ?>
    <script>
        jQuery(document).ready(function($) {
            $('.table-extraOptions .extra-option-active-toggle').click(function(e) {
                e.preventDefault();
                var id = $(this).attr('data-id');
                var attribute = $(this);
                var active = parseInt($(this).attr('data-active'));
                var active = ! active;

                $.ajax({
                    url: '/product/option/status',
                    type: 'put',
                    dataType: "json",
                    data: {
                        'id': id,
                        'type': 'extraOption',
                        'is_active': active
                    },
                    success: function (response) {
                        if (response.success) {
                            $(`.extra-option-${id}`).attr('data-active', response.is_active);

                            if (response.is_active) {
                                $(`.extra-option-switch-off-${id}`).removeClass('show').addClass('hide');
                                $(`.extra-option-switch-on-${id}`).removeClass('hide').addClass('show');
                            } else {
                                $(`.extra-option-switch-on-${id}`).removeClass('show').addClass('hide');
                                $(`.extra-option-switch-off-${id}`).removeClass('hide').addClass('show');
                            }
                        }
                    },
                    error: function(error) {
                        alert(JSON.parse(error.responseText).message);
                    }
                });
            });
            $(".btn-des-extraoption").click(function(){
                $("#myModalDesExtraoption").modal('show');
            });

            $(".btn-name-extraoption").click(function(){
                $("#myModalNameExtraoption").modal('show');
            });

            $(".btn-img-extraoption").click(function(){
                $("#myModalImageExtraoption").modal('show');
            });

            $(".btn-active-extraoption").click(function(){
                $("#myModalActiveExtraoption").modal('show');
            });

            $(".btn-cylindo-data-extraoption").click(function(){
                $("#myModalCylindoDataExtraoption").modal('show');
            });

            $(".btn-cylindo-type-extraoption").click(function(){
                $("#myModalCylindoTypeExtraoption").modal('show');
            });

            $(".btn-type-extraoption").click(function(){
                $("#myModalTypeExtraoption").modal('show');
            });

            $(".update-des-extraoption").click(function() {
                var des_extraoptions = $("#des-extraoption").val();

                if(des_extraoptions == '') {
                    alert("Please enter your content?");
                    return false;
                }
                var result = confirm("Are you sure?");
                if (result) {
                    var des = [];
                    $.each($(".table-extraOptions tbody input[type='checkbox']:checked"), function() {
                        if ($(this).attr('id') != 'select-all-extraOptions') des.push($(this).val());
                    });

                    $.ajax(
                    {
                        url: "/updateselect-extraoptions-desc",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "extraoption_id" : des,
                            "description": des_extraoptions,
                        },
                        success: function (response)
                        {
                            console.log(response);
                            $.each( des, function( key, value ) {
                                $(".description-"+value).val(des_extraoptions);
                            });
                            alert("You have successfully updated!");
                            $("#myModalDesExtraoption").modal('hide');
                            $('#des-extraoptions').val('');
                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                }
            });
            $(".update-name-extraoption").click(function() {
                var name_extraoptions = $("#name-extraoption").val();

                if(name_extraoptions == '') {
                    alert("Please enter your content?");
                    return false;
                }
                var result = confirm("Are you sure?");
                if (result) {
                    var name = [];
                    $.each($(".table-extraOptions tbody input[type='checkbox']:checked"), function() {
                        if ($(this).attr('id') != 'select-all-extraOptions') name.push($(this).val());
                    });

                    var entity_table = $(this).attr("entity_table");
                    console.log(name,name_extraoptions);
                    $.ajax(
                    {
                        url: "/updateselect-extraoptions-name",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "entity_id" : name,
                            "entity_table": entity_table,
                            "entity_field": "",
                            "entity_value"     : name_extraoptions
                        },
                        success: function (response)
                        {
                            console.log(response);
                            $.each( name, function( key, value ) {
                                $("textarea.name-"+value).val(name_extraoptions);
                                $(".name-"+value).html(name_extraoptions);
                            });
                            alert("You have successfully updated!");
                            $("#myModalNameExtraoption").modal('hide');
                            $('#name-extraoptions').val('');
                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                }
            });
            $(".update-image-extraoption").click(function() {
                var path = $("#image-extraoption").val();
                var image_extraoption = path.replace(/C:\\fakepath\\/, '');

                if(image_extraoption == '') {
                    alert("Please enter your content?");
                    return false;
                }
                var result = confirm("Are you sure?");
                if (result) {
                    var image = [];
                    $.each($(".table-extraOptions tbody input[type='checkbox']:checked"), function() {
                        if ($(this).attr('id') != 'select-all-extraOptions') image.push($(this).val());
                    });
                    var formData = new FormData();
                    var imageFile = $('#image-extraoption')[0].files;
                    formData.append('custom_image',imageFile[0]);
                    formData.append('extraoption_id',image);
                    var imageName = imageFile[0]["name"];

                    $.ajax(
                    {
                        url: "/updateselect-extraoptions-image",
                        type: 'post',
                        dataType: "json",
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function (response)
                        {
                            console.log(response);
                            console.log(response);
                            $.each( image, function( key, value ) {
                                $(".extraOption-custom-image-"+value).html('<p><img style= "height:80px;" src="/upload/images/extraOption/'+imageName+'"/></p>');;
                                $("#option-value-"+value+" .extraOption-custom-image-"+value).html('<p><img style= "height:80px;" src="/upload/images/extraOption/'+imageName+'"/></p><a class="btn btn-danger deleteCustomImage" data-type="extraOption" data-id="'+value+'" href="javascript:void();">X</a>');
                            });
                            $("#myModalImageExtraoption").modal('hide');
                            alert("You have successfully updated!");
                            //location.reload();

                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                }
            });
            $(".update-cylindoData-extraoptions").click(function() {
                var cylindoData = $("#cylindoData-extraoptions").val();
                if(cylindoData == '') {
                    alert("Please enter your content?");
                    return false;
                }
                var result = confirm("Are you sure?");
                if (result) {
                    var data = [];
                    $.each($(".table-extraOptions tbody input[type='checkbox']:checked"), function() {
                        data.push($(this).val());
                    });

                    $.ajax(
                            {
                                url: "/update-extraoptions-cylindodata",
                                type: 'post',
                                dataType: "json",
                                data: {
                                    "extraoption_id" : data,
                                    "cylindoData": cylindoData,
                                },
                                success: function (response)
                                {
                                    console.log(response);
                                    alert("You have successfully updated!");
                                    $.each( data, function( key, value ) {
                                        $(".cylindo-data-"+value).val(cylindoData);
                                    });
                                    $("#myModalCylindoDataExtraoption").modal('hide');
                                    $('#cylindoData-extraoptions').val('');
                                },
                                error: function(xhr) {
                                    console.log(xhr.responseText);
                                }
                            });
                }
            });

            $(".update-cylindoType-extraoptions").click(function() {
                var cylindoType = $("#cylindoType-extraoptions").val();
                if(cylindoType == '') {
                    alert("Please choose your option?");
                    return false;
                }
                var result = confirm("Are you sure?");
                if (result) {
                    var type = [];
                    $.each($(".table-extraOptions tbody input[type='checkbox']:checked"), function() {
                        type.push($(this).val());
                    });

                    $.ajax(
                            {
                                url: "/update-extraoptions-cylindotype",
                                type: 'post',
                                dataType: "json",
                                data: {
                                    "extraoption_id" : type,
                                    "cylindoType": cylindoType,
                                },
                                success: function (response)
                                {
                                    console.log(response);
                                    $.each( type, function( key, value ) {
                                        $(".cylindo-type-"+value).val(cylindoType);
                                    });
                                    $("#myModalCylindoTypeExtraoption").modal('hide');
                                    $('#cylindoType-extraoptions').val('');
                                    alert("You have successfully updated!");

                                },
                                error: function(xhr) {
                                    console.log(xhr.responseText);
                                }
                            });
                }
            });
            $(".update-active-extraOptions").click(function() {
                var status = $("#active-extraOptions").val();
                if(status == '') {
                    alert("Please choose your option?");
                    return false;
                }
                var result = confirm("Are you sure?");
                if (result) {
                    var data = [];
                    $.each($("input[type='checkbox']:checked"), function() {
                        data.push($(this).val());
                    });

                    $.ajax(
                    {
                        url: "/update-active-extraOptions",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "extraoption_id" : data,
                            "status": status,
                        },
                        success: function (response)
                        {
                            console.log(response);
                            $.each( data, function( key, value ) {
                                if(status == true) {
                                    $(".extra-option-switch-on-"+value).removeClass("show hide").addClass('show');
                                    $(".extra-option-switch-off-"+value).removeClass("show hide").addClass('hide');
                                } else {
                                    $(".extra-option-switch-on-"+value).removeClass("show hide").addClass('hide');
                                    $(".extra-option-switch-off-"+value).removeClass("show hide").addClass('show');
                                }
                            });
                            $("#myModalActiveExtraoption").modal('hide');
                            alert("You have successfully updated!");
                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                }
            });

            $('.update-type-extraoption').click(() => {
                const extraOptionType = $('#extraoption_type_text').val();
                if (extraOptionType === '') {
                    $('.update-type-error').text('Type is required.');
                    return false;
                }
                const isConfirm = confirm("Are you sure?");
                if (isConfirm) {
                    let extraOptionIds = [];
                    $.each($(".table-extraOptions tbody input[type='checkbox']:checked"), function() {
                        if ($(this).attr('id') != 'select-all-extraOptions') extraOptionIds.push($(this).val());
                    });
                    if (extraOptionIds.length === 0) {
                        $('.update-type-error').text('Please select a record.');
                        return false;
                    }
                    $.ajax({
                        url: "/updateselect-extraoptions-type",
                        type: 'post',
                        dataType: "json",
                        data: {
                            extra_option_ids : extraOptionIds,
                            type: extraOptionType,
                        },
                        success: function (response) {
                            $("#myModalTypeExtraoption").modal('hide');
                            alert("You have successfully updated!");
                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                }
            });

            $("#extraOptions .action-select-extraOptions").click(function () {
                var isChecked = $("#legs .input-checkbox-extraOptions").is(":checked");
                    if (!isChecked) {
                        return false;
                    }
            });

            $('#extraOptions .action-select-wrap-extraOptions').click(function(e) {
                e.stopPropagation();
                $(this).toggleClass('active');
            });

            $('body').click(function(e) {
                $("#extraOptions .action-select-wrap-extraOptions").removeClass('active');
            });


            $('#extraOptions #select-all-extraOptions').click(function(event) {
                if(this.checked) {
                    $('#extraOptions .input-checkbox-extraOptions').each(function() {
                        this.checked = true;
                    });
                } else {
                    $('#extraOptions .input-checkbox-extraOptions').each(function() {
                        this.checked = false;
                    });
                }
            });

            $('#extraOptions #selectall-extraOptions').click(function(event) {
                $('#extraOptions .input-checkbox-extraOptions').each(function() {
                    this.checked = true;
                });
            });

            $('#extraOptions #deselect-all-extraOptions').click(function(event) {
                $('#extraOptions .input-checkbox-extraOptions').each(function() {
                    this.checked = false;
                });
            });
        });
    </script>
@stop
