<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateShowOptionOnFrontendTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('option_show_on_frontend_mapping', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('store_id');
            $table->unsignedBigInteger('product_id');
            $table->string('option_type');
            $table->boolean('is_show')->default(0)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('option_show_on_frontend_mapping');
    }
}
