<?php
use App\Sap\OptionEntityValue;
use App\Sap\ProductOptionIndex;
use App\Sap\OptionTypeRequiredMapping;
$optionTypeValue = "";
if(isset($_GET['optionTypeValue'])){
    $optionTypeValue = $_GET['optionTypeValue'];
}
$sort = "";
if(isset($_GET['sort'])){
    $sort = $_GET['sort'];
}
$legs = ProductOptionIndex::sortOptions($product->legs,$product->id,'legs');
$cushionings = ProductOptionIndex::sortOptions($product->cushioning,$product->id,'cushionings');
$extraOptions = $product->extraOptions;
$exteriorLinks = $product->exteriorLinks;
$finishLinks = $product->finishLinks;
$materialTypes = DB::table('material_group_types')->get();
$materialLinks = $product->materialLinks;
$cylindoType = cylindoTypeList();
?>
@section('finish')
    <?php if (count($finishLinks) > 0) : ?>
    <li id = 'finish' class="border-table">
        <div class="move-heading"></div>
        <a class="card-link" data-toggle="collapse" href="#collapseFive">Finish</a>
        <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
            <?php  foreach ($finishLinks as $index => $finishLink) {
            $finish = $finishLink->finish;?>
            <?php if ($finish->is_active == 0)
                continue;
            ?>
            <?php $OptionTypeRequiredMapping = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type', $finish->finish_code)->first();?>
            <?php $optionTypeRequired = (isset($OptionTypeRequiredMapping->is_required)) ? $OptionTypeRequiredMapping->is_required : 1;?>
            <?php $optionShowOnFrontEnd = \App\Sap\OptionShowFrontendMapping::where('product_id',$product->id)->where('option_type', $finish->finish_code)->first();?>
            <?php $finishColors = ProductOptionIndex::sortOptions($finish->finishColor,$product->id,$finish->finish_name); ?>
            <form method="post" enctype="multipart/form-data" action="/optionTypeMappingSave">
                <input type='hidden' value='0' name='is_required'>
                <input type="checkbox" id="optionTypeRequired" name="is_required" value="1" <?php echo ($optionTypeRequired == 1) ?'checked' : '';?> onchange="this.form.submit()"><label for="is_required"> Is Required</label>
                @if (count($finishColors) <= 1)
                    <input type="checkbox" name="show_option_on_frontend" value="1" style="margin-right:5px; margin-left:10px;"  <?php echo ($optionShowOnFrontEnd && $optionShowOnFrontEnd->is_show) ? 'checked' : '';?> onchange="this.form.submit()"><label for="show_option_on_frontend"> Always Show Option On Frontend (if only one option within)</label>
                @endif()
                <input type = "hidden" name="product_id" value="<?= $product->id ?>"/>
                <input type = "hidden" name="option_type" value="{{$finish->finish_code}}"/>
            </form>
            <form action="/swatch-sort" method="post" enctype="multipart/form-data">
                <div class="toolbar-sorter sorter">
                    <select id="sorter" name="sort" data-role="sorter" class="sorter-options" onchange='this.form.submit()'>
                        <?php
                        $sort = "";
                        if(isset($_GET['sort'])){
                            $sort = $_GET['sort'];
                        }
                        ?>
                        <option value="#">Please choose sort</option>
                        <option <?php echo ($sort==1 && $optionTypeValue==$finish->finish_name) ? "selected" : "" ?> value="1">A -> Z</option>
                        <option <?php echo ($sort==2 && $optionTypeValue==$finish->finish_name) ? "selected" : "" ?> value="2">Z -> A</option>
                    </select>
                    <input type = "hidden" name="option_type" value="finish"/>
                    <input type = "hidden" name="option_type_value" value="<?= $finish->finish_name; ?>"/>
                    <input type = "hidden" name="product_id" value="<?= $product->id ?>"/>
                    <noscript><input type="submit" value="Submit"></noscript>
                </div>
                <table class="table table-finish sortable-index">
                    <thead>
                    <h3><?= $finish->finish_name; ?></h3>
                    <tr>
                        <th>Finish ID</th>
                        <th>Finish Code</th>
                        <th>Finish Name</th>
                        <th>Finish Custom Image</th>
                    </tr>
                    </thead>
                    <?php
                    foreach($finishColors as $key => $finishColor){?>
                    <tbody id="<?php echo $finishColor->id;?>">
                    <tr id="option-id-<?php echo $finishColor->id; ?>">
                        <td class="first-row"><div class="move-heading-item"></div><?= $finishColor->id;?></td>
                        <td><?= $finishColor->colour_code;?></td>
                        <?php
                            $getObj = OptionEntityValue::getValue($finishColor, 'finish_colour_name', $product->id);
                            $finishColor->colour_name = $getObj ? $getObj->value : $finishColor->colour_name;
                            $getObj = OptionEntityValue::getValue($finishColor, 'cylindo_data', $product->id);
                            $finishColor->cylindo_data = $getObj ? $getObj->value : $finishColor->cylindo_data;
                            $getObj = OptionEntityValue::getValue($finishColor, 'cylindo_type', $product->id);
                            $finishColor->cylindo_type = $getObj ? $getObj->value : $finishColor->cylindo_type;
                            $getObj = OptionEntityValue::getValue($finishColor, 'cylindo_type_optional', $product->id);
                            $finishColor->cylindo_type_optional = $getObj ? $getObj->value : $finishColor->cylindo_type_optional;
                            $getObj = OptionEntityValue::getValue($finishColor, 'cylindo_data_optional', $product->id);
                            $finishColor->cylindo_data_optional = $getObj ? $getObj->value : $finishColor->cylindo_data_optional;
                        ?>
                        <td><?= $finishColor->colour_name;?></td>
                        <td class="finish-custom-image-<?php echo $finishColor->id;?> StyleCustomImage">
                            <?php if($finishColor->custom_image):?>
                            <p><img style= "height:80px;" src="<?php echo "/upload/images/finish/".$finishColor->custom_image; ?>"/></p>
                            <?php endif;?>
                        </td>
                        <td><button type="button" class="btn btn-primary collapsed" data-toggle="collapse" data-target="#option-value-<?php echo $finishColor->id; ?>" aria-expanded="false">Edit</button></td>
                    </tr>
                    <tr id="option-value-<?php echo $finishColor->id; ?>" class="collapse edit-product-detail">
                        <td colspan="10">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Attribute Name</th>
                                    <th>Attribute Value</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Name</td>
                                    <td><textarea id = "name-<?php echo $finishColor->id;?>" class="name-<?php echo $finishColor->id;?>" data-id="<?php echo $finishColor->id;?>" data-colour="<?php echo $finishColor->colour_code; ?>"><?php echo $finishColor->colour_name; ?></textarea></td>
                                </tr>
                                <tr>
                                    <td>Cylindo Data</td>
                                    <td>
                                        <div class="custom-select">
                                            <select id="cylindo_type" data-id="<?php echo $finishColor->id;?>" name="cylindo_type" class="cylindo-type-<?php echo $finishColor->id;?>">
                                                <option value="">CHOOSE CYLINDO TYPE</option>
                                                <?php foreach ($cylindoType as $value) { ?>
                                                <option <?= $finishColor->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <textarea style=" margin-top: 10px; " data-id="<?php echo $finishColor->id;?>" name="cylindo_data" class="cylindo-data-<?php echo $finishColor->id;?>"><?php echo $finishColor->cylindo_data; ?></textarea>
                                        <div class="custom-select" style=" margin-top: 20px; ">
                                            <select id="cylindo_type_optional" data-id="<?php echo $finishColor->id;?>" name="cylindo_type_optional" class="cylindo-type-optional-<?php echo $finishColor->id;?>">
                                                <option value="">CHOOSE CYLINDO TYPE</option>
                                                <?php foreach ($cylindoType as $value) { ?>
                                                <option <?= $finishColor->cylindo_type_optional == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <textarea style=" margin-top: 10px; " data-id="<?php echo $finishColor->id;?>" name="cylindo_data_optional" class="cylindo-data-optional-<?php echo $finishColor->id;?>"><?php echo $finishColor->cylindo_data_optional; ?></textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2"><button entity_id="<?php echo $product->id;?>" type="submit-edit" product-type="finish" data-id="<?php echo $finishColor->id;?>" class="btn btn-primary btn-save">Save</button></td>
                                </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    </tbody>
                    <?php } ?>
                </table>
            </form>
            <?php } ?>
        </div>
    </li>
    <?php endif;?>
@stop
