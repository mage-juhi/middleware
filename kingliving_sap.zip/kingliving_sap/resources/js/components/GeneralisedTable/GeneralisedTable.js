import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './Table.css';
import { Card, Stack, Pagination, SkeletonDisplayText} from '@shopify/polaris';

export default class GeneralisedTable extends Component {
    static propTypes = {
        tableHeaders: PropTypes.array.isRequired,                 // array of header labels. Should be an array of strings
        sortDirection: PropTypes.func,
        attributeRenderFunctions: PropTypes.array.isRequired,     // array of render functions. function accepts an item from tableData, index of the item in the current page and the active offset (if pagination is enabled) as param and returns markup for that row
        tableData: PropTypes.array.isRequired,                    // the actual data array
        onDataExhausted: PropTypes.func,                          // relevant when pagination is enabled. Tells what to do when the current dataset is exhausted. (Make API call with updated offset and concat data to the tableData prop)
        doPagination: PropTypes.bool,                             // should pagination handles be shown
        pageLimit: PropTypes.number,                              // how many items to show on a page
        activeOffset: PropTypes.number,                           // if data should be shown starting from an offset
        noDataPlaceholderText: PropTypes.string,                  // what text to show when there is no data
        fetchInProgress: PropTypes.bool                           // boolean flag that denotes if currently fetching is going on
    }

    state = {
        items  : {},
        sorting : "v",
    }

    constructor(props){
        super(props);
        this.loadingContent = [];
        this.currentOffset = 0;

        for(let header of props.tableHeaders){
            this.loadingContent.push(<td key={header}><SkeletonDisplayText /></td>)
        }

        this.state.items = this.compileTableData(props);
        //this.onNextPage = this.onNextPage.bind(this);
        //this.onPreviousPage = this.onPreviousPage.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        this.setState({items: this.compileTableData(nextProps)});
    }
    
    /*onNextPage(){
        this.currentOffset += this.props.pageLimit;
        if(this.props.tableData.length - this.currentOffset == 0){      // eg tableData has 15 elements. we are on page 2. 15 - 10 + 10 != 0, meaning we dont have enough elements
            this.props.onDataExhausted(this.currentOffset);
        }else{
            this.setState({items: this.compileTableData(this.props)});
        }
    }
    onPreviousPage(){
        if(this.currentOffset - this.props.pageLimit >= 0){
            this.currentOffset -= this.props.pageLimit;
            this.setState({items: this.compileTableData(this.props)});
        }
    }*/
    compileTableData(props){
        let currentTableData;
        if(props.doPagination){
            let offset = (props.activeOffset ? props.activeOffset : this.currentOffset);    // in case we paginate and fetch next page data
            let limit = offset + props.pageLimit;
            currentTableData = props.tableData.slice(offset, limit);
        } else{
            currentTableData =  props.tableData;
        }
        let formattedTableData = [], formattedRow, columnContent, rowIndex = 0;
        for(let dataRow of currentTableData){
            formattedRow = [];
            for(let renderFn of props.attributeRenderFunctions){
                formattedRow.push(renderFn(dataRow, rowIndex, this.currentOffset));
            }
            formattedTableData.push(formattedRow);
            rowIndex++;
        }

        return formattedTableData;
    }

    invokeSort = (canSort) => {
        if(canSort) {
            this.props.sortDirection();
            var mark = this.state.sorting;
            if(mark == 'v')
                mark = '^';
            else
                mark = 'v';
            this.setState({sorting : mark});
        }

        return false;
    }

    render() {
        return (
            <div>
                <table className="results Polaris">
                    <thead>
                    <tr>
                        {
                            this.props.tableHeaders.map((header) => {
                                //return <th key={header.title} onClick={this.invokeSort.bind(this,header.sortable)} data-sorting={(header.sortable) ? this.props.sortDirection :''}> {header.title} </th>;
                                return <th key={header.title} onClick={this.invokeSort.bind(this,header.sortable)}> {header.title} {(header.sortable) ? this.state.sorting : ''} </th>;
                            })
                        }
                    </tr>
                    </thead>
                    <tbody>
                    {
                        this.props.fetchInProgress
                            ?
                            <tr>{this.loadingContent}</tr>
                            :
                            (
                                this.state.items.length > 0 ?
                                    this.state.items.map((row, i) =>
                                        <tr key={i}>
                                            {row.map((col, j) =>
                                                <td key={i+"_" +j}>{col}</td>
                                            )}
                                        </tr>
                                    )
                                    : (
                                    <tr>
                                        <td style={{textAlign: 'center'}} colSpan={this.props.tableHeaders.length}>
                                            {this.props.noDataPlaceholderText ?
                                                this.props.noDataPlaceholderText
                                                : "No data found."}
                                        </td>
                                    </tr>
                                )
                            )
                    }
                    </tbody>
                </table>
                <br />
                {/*
                    this.props.doPagination ?
                        <Stack distribution="center">
                            <Pagination
                                hasPrevious={this.currentOffset !== 0}
                                onPrevious={() => {this.onPreviousPage()}}
                                hasNext={this.state.items.length >= this.props.pageLimit}
                                onNext={() => {this.onNextPage()}} />
                        </Stack>
                        : ""
                 */ }
                <br />
            </div>
        )
    }
}