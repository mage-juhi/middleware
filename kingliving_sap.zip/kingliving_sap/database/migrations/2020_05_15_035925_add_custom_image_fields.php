<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddCustomImageFields extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        if (Schema::hasTable('material_group_option_value')) {
            //
            Schema::table('material_group_option_value', function (Blueprint $table) {
                $table->string('custom_image');
            });
        }

        if (Schema::hasTable('material_group_options')) {
            //
            Schema::table('material_group_options', function (Blueprint $table) {
                $table->string('custom_image');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        //
        if (Schema::hasTable('material_group_option_value')) {
            Schema::table('material_group_option_value', function (Blueprint $table) {
                $table->dropColumn('custom_image');
            });
        }

        if (Schema::hasTable('material_group_options')) {
            Schema::table('material_group_options', function (Blueprint $table) {
                $table->dropColumn('custom_image');
            });
        }

    }
}
