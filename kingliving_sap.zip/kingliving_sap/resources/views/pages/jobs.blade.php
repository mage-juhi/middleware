<?php

session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}

if (aclToClient($_SESSION['username']))
    header("Location:/dashboard");
?>
@extends('layouts.default')
@section('content')

<div class="container mt-3">
    <div>
        <form action="/jobs/triggerSyncMagento">
            <label for="store">Store</label>
            <select name="store">
                <?php foreach($stores as $key => $store){?>
                    <option value="<?php echo $store->id;?>"><?php echo $store->name .' '.$store->id;?></option>
                <?php } ?>
            </select>
            <button type="submit" class="btn btn-primary">Push a Trigger to sync from Magento</button>
        </form>
    </div>
    </br>
    </br>
    <div>
        <form action="/jobs/triggerSyncSap">
            <label for="store">Store</label>
            <select name="store">
                <?php foreach($stores as $key => $store){?>
                    <option value="<?php echo $store->id;?>"><?php echo $store->name .' '.$store->id;?></option>
                <?php } ?>
            </select>
            <button type="submit" class="btn btn-primary">Push a Trigger to sync from SAP</button>
        </form>
    </div>
    <table class="table">
        <thead>
        <tr>
            <th>Id</th>
            <th>Queue</th>
            <th>Payload</th>
            <th>Attempts</th>
            <th>Reserved at</th>
            <th>Available at</th>
            <th>Created at</th>
        </tr>
        </thead>
        <tbody>
                <?php foreach($jobs as $key => $job){?>
                <tr>
                    <td><?php echo $job->id;?></td>
                    <td><?php echo $job->queue; ?></td>
                    <td style="word-break:break-all;"><pre style=" max-width: 300px; overflow-x: scroll"><?php echo print_r(json_decode($job->payload),true); ?></pre></td>
                    <td><?php echo $job->attempts; ?></td>
                    <td><?php echo date('Y-m-d H:i:s', $job->reserved_at); ?></td>
                    <td><?php echo date('Y-m-d H:i:s', $job->available_at); ?></td>
                    <td><?php echo date('Y-m-d H:i:s', $job->created_at); ?></td>
                </tr>
                <?php } ?>
        </tbody>
    </table>
</div>
@stop
