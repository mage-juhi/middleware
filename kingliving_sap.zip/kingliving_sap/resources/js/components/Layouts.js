import React from 'react';
import {Layout,Card} from '@shopify/polaris';
import Navbar from './Navbar';
import Home from './Home/Home';
import Order from './Orders/Order';
import Logs from './Logs/Logs';
import LogsView from './Logs/LogsView';
import Settings from './Settings/Settings';
import Subscription from './Subscriptions/Subscription';
import SubscriptionForm from './Subscriptions/SubscriptionForm';

class Layouts extends React.Component{

    render(){
        const reactRoot = document.getElementById('app');
        const item = reactRoot.getAttribute('data-view');

        let view = 'home';

        switch (item){
            case 'ordersBoard':
                view = <Order />;
                break;
            case 'subscriptionsBoard':
                view = <Subscription />;
                break;
            case 'subscriptionForm':
                view = <SubscriptionForm />;
                break;
            case 'logsBoard':
                view = <Logs />;
                break;
            case 'logsView':
                view = <LogsView />;
                break;
            case 'settingsBoard':
                view = <Settings />;
                break;
            default:
                view = <Home />;
                break;
        }

        return (
            <Layout>
                <Layout.Section>
                    <Card sectioned>
                        <div className="container">
                            {view}
                        </div>
                    </Card>
                </Layout.Section>
                <Layout.Section secondary>
                    <Card title="App Menus" sectioned>
                        <Navbar />
                    </Card>
                </Layout.Section>
            </Layout>
        );
    }
}

export default Layouts;