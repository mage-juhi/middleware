<?php

namespace App\Listeners\Shopify;

use App\Events\Shopify\ProductsUpdate;

use App\Services\Base\Indexer\ProductIndex;

use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

use App\DB\Logger;
use Monolog\Handler\StreamHandler;

class IndexProduct implements ShouldQueue
{
    public $connection = 'database';
    public $queue = 'shopify_webhook';

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  ExampleEvent  $event
     * @return void
     */
    public function handle($event)
    {
        // This must not be removed as it sets the store context for the listener
        $store = $event->store;
        if (!$store) {
            throw new \Exception('The event object did not contain a valid store context');
        }

        // The store is now Authorized
        authoriseStore($store->id);

        $logger = self::getLogger();

        $debugObj = [
            'store_singleton' => store()->toArray(),
            'product' => $event->product
        ];
        $logger->debug('Webhook Event Listener Hit', $debugObj);
        
        // Add Listener Logic Here
        ProductIndex::indexSingleProduct($event->product);

    }

    static protected function getLogger()
    {
        $loggerName = str_replace('\\', '_', get_called_class());

        $logger = new Logger($loggerName);
        $loggerFilename = storage_path(
            "logs/{$loggerName}.log"
        );
        $logger->pushHandler(new StreamHandler($loggerFilename), Logger::INFO);

        return $logger;
    }
}
