import React from 'react';
import {Button, Form, FormLayout, TextField, Heading, Layout, Page,TextContainer, TextStyle} from '@shopify/polaris';


const API_BASE_URL = '/logs/';

class LogsView extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            data: params[0].data,
            id: params[0].id,
            name: params[0].name,
            created_at: params[0].created_at
        }
    }

    componentDidMount() {
        // const projectId = this.props.match.params.id
        // this.setState({id:projectId});
    }

    handleSubmit = (event) => {
        console.log('fire up');
    };

    handleChange = (field) => {
        return (value) => this.setState({[field]: value});
    };



    render() {

        const {data, id, name,created_at} = this.state;
        const primaryAction = {content: 'Delete Log'};
        const secondaryActions = [{content: 'Download', icon: 'import', url: '/logs/download/' + id}];
        // const projectId = this.props.match.params.id
        var str = JSON.stringify(JSON.parse(data), null, 2);

        return (
            <Page
                title="Log Detail"
                breadcrumbs={[{content: 'Back to Logs', url: '/logs'}]}
                primaryAction={{
                    content: 'Delete Log',
                    url: '/logs/delete/' + id,
                }}
                secondaryActions={secondaryActions}>

                <Heading>View Log Data For {name}</Heading>
                <TextContainer>
                    <Heading>Logged: {created_at}</Heading>
                    <pre><TextStyle variation="code">{ str }</TextStyle></pre>
                </TextContainer>
            </Page>

        );
    }
}

export default LogsView;