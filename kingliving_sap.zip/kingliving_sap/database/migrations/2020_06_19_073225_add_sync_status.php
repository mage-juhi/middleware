<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddSyncStatus extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        if (Schema::hasTable('package_product_parent')) {
            //
            Schema::table('package_product_parent', function (Blueprint $table) {
                $table->integer('sync_status');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        if (Schema::hasTable('package_product_parent')) {
            Schema::table('package_product_parent', function (Blueprint $table) {
                $table->dropColumn('sync_status');
            });
        }
    }
}
