
<?php

session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}

if (aclToClient($_SESSION['username']))
    header("Location:/dashboard");
?>
@extends('layouts.default')
@section('content')
    <div class="container">
        <div class="dropdown-action">
            <div class="action-select-wrap">
                <button class="action-select">
                <span>Actions</span>
                </button>
                <div class="action-menu-items">
                    <ul class="action-menu">
                        <li><span class="btn-full action-menu-item">Full Sync</span></li>
                        <li><span class="btn-magento action-menu-item">Sync to Magento</span></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>Select</th>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Domain</th>
                    <th style="text-align: center;">Magento Store Code</th>
                    <th style="text-align: center;">Total</th>
                    <th style="text-align: center;">Active</th>
                    <th style="text-align: center;">Synced</th>
                    <th style="text-align: center;">SAP Status</th>
                    <th style="text-align: center;">Magento Status</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach($stores as $key => $store){
                    $list = DB::table('package_products')->where('store_id',$store->id)->get();
                    $status = DB::table('package_products')->where('store_id',$store->id)->where('status',1)->get();
                    $sync = DB::table('package_products')->where('store_id',$store->id)->where('magento_sync_status',1)->where('status',1)->get();

                    $sap = DB::table('package_product_parent')->where('store_id',$store->id)->where('sync_status',0)->get();
                    $fullJobs = DB::table('jobs')->where('queue', '=', 'full_sync_country')->where('attempts',1)->where('payload','like','%storeId\\\\";i:'.$store->id.'%')->count();
                    $subrangeJob = DB::table('jobs')->where('queue', '=', 'product_sync_from_sub_range')->where('attempts',1)->where('payload','like','%storeId\\\\";i:'.$store->id.'%')->count();
                    $sapColor = '#38b83a';
                    $sapStatus = 'Synced';
                    $jobStatus = 'Synced';
                    if ($fullJobs > 0 || (count($sap) > 0 && $subrangeJob > 0)){
                        $sapColor = 'orange';
                        $jobStatus = 'syncing';
                        $sapStatus = 'Syncing ' . count(DB::table('package_product_parent')->where('store_id',$store->id)->where('sync_status',1)->get()) . '/' . count(DB::table('package_product_parent')->where('store_id',$store->id)->get());
                    }

                    $magentoJobs = DB::table('jobs')->where('queue', '=', 'full_sync_magento')->where('attempts',1)->where('payload','like','%storeId\\\\";i:'.$store->id.'%')->count();
                    $magentoProgress = count($sync) . '/' . count($status);
                    $magentoColor = '#38b83a';
                    $magentoStatus = 'Synced ' . $magentoProgress;
                    if ($fullJobs > 0 || $magentoJobs > 0 || (count($sap) == 0 && $subrangeJob > 0)){
                        $magentoColor = 'orange';
                        $magentoStatus = 'Syncing ' . $magentoProgress;
                        $jobStatus = 'syncing';
                    }

                ?>
                <tr data-store="<?php echo $store->name;?>">
                    <td class="data-grid-checkbox-cell">
                        <label class="data-grid-checkbox-cell-inner">
                        <input class="input-checkbox__dashboard input-checkbox" type="checkbox" name="check-for__action" value="<?php echo $store->id;?>">
                        </label>
                    </td>
                    <td><?php echo $store->id;?></td>
                    <td><?php echo $store->name; ?></td>
                    <td><?php echo $store->domain; ?></td>
                    <td style="text-align: center;"><?php echo $store->magento_store_code; ?></td>
                    <td style="text-align: center;"><?php echo count($list); ?></td>
                    <td style="text-align: center;"><?php echo count($status); ?></td>
                    <td style="text-align: center;"><?php echo count($sync); ?></td>
                    <td style="text-align: center;">
                        <span style="color: <?php echo $sapColor ?>;"> <?php echo $sapStatus;?></span>
                    </td>
                    <td style="text-align: center;">
                        <span style="color: <?php echo $magentoColor ?>;"> <?php echo $magentoStatus;?></span>
                    </td>
                </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('.input-checkbox__dashboard').click(function(){
            var jobsCount = <?php echo DB::table('jobs')->where('queue', '=', 'full_sync_country')->where('attempts',1)->count(); ?>;
            if(jobsCount){
                var storeName = $('.storewise-synclist tr').find("td[class='syncing']").closest('tr').attr('data-store');
                alert('Please wait..Syncing is still running for - ' + storeName);
                $(this).prop('checked', false);
            }
        });

        $(".btn-full").click(function(){
            var storeId = $("input[type='checkbox']:checked").val();
            if(storeId= '' || storeId == undefined){
                alert('Please select one of the store to proceed.');
                return;
            }

            var result = confirm("Are you sure?");
            if(result){
                var id = $("input[type='checkbox']:checked").val();
                $.ajax(
                {
                    url: "/trigger-full-sync",
                    type: 'post',
                    dataType: "json",
                    data: {
                        "store_id" : id
                    },
                    success: function (response)
                    {
                        console.log(response);
                        alert("Full sync has been run!");
                        location.reload();

                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    }
                });
            }
        });

        $(".btn-magento").click(function(){
            var storeId = $("input[type='checkbox']:checked").val();
            if(storeId= '' || storeId == undefined){
                alert('Please select one of the store to proceed.');
                return;
            }

            var result = confirm("Are you sure?");
            if(result){
                var id = $("input[type='checkbox']:checked").val();
                $.ajax(
                {
                    url: "/trigger-sync-to-magento",
                    type: 'post',
                    dataType: "json",
                    data: {
                        "store_id" : id
                    },
                    success: function (response)
                    {
                        console.log(response);
                        alert("Full sync to magento has been run!");
                        location.reload();

                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    }
                });
            }
        });
    });
    </script>
@stop
