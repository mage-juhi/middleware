<p>Hi,</p>
<p>King Living SAP Job is failed to process.</p>
<p> <b>Store ID:</b> {{ $data['job']['store_id'] }}</p>
<p> <b>Attempts:</b> {{ $data['job']['attempts'] }}</p>
<p> <b>Queue:</b>   {{ $data['job']['queue'] }}</p>
@if (isset($data['job']['subrange']))
    <p> <b>Subrange:</b> {{ $data['job']['subrange'] }}</p>
@endif
@if (isset($data['job']['product_id']))
    <p> <b>Product ID:</b> {{ $data['job']['product_id'] }}</p>
@endif
<p> <b>Error Message:</b>  {{ $data['error_message'] }}</p>

<p>[This is an automate message - please do not reply directly to this email.]</p>