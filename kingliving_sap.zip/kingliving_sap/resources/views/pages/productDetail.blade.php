<?php
use App\Sap\OptionEntityValue;
use App\Sap\ProductOptionIndex;
use App\Sap\ProductOptionTypeIndex;

if(!isset($_SESSION['username'])){
    header("Location:/");
}
$optionTypeValue = "";
if(isset($_GET['optionTypeValue'])){
    $optionTypeValue = $_GET['optionTypeValue'];
}
$sort = "";
if(isset($_GET['sort'])){
    $sort = $_GET['sort'];
}
$legs = ProductOptionIndex::sortOptions($product->legs,$product->id,'legs');
$cushionings = ProductOptionIndex::sortOptions($product->cushioning,$product->id,'cushionings');
$extraOptions = $product->extraOptions;
$optionalUpgrades = $product->optionalUpgrades;
$exteriorLinks = $product->exteriorLinks;
$finishLinks = $product->finishLinks;
$materialTypes = DB::table('material_group_types')->get();
$materialLinks = $product->materialLinks;
$cylindoType = cylindoTypeList();

?>
@extends('layouts.productDetail')
@section('before')
    @include('pages.productDetailBefore')
    @if (count($productTypeOptions) > 0)
        @foreach ($productTypeOptions as $productTypeOption)
@section($productTypeOption)
    <?php $pageName = 'pages.productDetail'.ucfirst($productTypeOption); ?>
    @include($pageName)
    @endforeach
    @else
@section('legs')
    @include('pages.productDetailLegs')
@section('cushionings')
    @include('pages.productDetailCushionings')
@section('exterior')
    @include('pages.productDetailExterior')
@section('extraOptions')
    @include('pages.productDetailExtraOptions')
@section('finish')
    @include('pages.productDetailFinish')
@section('cover')
    @include('pages.productDetailCover')
@section('optionalUpgrades')
    @include('pages.productDetailOptionalUpgrades')

    @endif

@section('after')
    @include('pages.productDetailAfter')

