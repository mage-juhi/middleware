<?php
use App\Sap\OptionalUpgradeType;

$optionalUpgradeTypes = OptionalUpgradeType::get();
?>
@extends('layouts.default')
@section('content')

<div class="row">
 <div class="col-sm-8 offset-sm-2">
    <h1 class="display-3">Add Optional Upgrades</h1>
  <div>
      <form id="OptionalUpgrades" method="post" action="{{route('createOptionalUpgrades')}}" enctype="multipart/form-data">
            <input type="hidden" name="product_id" value="<?= $product->id?>">
            <input type="hidden" name="store_id" value="<?= $product->store_id?>">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="name" value="">
            </div>
            <div class="form-group">    
                <label for="price">Price</label>
                <input type="text" class="form-control" name="price" value="">
            </div>
            <div class="form-group">
                <label for="type_id">Type:</label>
                <div class="input-group" style="display:flex">                    
                    <select class="select form-control" name="type_id" id="type_id" >
                        <option value="">Please select type</option>
                        <?php foreach($optionalUpgradeTypes as $type):?>
                            <option value="<?= $type->id;?>" ><?= $type->name?></option>
                        <?php endforeach;?>
                    </select>                  
                    <div class="input-group-append">
                        <a href="/optional-upgrade-type"  class="btn btn-outline-primary" type="button">Manager Type</a>
                    </div>
                </div>
            </div>
            
            <div class="form-group">    
                <label for="image">Image</label>
                <input required id="image" type="file" class="form-control" name="image" accept="image/png, image/jpeg" title="Please select a image!">
            </div>
            <div class="form-group">
                <label for="active">Active:</label>
                <div class="col-sm-12 form-group">
                    <div class="col-sm-6 radio-inline">
                        <input type="radio" id="yes" name="active" value="1" checked /> Yes
                    </div>
                    <div class="radio-inline">
                        <input type="radio" id="no" name="active" value="0" /> No
                    </div>
              </div>
            </div>
            <button style="margin-bottom:10px;" type="submit" class="btn btn-primary">Save</button>
      </form>
  </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function($) {
    $("#OptionalUpgrades").validate({
        rules: {
            name : {
                required: true,
                minlength: 3
            },      
            price : {
                required: true,
                number: true 
            },
            type_id: {
                required: true
            },
            image: {
                required: true
            }
        }, 
        messages : {
            name: {
                required: "Please enter field name",
                minlength: "Name should be at least 3 characters"
            },
            price: {
                required: "Please enter field price",
                number: "Please enter the number"
       
            },
            type_id: {
                required: "Please select field type"
            },
            image: {
                required: "Please select field image"
            } 
        }
  });
});
</script>
@stop