<?php

namespace App\Sap;
use App\Sap\ProductEntityValue;
use App\Sap\Product\Exterior;
use App\Sap\Product\Finish;
use Illuminate\Database\Eloquent\Model;

class ProductOptionIndex extends Model
{

    protected $table = 'product_option_index';
    protected $primaryKey = 'id';

    protected $fillable = [
        'store_id',
        'product_id',
        'option_id',
        'option_type',
        'position',
    ];

     /**
     * Allows the retrieval of MaterialLinks from the Product Object
     *
     * @return mixed
     */
    public function materialLinks()
    {
        return $this->hasMany('App\Sap\Product\MaterialLink', 'product_id');
    }
    
    /**
     * Allows the retrieval of ExtraOptions from the Product Object
     *
     * @return mixed
     */
    public function extraOptions()
    {
        return $this->hasMany('App\Sap\Product\ExtraOption', 'product_id');
    }

    /**
     * Allows the retrieval of Cushioning from the Product Object
     *
     * @return mixed
     */
    public function cushioning()
    {
        return $this->hasMany('App\Sap\Product\Cushioning', 'product_id');
    }

    /**
     * Allows the retrieval of Legs from the Product Object
     *
     * @return mixed
     */
    public function legs()
    {
        return $this->hasMany('App\Sap\Product\Legs', 'product_id');
    }

    /**
     * Allows the retrieval of Exterior from the Product Object
     *
     * @return mixed
     */
    public function exterior()
    {
        return $this->hasMany('App\Sap\Product\Exterior', 'product_id');
    }

    /**
     * Allows the retrieval of Finish from the Product Object
     *
     * @return mixed
     */
    public function finish()
    {
        return $this->hasMany('App\Sap\Product\Finish', 'product_id');
    }

    public static function getPosition($productId, $optionId, $optionType)
    {
        $optionIndex = self::where('product_id', $productId)
                    ->where('option_id', $optionId)
                    ->where('option_type', $optionType)->first();
        return $optionIndex ? $optionIndex->position : 0;
    }

    public static function sortOptions($options, $productId, $optionType)
    {
        $sort = [];
        if (count($options) > 0){
            foreach ($options as $option) {
                $optionIndex = self::getPosition($productId,$option->id,$optionType);
                if ($optionIndex)
                    $sort[$optionIndex] = $option;
                else $sort[] = $option;
            }
        }
        ksort($sort);
        return $sort;
    }
}