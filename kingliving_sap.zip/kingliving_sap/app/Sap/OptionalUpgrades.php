<?php

namespace App\Sap;

use Illuminate\Database\Eloquent\Model;

class OptionalUpgrades extends Model
{

    protected $table = 'optional_upgrades';
    protected $primaryKey = 'id';

    protected $fillable = [
        'store_id', 
        'product_id',
        'type_id',
        'name',
        'price',
        'image',
        'active',
    ];
    public function optionalUpgradeType()
    {
        return $this->hasMany('App\Sap\OptionalUpgradeType', 'type_id');
    }
}