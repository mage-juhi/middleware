import React from 'react';

class Order extends React.Component{

    render(){
        return (
            <p>orders grid</p>
        );
    }
}

export default Order;