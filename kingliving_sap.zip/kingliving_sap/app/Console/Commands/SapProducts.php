<?php

namespace App\Console\Commands;

use App\Console\AbstractCommand;
use App\Jobs\ProcessSyncFromSap;
use App\DB\Logger;
use Monolog\Handler\StreamHandler;

class SapProducts extends AbstractCommand
{
    const PROGRESS_BAR_FORMAT = 'debug';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:sap:product
                              {store_id : The integrations Store ID for the Sap Store}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get Sap Range and create packages command';

    /**
     * Execute the console command.
     *
     * @param  \App\DripEmailer $drip
     * @return mixed
     */
    public function handle()
    {
        parent::handle();
        $logger = self::getLogger();

        $logger->info('Sap Products::handle() EXECUTED');
        $time_start = microtime(true);

        $store_id = $this->argument('store_id');
        
        $process = new ProcessSyncFromSap($store_id);
        dispatch($process);

        $time_end = microtime(true);
        $execution_time = $time_end - $time_start;

        $logger->info("Sap Products COMPLETED in {$execution_time}");
        date_default_timezone_set('Australia/Sydney');
        $cron_run_at = date('m/d/Y h:i:s a', time());
        $logger->info("Sap Products Cronrun time at {$cron_run_at} store id: {$store_id}");
        return;
    }

    static private function getLogger()
    {
        $logger = new Logger('Sap_Log');
        $loggerFilename = storage_path(
            'logs/Sap_SyncProduct.log'
        );
        $logger->pushHandler(new StreamHandler($loggerFilename), Logger::INFO);

        return $logger;
    }
}