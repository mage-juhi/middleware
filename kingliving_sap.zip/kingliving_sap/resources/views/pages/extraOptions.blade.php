<?php
use App\Sap\OptionEntityValue;
session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}
//if (aclToClient($_SESSION['username']))
//    header("Location:/dashboard");
$status = [
    0 => 'False',
    1 => 'True'
];
$cylindoType = cylindoTypeList();
?>
@extends('layouts.default')
@section('content')
    <div class="container mt-3">

        <div class="row">
            <div class="col-md-6">
                @include('includes.search')
            </div>
            <div class="col-md-6">
                <?php echo $extraOptions->links(); ?>
            </div>
        </div>

        <div class="dropdown-action">
            <div class="action-select-wrap">
                <button class="action-select">
                <span>Actions</span>
                </button>
                <div class="action-menu-items">
                    <ul class="action-menu">
                        <li><span class="btn-des action-menu-item">Update Description</span></li>
                        <li><span class="btn-img action-menu-item">Update Image</span></li>
                        <li><span class="btn-name action-menu-item">Update Name</span></li>
                        <li><span class="btn-cylindo-data action-menu-item">Update Cylindo Data</span></li>
                        <li><span class="btn-cylindo-type action-menu-item">Update Cylindo Type</span></li>
                        <li><span class="btn-active action-menu-item">Update Status</span></li>
                        <li><span class="btn-type action-menu-item">Update Type</span></li>
                    </ul>
                </div>
            </div>
        </div>
        <?php if(count($extraOptions) > 0) {?>
        <table class="table" id="extraOption_table">
            <thead>
            <tr>
                <th class="data-grid-multicheck-cell">
                    <div class="action-multicheck-wrap">
                        <input id="select-all" class="input-checkbox" type="checkbox" >
                        <button class="action-multicheck-toggle" data-toggle="dropdown"></button>
                        <ul class="action-menu">
                            <li>
                                <span id="selectall" class="action-menu-item">Select All On This Page</span>
                            </li>
                            <li>
                                <span id="selectallpages" class="action-menu-item">Select All</span>
                                <input id='selectallpagesFlag' type='checkbox' style='display:none;'>
                            </li>
                            <li>
                                <span id="deselect-all" class="action-menu-item">Deselect All</span>
                            </li>

                        </ul>
                    </div>
                </th>
                <th>Id</th>
                <th>Sku</th>
                <th class="width_20">Type</th>
                <th class="width_40">Name</th>
                <th>Package Sku</th>
                <th>Image</th>
                <th>Custom Image</th>
                <th>Description</th>
                <th>Cylindo Data</th>
                <th>Active</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <div id = 'search-count-result'><?php echo $extraOptionsall->count() . ' records found'?> <i><small class="counter"></small></i></div>
            <?php foreach($extraOptions as $key => $extraOption){?>
            <form action="/extraOptions" method="post" enctype="multipart/form-data">
                <tr>
                    <td class="data-grid-checkbox-cell">
                        <label class="data-grid-checkbox-cell-inner">
                        <input class="input-checkbox-child" type="checkbox" value="<?php echo $extraOption->id;?>"/>
                        </label>
                    </td>
                    <td><?php echo $extraOption->id;?></td>
                    <td><?php echo $extraOption->sku; ?></td>
                    <td class="width_20">
                        <?php
                            $get_extraOption_type = OptionEntityValue::getValue($extraOption,'extra_option_type');
                            $extra_option_type = $get_extraOption_type ? $get_extraOption_type->value : $extraOption->type;
                        ?>
                        <a class="update_value check_click" id="extra_option_type_<?php echo $extraOption->id;?>" href="javascript:void();"><?php echo $extra_option_type?></a>
                        <div class="div_hide div_extra_option_type">
                            <input class="check_click" type="text" name="extra_option_type_<?php echo $extraOption->id;?>" value="<?php echo $extra_option_type;?>"/>
                            <a href="javascript:void();" data-id="extra_option_type_<?php echo $extraOption->id;?>" entity_field="extra_option_type" entity_table="extraOption" entity_id="<?php echo $extraOption->id;?>" class="btn btn-primary update_btn_value check_click">Update</a>
                        </div>
                    </td>
                    <td class="width_40">
                        <?php
                            $get_extraOption_name = OptionEntityValue::getValue($extraOption,'extra_option_name');
                            $extra_option_name = $get_extraOption_name ? $get_extraOption_name->value : $extraOption->name;
                        ?>
                        <a class="update_value check_click" id="extra_option_name_<?php echo $extraOption->id;?>" href="javascript:void();"><?php echo $extra_option_name?></a>
                        <div class="div_hide div_extra_option_name">
                            <textarea rows="4" class="check_click" type="text" name="extra_option_name_<?php echo $extraOption->id;?>"><?php echo $extra_option_name;?></textarea>
                            <a href="javascript:void();" data-id="extra_option_name_<?php echo $extraOption->id;?>" entity_field="extra_option_name" entity_table="extraOption" entity_id="<?php echo $extraOption->id;?>" class="btn btn-primary update_btn_value check_click">Update</a>
                        </div>
                    </td>
                    <td><?php echo $extraOption->package_sku;?></td>
                    <td class="extraOption-custom-image-<?php echo $extraOption->id;?> StyleCustomImage" id="custom-image-<?php echo $extraOption->id;?>" >
                        <?php
                            $path = base_path('public/upload/images/extraOption/'.$extraOption->custom_image);
                            $isExists = file_exists($path);
                        ?>
                        <?php if($extraOption->custom_image):?>
                            <p><img style= "height:80px;" src="/upload/images/extraOption/<?php echo $extraOption->custom_image ?>"/></p>
                            <a class="btn btn-danger deleteCustomImage" data-type="extraOption" data-id="<?php echo $extraOption->id;?>" href="javascript:void();">X</a>
                        <?php endif;?>
                    </td>
                    <td><input style=" width: 200px; " type="file" class="custom-image-<?php echo $extraOption->id;?>" name="extraOption_custom_image" value="<?php echo $extraOption->custom_image; ?>"/></td>
                    <input type = "hidden" name="extraOption_id" value="<?php echo $extraOption->id;?>?>"/>

                    <td><textarea class="description-<?php echo $extraOption->id; ?>" id="description" name="description"><?php echo $extraOption->description; ?></textarea></td>

                    <td>
                        <div class="custom-select">
                            <select name="cylindo_type" id="cylindo_type" class="cylindo-type-<?php echo $extraOption->id; ?>">
                                <option value="">CHOOSE CYLINDO TYPE</option>
                                <?php foreach ($cylindoType as $value) { ?>
                                <option <?= $extraOption->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <textarea class="cylindo-data-<?php echo $extraOption->id; ?>" name="cylindo_data" id="cylindo_data"><?php echo $extraOption->cylindo_data; ?></textarea>
                        <div class="custom-select">
                            <select name="cylindo_type_optional" id="cylindo_type_optional" class="cylindo-type-optional-<?php echo $extraOption->id; ?>">
                                <option value="">CHOOSE CYLINDO TYPE</option>
                                <?php foreach ($cylindoType as $value) { ?>
                                <option <?= $extraOption->cylindo_type_optional == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <textarea class="cylindo-data-optional-<?php echo $extraOption->id; ?>" name="cylindo_data_optional" id="cylindo_data_optional"><?php echo $extraOption->cylindo_data_optional; ?></textarea>
                    </td>
                    <td <?php if ($extraOption->is_active == 1) echo 'style="color: green;"'; else echo 'style="color: orange;"'; ?>><a data-id="<?php echo $extraOption->id;?>" href="javascript:void();" class="btn btn-primary updateActive"><?php echo $status[$extraOption->is_active]; ?></a></td>
                    <td><button type="submit-edit" product-type="extraOption" data-id="<?php echo $extraOption->id;?>" class="btn btn-primary btn-update">Update</button></td>
                </tr>
            </form>
            <?php } ?>
            </tbody>
        </table>

        <div id="myModalDes" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Description</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <textarea id="des-extraoption"></textarea>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-des-extraoption btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalName" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Name</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <input id="name-extraoption" type="text">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" entity_table="extraOption" entity_id="<?php echo $extraOption->id;?>" class="update-name-extraoption btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalType" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="post" action="">
                        <div class="modal-header">
                            <h3 class="modal-title">Update Type</h3>
                            <button type="button" class="close" data-dismiss="modal">
                                &times;
                            </button>
                        </div>
                        <div class="modal-body">
                            <input type="text" id="extraoption_type_text" class="form-control" name="extraoption_type" value="" placeholder="Type" />
                            <small class="update-type-error text-danger py-3"></small>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                Cancel
                            </button>
                            <button type="button" class="update-type-extraoption btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div id="myModalImage" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <form method="post" action="" enctype="multipart/form-data">
                <div class="modal-header">
                <h3 class="modal-title">Update Image</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <input type="file" id="image-extraoption" name="extraoption_custom_image" value="<?php echo $extraOption->custom_image; ?>"/>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-image-extraoption btn btn-primary">Save</button>
                </div>
                </form>
            </div>
            </div>
        </div>

        <div id="myModalCylindoData" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Cylindo Data</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <textarea id="cylindoData-extraoptions"></textarea>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-cylindoData-extraoptions btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalCylindoType" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Cylindo Type</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <select name="cylindoType-extraoptions" id="cylindoType-extraoptions">
                        <option value="">CHOOSE CYLINDO TYPE</option>
                        <?php foreach ($cylindoType as $value) { ?>
                            <option <?= $extraOption->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-cylindoType-extraoptions btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalActive" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title">Update Status</h3>
                        <button type="button" class="close" data-dismiss="modal">
                            &times;
                        </button>
                    </div>
                    <div class="modal-body">
                        <select name="active-extraOptions" id="active-extraOptions">
                            <option value="">CHOOSE STATUS</option>
                            <option value="1">TRUE</option>
                            <option value="0">FALSE</option>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            Cancel
                        </button>
                        <button type="button" class="update-active-extraOptions btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>
        <?php } else { ?>
            <div style="margin-top: 20px;">No data found!</div>
        <?php } ?>
    </div>
<script type="text/javascript">
jQuery(document).ready(function($) {
    $(".btn-des").click(function(){
        $("#myModalDes").modal('show');
    });

    $(".btn-name").click(function(){
        $("#myModalName").modal('show');
    });

    $(".btn-img").click(function(){
        $("#myModalImage").modal('show');
    });

    $(".btn-active").click(function(){
        $("#myModalActive").modal('show');
    });

    $('#selectallpages').click(function(event) {
        $('.input-checkbox').each(function() {
            this.checked = true;
        });
        $('.input-checkbox-child').each(function() {
            this.checked = true;
        });
        $('#selectallpagesFlag').each(function() {
            this.checked = true;
        });
        updateCounterAllPages();
    });

    function updateCounterAllPages() {
        var len = '<?php echo $extraOptionsall->count();?>';
        if(len>0){$("#search-count-result i .counter").text('('+len+' selected)');}else{$("#search-count-result i .counter").text(' ');}
    }

    $(".update-active-extraOptions").click(function() {
        var status = $("#active-extraOptions").val();
        if(status == '') {
            alert("Please choose your option?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var data = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($extraOptionsall as $key => $extraOption) {?>
                data.push('<?php echo $extraOption->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    data.push($(this).val());
                });
            }

            $.ajax(
            {
                url: "/update-active-extraOptions",
                type: 'post',
                dataType: "json",
                data: {
                    "extraoption_id" : data,
                    "status": status,
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
 });
    $(".btn-update").click(function(e) {
        e.preventDefault();
        var id = $(this).attr('data-id');
        var type = $(this).attr('product-type');
        var des = $('.description-'+id).val();
        var cylindoData = $('.cylindo-data-'+id).val();
        var cylindoType = $('.cylindo-type-'+id).val();
        var cylindoDataOptional = $('.cylindo-data-optional-'+id).val();
        var cylindoTypeOptional = $('.cylindo-type-optional-'+id).val();
        var formData = new FormData();
        var imageFile = $('.custom-image-'+id)[0].files;
        if(imageFile.length > 0) {
            formData.append('extraOption_custom_image',imageFile[0]);
        }
        
        formData.append('extraOption_id',id);
        formData.append('type',type);
        formData.append('description',des);
        formData.append('cylindo_data',cylindoData);
        formData.append('cylindo_type',cylindoType);
        formData.append('cylindoDataOptional',cylindoDataOptional);
        formData.append('cylindoTypeOptional',cylindoTypeOptional);
        $.ajax(
        {
            url: "/extraOptions",
            type: 'post',
            dataType: "json",
            cache: false,
            contentType: false,
            processData: false,
            data: formData,
            success: function (response)
            {
                console.log(response);
                document.getElementById("custom-image-"+id+"").innerHTML = response.template_image;
                alert("You have successfully updated!");
            },
            error: function(xhr) {
                console.log(xhr.responseText);
                alert("Update failed!");
            }
        });
    });

    $(".update-name-extraoption").click(function() {
        var name_extraoption = $("#name-extraoption").val();

        if(name_extraoption == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var name = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($extraOptionsall as $key => $extraOption) {?>
                name.push('<?php echo $extraOption->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    if ($(this).attr('id') != 'select-all') name.push($(this).val());
                });
            }

            var entity_table = $(this).attr("entity_table");

            $.ajax(
            {
                url: "/updateselect-extraoptions-name",
                type: 'post',
                dataType: "json",
                data: {
                    "entity_id" : name,
                    "entity_table": entity_table,
                    "entity_field": "",
                    "entity_value"     : name_extraoption
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

    $(".btn-cylindo-data").click(function(){
        $("#myModalCylindoData").modal('show');
    });

    $(".btn-cylindo-type").click(function(){
        $("#myModalCylindoType").modal('show');
    });
    $(".update-cylindoData-extraoptions").click(function() {
        var cylindoData = $("#cylindoData-extraoptions").val();        
        var result = confirm("Are you sure?");
        if (result) {
            var data = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($extraOptionsall as $key => $extraOption) {?>
                data.push('<?php echo $extraOption->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    data.push($(this).val());
                });
            }

            $.ajax(
                    {
                        url: "/update-extraoptions-cylindodata",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "extraoption_id" : data,
                            "cylindoData": cylindoData,
                        },
                        success: function (response)
                        {
                            console.log(response);
                            alert("You have successfully updated!");
                            location.reload();

                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

    $(".update-cylindoType-extraoptions").click(function() {
        var cylindoType = $("#cylindoType-extraoptions").val();        
        var result = confirm("Are you sure?");
        if (result) {
            var type = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($extraOptionsall as $key => $extraOption) {?>
                type.push('<?php echo $extraOption->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    type.push($(this).val());
                });
            }

            $.ajax(
                    {
                        url: "/update-extraoptions-cylindotype",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "extraoption_id" : type,
                            "cylindoType": cylindoType,
                        },
                        success: function (response)
                        {
                            console.log(response);
                            alert("You have successfully updated!");
                            location.reload();

                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });


   $(".updateActive").click(function(e){
        e.preventDefault();
        var result = confirm("Are you sure?");
        if(result)
        {
            var id = $(this).data("id");
            var button = $(this);
            $.ajax(
            {
                url: "/update-active",
                type: 'post',
                dataType: "json",
                data: {
                    "id": id,
                    "option": "extraOption"
                },
                success: function (response)
                {
                    if (response.value == true){
                        button.text('True');
                    }else button.text('False');
                       
                    // $(this).html(response.value);
                },
                error: function(xhr) {
                 console.log(xhr.responseText);
               }
            });
        }
   });
  $(".update_value").click(function(e){
    e.preventDefault();
    $(".div_hide.active").removeClass("active");
    $(".update_value").show();
    if($(this).parent().find(".div_hide.active").length < 1)
    {
        $(this).hide();
        $(this).parent().find(".div_hide").addClass("active");
    }
    else
    {
        $(this).parent().find(".div_hide").removeClass("active");
    }
  });
  $(".update-des-extraoption").click(function() {
        var des_extraoption = $("#des-extraoption").val();

        if(des_extraoption == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var des = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($extraOptionsall as $key => $extraOption) {?>
                des.push('<?php echo $extraOption->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    if ($(this).attr('id') != 'select-all') des.push($(this).val());
                });
            }

            $.ajax(
            {
                url: "/updateselect-extraoptions-desc",
                type: 'post',
                dataType: "json",
                data: {
                    "extraoption_id" : des,
                    "description": des_extraoption,
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

    $(".update-image-extraoption").click(function() {
        var path = $("#image-extraoption").val();
        var image_extraoption = path.replace(/C:\\fakepath\\/, '');

        if(image_extraoption == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var image = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($extraOptionsall as $key => $extraOption) {?>
                image.push('<?php echo $extraOption->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    if ($(this).attr('id') != 'select-all') image.push($(this).val());
                });
            }
            var formData = new FormData();
            var imageFile = $('#image-extraoption')[0].files;
            formData.append('custom_image',imageFile[0]);
            formData.append('extraoption_id',image);

            $.ajax(
            {
                url: "/updateselect-extraoptions-image",
                type: 'post',
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false,
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

  $(".update_btn_value").click(function(e){
    e.preventDefault();
    var result = confirm("Are you sure?");
    if(result)
    {
        var input_name = $(this).attr("data-id");
        var entity_id = $(this).attr("entity_id");
        var entity_table = $(this).attr("entity_table");
        var entity_field = $(this).attr("entity_field");
        if( entity_field == "extra_option_name")
        {
            var entity_value = $("textarea[name="+input_name+"]").val();
        }
        else
        {
            var entity_value = $("input[name="+input_name+"]").val();
        }
        
        $.ajax(
        {
            url: "/update-option-entity-value",
            type: 'post',
            dataType: "json",
            data: {
                "entity_id" : entity_id,
                "entity_table": entity_table,
                "entity_field": entity_field,
                "entity_value"     : entity_value
            },
            success: function (response)
            {
                console.log(response);
                $("#"+entity_field+"_"+entity_id).html(entity_value);
                $(".div_hide.active").removeClass("active");
                $(".update_value").show();
            },
            error: function(xhr) {
             console.log(xhr.responseText);
           }
        });
        $('#selectallpagesFlag').each(function() {
            this.checked = false;
        });
    }
  });

    // Bulk Update ExtraOptions Type
    $(".btn-type").click(function(){
        $("#myModalType").modal('show');
    });

    $('.update-type-extraoption').click(() => {
        const extraOptionType = $('#extraoption_type_text').val();
        if (extraOptionType === '') {
            $('.update-type-error').text('Type is required.');
            return false;
        }
        const isConfirm = confirm("Are you sure?");
        if (isConfirm) {
            let extraOptionIds = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($extraOptionsall as $key => $extraOption) {?>
                extraOptionIds.push('<?php echo $extraOption->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    if ($(this).attr('id') != 'select-all') extraOptionIds.push($(this).val());
                });
            }
            if (extraOptionIds.length === 0) {
                $('.update-type-error').text('Please select a record.');
                return false;
            }
            $.ajax({
                url: "/updateselect-extraoptions-type",
                type: 'post',
                dataType: "json",
                data: {
                    extra_option_ids : extraOptionIds,
                    type: extraOptionType,
                },
                success: function (response) {
                    $("#myModalType").modal('hide');
                    alert("You have successfully updated!");
                    location.reload();
                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

  $('body').click(function(e){
    if(!$(e.target).hasClass('check_click')) {
       $(".div_hide.active").removeClass("active");
       $(".update_value").show();
    }
  });   
});
</script>
@stop