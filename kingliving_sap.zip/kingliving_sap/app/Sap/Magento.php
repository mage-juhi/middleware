<?php

namespace App\Sap;

use App\Logger;
use Monolog\Handler\StreamHandler;

use GuzzleHttp\Client as httpClient;
use GuzzleHttp\Pool as httpPool;
use GuzzleHttp\Psr7\Request as httpRequest;
use GuzzleHttp\Psr7\Uri as httpUri;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Support\Facades\Log;

class Magento
{

    protected $_baseUrl;
    protected $_password;
    protected $_verifySsl;

    protected $_httpClient;

    const GET = 'GET';
    const POST = 'POST';
    const PUT = 'PUT';

    public function __construct(
        string $baseUrl,
        string $password,
        bool $verifySsl
    )
    {
        $this->_baseUrl = $baseUrl;
        $this->_password = $password;
        $this->_verifySsl = $verifySsl;
        Log::info($this->_baseUrl);

        $this->_httpClient = new httpClient([
            'headers' => [
                'User-Agent' => 'SAP Middleware by MindArc',
                "Content-Type"=> "application/json",
                "X-Requested-With"=> "XMLHttpRequest",
                'Authorization' => "Bearer {$this->_password}"
            ],
            'base_uri' => $this->_baseUrl,
            // 'auth' => $this->_password,
            'verify' => $verifySsl
        ]);
    }

    public function syncProducts($jsonData){
        $item_data = $this->request('POST','sync', $jsonData);

        $ItemData = json_decode($item_data['message'], true);

        return $ItemData;
    }

    public function request(string $method, string $uri, array $data = null)
    {
        $result = [];

        if (!isset($data['auth'])) {
            $data['auth'] = $this->_password;
        }

        try {
            $response = $this->_httpClient->request($method, $uri, ['json' => $data]);
        } catch (RequestException $e) {
            if ($e->hasResponse()) {
                $errorResponse = $e->getResponse();

                $result['success'] = false;
                $result['status_code'] = $errorResponse->getStatusCode();
                $result['message'] = $errorResponse->getReasonPhrase();
            } else {
                $result['success'] = false;
                $result['status_code'] = $e->getCode();
                $result['message'] = $e->getMessage();
            }

            return $result;
        } catch (\Exception $e) {

            $result['success'] = false;
            $result['status_code'] = $e->getCode();
            $result['message'] = $e->getMessage();

            return $result;
        }

        if ((200 <= $response->getStatusCode()) && $response->getStatusCode() < 300) {
            $result['success'] = true;
            $result['status_code'] = $response->getStatusCode();
            $result['headers'] = $response->getHeaders();
            $result['message'] = $response->getBody()->getContents();
        } else {
            $result['success'] = false;
            $result['status_code'] = $response->getStatusCode();
            $result['headers'] = $response->getHeaders();
            $result['message'] = $response->getReasonPhrase();
        }

        return $result;
    }

}
