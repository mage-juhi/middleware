<?php

namespace App\Shopify\Collection;

use Illuminate\Database\Eloquent\Model;

class Rule extends Model
{
    protected $table = 'shopify_collection_rules';
    protected $primaryKey = 'id';

    protected $fillable = [
        'collection_id',
        'column',
        'relation',
        'condition'
    ];

    public $timestamps = false;

    public function collection()
    {
        return $this->belongsTo('App\Shopify\Collection');
    }
}
