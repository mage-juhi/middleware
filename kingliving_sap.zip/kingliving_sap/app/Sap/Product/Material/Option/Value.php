<?php

namespace App\Sap\Product\Material\Option;

use Illuminate\Database\Eloquent\Model;

class Value extends Model
{
    protected $table = 'material_group_option_value';
    protected $primaryKey = 'id';

    protected $fillable = [
        'group_option_id',
        'colour_name',
        'colour_code',
        'colour_image',
        'allow_king_guard',
        'custom_image',
        'is_active'
    ];
    public function option()
    {
        return $this->belongsTo('App\Sap\Product\Material\Option', 'group_option_id');
    }

    public function getOptionValue($id)
    {
        return self::where('group_option_id', '=', $id)->orderBy('position')->get();
    }

}