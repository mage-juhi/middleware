<?php
use App\Sap\OptionEntityValue;
session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}
//if (aclToClient($_SESSION['username']))
//    header("Location:/dashboard");
$status = [
    0 => 'False',
    1 => 'True'
];
$cylindoType = cylindoTypeList();
?>
@extends('layouts.default')
@section('content')
    <div class="container mt-3">
        <div class="row">
            <div class="col-md-6">
                @include('includes.search')
            </div>
        <div class="col-md-6">
            <?php echo $legs->links(); ?>
        </div>
        </div>

        <div class="dropdown-action">
            <div class="action-select-wrap">
                <button class="action-select">
                <span>Actions</span>
                </button>
                <div class="action-menu-items">
                    <ul class="action-menu">
                        <li><span class="btn-des action-menu-item">Update Description</span></li>
                        <li><span class="btn-img action-menu-item">Update Image</span></li>
                        <li><span class="btn-name action-menu-item">Update Name</span></li>
                        <li><span class="btn-cylindo-data action-menu-item">Update Cylindo Data</span></li>
                        <li><span class="btn-cylindo-type action-menu-item">Update Cylindo Type</span></li>
                        <li><span class="btn-active action-menu-item">Update Status</span></li>
                    </ul>
                </div>
            </div>
        </div>

        <?php if(count($legs) > 0) {?>
        <table class="table" id="legs_table">
            <thead>
                <tr>
                    <th class="data-grid-multicheck-cell">
                        <div class="action-multicheck-wrap">
                            <input id="select-all" class="input-checkbox" type="checkbox" >
                            <button class="action-multicheck-toggle" data-toggle="dropdown"></button>
                            <ul class="action-menu">
                                <li>
                                    <span id="selectall" class="action-menu-item">Select All On This Page</span>
                                </li>
                                <li>
                                    <span id="selectallpages" class="action-menu-item">Select All</span>
                                    <input id='selectallpagesFlag' type='checkbox' style='display:none;'>
                                </li>

                                <li>
                                    <span id="deselect-all" class="action-menu-item">Deselect All</span>
                                </li>

                            </ul>
                        </div>
                    </th>
                <th>Id</th>
                <th>Legs Code</th>
                <th class="width_40">Legs Name</th>
                <th>Package SKU</th>
                <th>Qty</th>
                <th>Image</th>
                <th>Custom Image</th>
                <th>Description</th>
                <th>Cylindo Data</th>
                <th>Active</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <div id = 'search-count-result'><?php echo $legsAll->count() . ' records found'?> <i><small class="counter"></small></i></div>
            <?php foreach($legs as $key => $leg){?>
            <form action="/legs" method="post" enctype="multipart/form-data">
                <tr>
                    <td class="data-grid-checkbox-cell">
                        <label class="data-grid-checkbox-cell-inner">
                        <input class="input-checkbox-child" type="checkbox" value="<?php echo $leg->id; ?>"/>
                        </label>
                    </td>

                    <td><?php echo $leg->id;?></td>
                    <td><?php echo $leg->legs_code; ?></td>
                    <td class="width_40">
                        <?php
                            $get_name = OptionEntityValue::getValue($leg,'leg_name');
                            $leg_name = $get_name ? $get_name->value : $leg->legs_name;
                        ?>
                        <a class="update_value check_click" id="leg_value_<?php echo $leg->id;?>" href="javascript:void();"><?php echo $leg_name?></a>
                        <div class="div_hide div_leg_name">
                            <textarea rows="4" class="check_click" type="text" name="leg_name_<?php echo $leg->id;?>"><?php echo $leg_name;?></textarea>
                            <a href="javascript:void();" data-id="leg_name_<?php echo $leg->id;?>" entity_table="leg" entity_id="<?php echo $leg->id;?>" class="btn btn-primary update_btn_value check_click">Update</a>
                        </div>        
                    </td>
                    <td><?php echo $leg->product->sku;?></td>
                    <td><?php echo $leg->quantity; ?></td>
                    <td class="leg-custom-image-<?php echo $leg->id;?> StyleCustomImage" id="custom-image-<?php echo $leg->id;?>">
                        <?php if($leg->custom_image):?>
                        <p><img style= "height:80px;" src="/upload/images/legs/<?php echo $leg->custom_image ?>"/></p>
                        <a class="btn btn-danger deleteCustomImage" data-type="leg" data-id="<?php echo $leg->id;?>" href="javascript:void();">X</a>
                        <?php endif;?>
                    </td>
                    <td><input class="custom-image-<?php echo $leg->id;?>" type="file" id="custom_image" name="legs_custom_image" value="<?php echo $leg->custom_image; ?>"/></td>
                    <input type = "hidden" name="leg_id" value="<?php echo $leg->id;?>"/>

                    <td><textarea id="description" name="description" class="description-<?php echo $leg->id;?>"><?php echo $leg->description; ?></textarea></td>
                    <td>
                        <div class="custom-select">
                            <select name="cylindo_type" id="cylindo_type" class="cylindo-type-<?php echo $leg->id;?>">
                                <option value="">CHOOSE CYLINDO TYPE</option>
                                <?php foreach ($cylindoType as $value) { ?>
                                <option <?= $leg->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <textarea name="cylindo_data" id="cylindo_data" class="cylindo-data-<?php echo $leg->id;?>"><?php echo $leg->cylindo_data; ?></textarea>
                        <div class="custom-select_optional">
                            <select name="cylindo_type_optional" id="cylindo_type_optional" class="cylindo-type-optional-<?php echo $leg->id;?>">
                                <option value="">CHOOSE CYLINDO TYPE</option>
                                <?php foreach ($cylindoType as $value) { ?>
                                <option <?= $leg->cylindo_type_optional == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <textarea name="cylindo_data_optional" id="cylindo_data_optional" class="cylindo-data-optional-<?php echo $leg->id;?>"><?php echo $leg->cylindo_data_optional; ?></textarea>
                    </td>
                    <td <?php if ($leg->is_active == 1) echo 'style="color: green;"'; else echo 'style="color: orange;"'; ?>><a data-id="<?php echo $leg->id;?>" href="javascript:void();" class="btn btn-primary updateActive"><?php echo $status[$leg->is_active]; ?></a></td>
                    <td><button type="submit-edit" product-type="legs" data-id="<?php echo $leg->id;?>" class="btn btn-primary btn-update-legs">Update</button></td>
                </tr>
            </form>
            <?php } ?>
            </tbody>
        </table>
        

        <div id="myModalDes" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Description</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <textarea id="des-leg"></textarea>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-des-leg btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalName" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Update Name</h3>
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>
                <div class="modal-body">
                    <input id="name-leg" type="text">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" entity_table="leg" entity_id="<?php echo $leg->id;?>" class="update-name-leg btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalImage" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <form method="post" action="" enctype="multipart/form-data">
                <div class="modal-header">
                <h3 class="modal-title">Update Image</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <input type="file" id="image-leg" name="legs_custom_image" value="<?php echo $leg->custom_image; ?>"/>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-image-leg btn btn-primary">Save</button>
                </div>
                </form>
            </div>
            </div>
        </div>

        <div id="myModalCylindoData" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Cylindo Data</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <textarea id="cylindoData-leg"></textarea>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-cylindoData-leg btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalCylindoType" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Cylindo Type</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <select name="cylindoType-legs" id="cylindoType-legs">
                        <option value="">CHOOSE CYLINDO TYPE</option>
                        <?php foreach ($cylindoType as $value) { ?>
                            <option <?= $leg->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-cylindoType-legs btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalActive" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title">Update Status</h3>
                        <button type="button" class="close" data-dismiss="modal">
                            &times;
                        </button>
                    </div>
                    <div class="modal-body">
                        <select name="active-legs" id="active-legs">
                            <option value="">CHOOSE STATUS</option>
                            <option value="1">TRUE</option>
                            <option value="0">FALSE</option>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            Cancel
                        </button>
                        <button type="button" class="update-active-legs btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <?php } else { ?>
            <div style="margin-top: 20px;">No data found!</div>
        <?php } ?>
    </div>
<script type="text/javascript">
jQuery(document).ready(function($) {

    $(".btn-des").click(function(){
        $("#myModalDes").modal('show');
    });

    $(".btn-name").click(function(){
        $("#myModalName").modal('show');
    });

    $(".btn-img").click(function(){
        $("#myModalImage").modal('show');
    });


    $(".btn-cylindo-data").click(function(){
        $("#myModalCylindoData").modal('show');
    });

    $(".btn-cylindo-type").click(function(){
        $("#myModalCylindoType").modal('show');
    });

    $(".btn-active").click(function(){
        $("#myModalActive").modal('show');
    });

    $(".update-active-legs").click(function() {
        var status = $("#active-legs").val();
        if(status == '') {
            alert("Please choose your option?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var data = [];
            $.each($("input[type='checkbox']:checked"), function() {
                data.push($(this).val());
            });

            $.ajax(
            {
                url: "/update-active-legs",
                type: 'post',
                dataType: "json",
                data: {
                    "leg_id" : data,
                    "status": status,
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        }
    });
    $(".btn-update-legs").click(function(e) {
        e.preventDefault();
        var id = $(this).attr('data-id');
        var type = $(this).attr('product-type');
        var des = $('.description-'+id).val();
        var cylindoData = $('.cylindo-data-'+id).val();
        var cylindoType = $('.cylindo-type-'+id).val();
        var cylindoDataOptional = $('.cylindo-data-optional-'+id).val();
        var cylindoTypeOptional = $('.cylindo-type-optional-'+id).val();

        var formData = new FormData();
        var imageFile = $('.custom-image-'+id)[0].files;
        if(imageFile.length > 0) {
            formData.append('custom_image',imageFile[0]);
        }
        
        formData.append('id',id);
        formData.append('type',type);
        formData.append('des',des);
        formData.append('cylindoData',cylindoData);
        formData.append('cylindoType',cylindoType);
        formData.append('cylindoDataOptional',cylindoDataOptional);
        formData.append('cylindoTypeOptional',cylindoTypeOptional);
        $.ajax(
        {
            url: "/legs",
            type: 'post',
            dataType: "json",
            cache: false,
            contentType: false,
            processData: false,
            data: formData,
            success: function (response)
            {
                console.log(response);
                // document.getElementById("option-id-"+id+"").innerHTML = response.template_table;
                document.getElementById("custom-image-"+id+"").innerHTML = response.template_image;
                alert("You have successfully updated!");
                // location.reload();
            },
            error: function(xhr) {
                console.log(xhr.responseText);
                alert("Update failed!");
            }
        });
    });


   $(".updateActive").click(function(e){
        e.preventDefault();
        var result = confirm("Are you sure?");
        if(result)
        {
            var id = $(this).data("id");
            var button = $(this);
            $.ajax(
            {
                url: "/update-active",
                type: 'post',
                dataType: "json",
                data: {
                    "id": id,
                    "option": "leg"
                },
                success: function (response)
                {
                    if (response.value == true){
                        button.text('True');
                    }else button.text('False');
                       
                    // $(this).html(response.value);
                },
                error: function(xhr) {
                 console.log(xhr.responseText);
               }
            });
        }
   });
  $(".update_value").click(function(e){
    e.preventDefault();
    $(".div_hide.active").removeClass("active");
    $(".update_value").show();
    if($(this).parent().find(".div_hide.active").length < 1)
    {
        $(this).hide();
        $(this).parent().find(".div_hide").addClass("active");
    }
    else
    {
        $(this).parent().find(".div_hide").removeClass("active");
    }
  });
  $(".update_btn_value").click(function(e){
    e.preventDefault();
    var result = confirm("Are you sure?");
    if(result)
    {
        var input_name = $(this).attr("data-id");
        var entity_id = $(this).attr("entity_id");
        var entity_table = $(this).attr("entity_table");
        var entity_value = $("textarea[name="+input_name+"]").val();
        $.ajax(
        {
            url: "/update-option-entity-value",
            type: 'post',
            dataType: "json",
            data: {
                "entity_id" : entity_id,
                "entity_table": entity_table,
                "entity_field": "",
                "entity_value"     : entity_value
            },
            success: function (response)
            {
                console.log(response);
                $("#"+entity_table+"_value_"+entity_id).html(entity_value);
                $(".div_hide.active").removeClass("active");
                $(".update_value").show();
            },
            error: function(xhr) {
             console.log(xhr.responseText);
           }
        });
    }
  });

    $('#selectallpages').click(function(event) {
        $('.input-checkbox').each(function() {
            this.checked = true;
        });
        $('.input-checkbox-child').each(function() {
            this.checked = true;
        });
        $('#selectallpagesFlag').each(function() {
            this.checked = true;
        });
        updateCounterAllPages();
    });

    function updateCounterAllPages() {
        var len = '<?php echo $legsAll->count();?>';
        if(len>0){$("#search-count-result i .counter").text('('+len+' selected)');}else{$("#search-count-result i .counter").text(' ');}
    }


  $(".update-name-leg").click(function() {
    var name_leg = $("#name-leg").val();
    if(name_leg == '') {
        alert("Please enter your content?");
        return false;
    }
    var result = confirm("Are you sure?");
        if (result) {
            var name = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($legsAll as $key => $leg) {?>
                name.push('<?php echo $leg->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    if ($(this).attr('id') != 'select-all') name.push($(this).val());
                });
            }

            var entity_table = $(this).attr("entity_table");

            $.ajax(
            {
                url: "/updateselect-legs-name",
                type: 'post',
                dataType: "json",
                data: {
                    "entity_id" : name,
                    "entity_table": entity_table,
                    "entity_field": "",
                    "entity_value": name_leg
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

    $(".update-des-leg").click(function() {
        var des_leg = $("#des-leg").val();
        if(des_leg == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var des = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($legsAll as $key => $leg) {?>
                    des.push('<?php echo $leg->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    if ($(this).attr('id') != 'select-all') des.push($(this).val());
                });
            }

            $.ajax(
            {
                url: "/updateselect-legs-desc",
                type: 'post',
                dataType: "json",
                data: {
                    "leg_id" : des,
                    "description": des_leg,
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }

    });

    $(".update-image-leg").click(function() {
        var path = $("#image-leg").val();
        var image_leg = path.replace(/C:\\fakepath\\/, '');

        if(image_leg == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var image = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($legsAll as $key => $leg) {?>
                image.push('<?php echo $leg->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    if ($(this).attr('id') != 'select-all') image.push($(this).val());
                });
            }
            var formData = new FormData();
            var imageFile = $('#image-leg')[0].files;
            formData.append('custom_image',imageFile[0]);
            formData.append('leg_id',image);

            $.ajax(
            {
                url: "/updateselect-legs-image",
                type: 'post',
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false,
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);

                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

  //Legs



    $(".update-cylindoData-leg").click(function() {
        var cylindoData = $("#cylindoData-leg").val();
        if(cylindoData == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var data = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($legsAll as $key => $leg) {?>
                data.push('<?php echo $leg->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    data.push($(this).val());
                });
            }

            $.ajax(
            {
                url: "/update-legs-cylindodata",
                type: 'post',
                dataType: "json",
                data: {
                    "leg_id" : data,
                    "cylindoData": cylindoData,
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

    $(".update-cylindoType-legs").click(function() {
        var cylindoType = $("#cylindoType-legs").val();
        if(cylindoType == '') {
            alert("Please choose your option?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var type = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($legsAll as $key => $leg) {?>
                type.push('<?php echo $leg->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    type.push($(this).val());
                });
            }

            $.ajax(
            {
                url: "/update-legs-cylindotype",
                type: 'post',
                dataType: "json",
                data: {
                    "leg_id" : type,
                    "cylindoType": cylindoType,
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

  //Legs

  $('body').click(function(e){
    if(!$(e.target).hasClass('check_click')) {
       $(".div_hide.active").removeClass("active");
       $(".update_value").show();
    }
  });    
});
</script>
@stop