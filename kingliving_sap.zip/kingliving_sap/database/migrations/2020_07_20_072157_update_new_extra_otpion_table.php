<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateNewExtraOtpionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('extra_group_option', function (Blueprint $table) {
            $table->dropForeign('extra_group_option_store_id_foreign');
            $table->dropColumn('store_id');
            $table->dropColumn('sell_price');
            $table->dropColumn('value_id');
            $table->string('name');
            $table->string('type');
            $table->dropUnique('extra_group_option_store_id_product_id_value_id_unique');
            $table->unique(['product_id','sku']);
        });

        Schema::table('extra_group_option_value', function (Blueprint $table) {
            $table->dropColumn('type');
            $table->dropColumn('name');
            $table->double('sell_price',10,2);
            $table->integer('store_id')->unsigned();
            $table->integer('extra_group_option_id')->unsigned();
        });

        Schema::table('extra_group_option_value', function (Blueprint $table) {
            $table->foreign('store_id')->references('id')->on('stores');
            $table->foreign('extra_group_option_id')->references('id')->on('extra_group_option');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
