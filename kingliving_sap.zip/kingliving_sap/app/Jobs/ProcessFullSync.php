<?php

namespace App\Jobs;

use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Sap\Services\Index\Products;
use Illuminate\Support\Facades\Log;
use App\Sap\ParentProductPackage;
use App\Sap\Product;
use App\DB\Logger;
use Monolog\Handler\StreamHandler;

class ProcessFullSync implements ShouldQueue
{

    public $connection = 'database';
    public $queue = 'full_sync_country';
    public $storeId = 1;

    /**
     * Create a new job instance.
     * @return void
     */
    public function __construct(int $storeId = 1)
    {
        $this->storeId = $storeId;
    }

    /**
     * Execute the job.
     * @return void
     */
    public function handle()
    {
        // Process uploaded podcast...
        $logger = self::getLogger();
        $time_start = microtime(true);
        $logger->info('------------Create Full Sync  Queue------------');

        $count_jobs = \DB::table('jobs')->where('queue', '=', 'full_sync_country')->where('payload','like','%storeId\\\\";i:'.$this->storeId.'%')->count();

        if ($count_jobs == 1) {
            $logger->info('-1. Sync from SAP');
            // set all subrange to sync_status = 0
            ParentProductPackage::where('store_id',$this->storeId)->update(["sync_status"=>0]);
            $subRanges = ParentProductPackage::where('store_id',$this->storeId)->get();
            if (count($subRanges) > 0 ){
                foreach ($subRanges as $subRange) {
                    echo "Sync sub range" . $subRange->sub_range_code ."\n\n";
                    $logger->info("Sync sub range" . $subRange->sub_range_code);
                    $item_data = Products::generateProductSubRange($this->storeId,$subRange->sub_range_code,0);
                }
            }
            $logger->info('----> Synced');
            $logger->info('-2. Sync to Magento');
            // set all product status to 0
            Product::where('store_id',$this->storeId)->where('status',1)->update(["magento_sync_status"=>0]);
            Products::syncToMagento($this->storeId);
            $logger->info('----> Synced');
        }

        $time_end = microtime(true);
        $execution_time = $time_end - $time_start;

        $logger->info("Queue COMPLETED in {$execution_time}");
    }

    static private function getLogger()
    {
        $logger = new Logger('Middleware_Log');
        $loggerFilename = storage_path(
            'logs/full_sync_country.log'
        );
        $logger->pushHandler(new StreamHandler($loggerFilename), Logger::INFO);

        return $logger;
    }
}