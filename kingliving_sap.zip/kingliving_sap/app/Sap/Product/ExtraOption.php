<?php

namespace App\Sap\Product;

use Illuminate\Database\Eloquent\Model;

class ExtraOption extends Model
{
    protected $table = 'extra_group_option';
    protected $primaryKey = 'id';

    protected $fillable = [
        'product_id',
        'sku',
        'name',
        'type',
        'is_required',
        'custom_image',
        'package_sku'
    ];


    public function product()
    {
        return $this->belongsTo('App\Sap\Product', 'product_id');
    }

        /**
     * Allows the retrieval of ExtraOptions from the Product Object
     *
     * @return mixed
     */
    public function extraOptionValue()
    {
        return $this->hasMany('App\Sap\Product\ExtraOption\Value', 'extra_group_option_id');
    }

    public function delete()
    {
        // delete all related
        $this->deleteRelate($this->extraOptionValue);

        // delete the user
        return parent::delete();
    }

    public function deleteRelate($data)
    {
        if (count($data) > 0)
            foreach ($data as $option) {
                $option->delete();
            }
    }
}