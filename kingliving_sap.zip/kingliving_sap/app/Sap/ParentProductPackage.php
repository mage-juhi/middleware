<?php

namespace App\Sap;

use Illuminate\Database\Eloquent\Model;

class ParentProductPackage extends Model
{
    protected $table = 'package_product_parent';
    protected $primaryKey = 'id';

    protected $fillable = [
        'store_id',
        'name',
        'sub_range_code',
        'sync_status'
    ];

}
