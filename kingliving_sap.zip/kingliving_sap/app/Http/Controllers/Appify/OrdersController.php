<?php

namespace App\Http\Controllers\Appify;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class OrdersController extends Controller
{
    public function __construct()
    {
        // Todo: AUTH VALIDATION HERE
    }

    public function index(Request $request)
    {
        $data = array('dashboard'=>'ordersBoard');
        return view('master', $data);
    }
}
