<?php
use App\Sap\OptionEntityValue;
use App\Sap\ProductOptionIndex;
use App\Sap\OptionalUpgradeType;
$optionTypeValue = "";
if(isset($_GET['optionTypeValue'])){
    $optionTypeValue = $_GET['optionTypeValue'];
}
$sort = "";
if(isset($_GET['sort'])){
    $sort = $_GET['sort'];
}
$legs = ProductOptionIndex::sortOptions($product->legs,$product->id,'legs');
$cushionings = ProductOptionIndex::sortOptions($product->cushioning,$product->id,'cushionings');
$extraOptions = $product->extraOptions;
$exteriorLinks = $product->exteriorLinks;
$finishLinks = $product->finishLinks;
$materialTypes = DB::table('material_group_types')->get();
$materialLinks = $product->materialLinks;
$cylindoType = cylindoTypeList();
$optionalUpgrades = $product->optionalUpgrades;
?>
@section('optionalUpgrades')
    <?php if (count($optionalUpgrades) > 0) : ?>
    <li id="optionalUpgrades" class="border-table">
        <?php
        $type = [];
        foreach($optionalUpgrades as $key => $optionalUpgrade){
            $type[] = $optionalUpgrade->type_id;
            
        }
        $type = array_unique($type);
        ?>
        <a class="card-link" data-toggle="collapse" href="#collapse">Optional Upgrades</a>
        <div id="collapse" class="collapse" aria-labelledby="heading" data-parent="#accordionExample">
            <table class="table table-optional-upgrades">
                
            <?php  foreach ($type as $index => $value) { 
                $optionalUpgradeType = OptionalUpgradeType::where('id', $value)->first();
                if(isset($optionalUpgradeType->name)):?>
                    <tbody>
                        <tr>
                           <td colspan="5">  <h3><?=$optionalUpgradeType->name ?></h3></td>
                        </tr>                    
                    <tbody>
                <?php endif;?>
                    <tbody>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th></th>
                    </tr>
                    </tbody>                
                    <tbody>
                    <?php
                    foreach($optionalUpgrades as $optionalUpgrade){?>
                    <?php if ($optionalUpgrade->type_id == $value ){ ?>
                    <tr id="optional-upgrades-<?=$optionalUpgrade->id;?>">
                        <td><?= $optionalUpgrade->id;?></td>
                        <td><?= $optionalUpgrade->name;?></td>
                        <td><?= $optionalUpgrade->price;?></td>
                        <td class="StyleCustomImage">
                            <?php if($optionalUpgrade->image):?>
                            <p><img style= "height:80px;" src="/upload/images/optionalUpgrade/<?php echo $optionalUpgrade->image ?>"/></p>                      
                            <?php endif;?>
                        </td>
                        <td style="text-align:right;"><button class="deleteOptionalUpgrades btn btn-danger" data-id="<?php echo $optionalUpgrade->id;?>">Delete</button></td>
                        <td><a href="/edit-optional-upgrades/<?php echo $optionalUpgrade->id;?>"​ type="button" class="btn btn-primary btn-edit">Edit</a></td>
                    </tr>
                    <?php } ?>
                    <?php } ?>
                    </tbody>                
            <?php } ?>
            </table>
        </div>
    </li>
    <?php endif ?>
@stop
