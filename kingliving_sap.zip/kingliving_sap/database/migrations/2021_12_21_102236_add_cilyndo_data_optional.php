<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddCilyndoDataOptional extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('legs', function (Blueprint $table) {
            $table->string('cylindo_data_optional')->nullable(true);
        });
        Schema::table('cushioning', function (Blueprint $table) {
            $table->string('cylindo_data_optional')->nullable(true);
        });
        Schema::table('extra_group_option', function (Blueprint $table) {
            $table->string('cylindo_data_optional')->nullable(true);
        });
        Schema::table('exterior_group_color', function (Blueprint $table) {
            $table->string('cylindo_data_optional')->nullable(true);
        });
        Schema::table('finish_group_color', function (Blueprint $table) {
            $table->string('cylindo_data_optional')->nullable(true);
        });
        Schema::table('material_group_option_value', function (Blueprint $table) {
            $table->string('cylindo_data_optional')->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
