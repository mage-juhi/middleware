<?php

namespace App\Sap;

use Illuminate\Database\Eloquent\Model;

class OptionTypeRequiredMapping extends Model
{

    protected $table = 'optiion_type_required_mapping';
    protected $primaryKey = 'id';

    protected $fillable = [
        'store_id',
        'product_id',
        'option_type',
        'is_required',
    ];
}