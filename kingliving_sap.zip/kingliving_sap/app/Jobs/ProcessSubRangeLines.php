<?php

namespace App\Jobs;

use App\DB\Store;
use App\Mail\FailedJobNotification;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Sap\Services\Index\Products;
use App\DB\Logger;
use Monolog\Handler\StreamHandler;
use Illuminate\Support\Facades\Log;
use App\Sap\ParentProductPackage;
use Illuminate\Support\Facades\Mail;
use Exception;

class ProcessSubRangeLines implements ShouldQueue
{
    use InteractsWithQueue;

    public $connection = 'database';
    public $queue = 'product_sync_from_sub_range';
    public $storeId = 1;
    public $subRange = '';
    public $tries = 1;
    public $singleSku = null;

    /**
     * Create a new job instance.
     * @return void
     */
    public function __construct(int $storeId = 1,$subRange,$tries = 1,$singleSku = null)
    {
        $this->storeId = $storeId;
        $this->subRange = $subRange;
        $this->tries = $tries;
        $this->singleSku = $singleSku;
    }

    /**
     * Execute the job.
     * @return void
     */
    public function handle()
    {
        try {

            if (env('JOB_NOTIFICATION_TEST')) {
                throw new Exception('Test Error - Product Sync from Subrange Job failed to process ');
            }

            $time_start = microtime(true);
            $logger = self::getLogger();
            $logger->info('Generate product from store ' . $this->storeId . ' sub range '.$this->subRange);
            Products::generateProductSubRange($this->storeId, $this->subRange, $this->tries, $this->singleSku);

            // sync full to magento when sap done
            $subRange = ParentProductPackage::where('store_id',$this->storeId)->where('sync_status', 0)->get();
            if (count($subRange) == 0){
                $logger->info('-->Sub-range synced '.$this->storeId);
                $logger->info('---->Start full sync to Magento');
                Products::syncToMagento($this->storeId);
                $logger->info('---->Full synced to Magento');
                $logger->info('---------------------------');
            }

            $time_end = microtime(true);
            $execution_time = $time_end - $time_start;

        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    public function failed(Exception $e)
    {
        $this->notifyEmail($e->getMessage());

        $store_id = $this->storeId;
        $logger = self::getLogger();
        // dispatch next subrange on failure, report this problem into logs

        //force that product to synced to not interrupt the sync
        ParentProductPackage::where('store_id',$store_id)->where('sync_status', 0)->where('sub_range_code',$this->subRange)->update(["sync_status"=>1]);

        //dispatch the next subrage
        $subRange = ParentProductPackage::where('store_id',$store_id)->where('sync_status', 0)->first();
        Log::info('Failed job detected, dispatching next sub-range: ' . $subRange->sub_range_code . "store: $store_id");
        $productSubRange = new \App\Jobs\ProcessSubRangeLines($store_id, $subRange->sub_range_code);
        dispatch($productSubRange);

        $logger->info('Job Failed for '. $store_id . " - sub range" . $this->subRange);
    }

    static private function getLogger()
    {
        $logger = new Logger('Sap_Log');
        $loggerFilename = storage_path(
            'logs/Sap_SyncProduct.log'
        );
        $logger->pushHandler(new StreamHandler($loggerFilename), Logger::INFO);

        return $logger;
    }

    public function notifyEmail($message)
    {
        Mail::to(env('ADMIN_EMAIL'))
            ->send(new FailedJobNotification([
                'error_message' => $message,
                'job' => [
                    'attempts' => $this->tries,
                    'store_id' => $this->storeId,
                    'queue' => $this->queue,
                    'subrange' => $this->subRange
                ]
            ]));

        if (env('JOB_NOTIFICATION_TEST')) {
            exit();
        }
    }
}