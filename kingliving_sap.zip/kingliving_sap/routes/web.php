<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/
use App\Sap\Product\Material\Option;
use App\Sap\Product;
use App\Sap\ParentProductPackage;
use App\Sap\Product\MaterialLink;
use App\Sap\Product\Material\Option\Value;
use App\Sap\Product\Legs;
use App\Sap\Product\Cushioning;
use App\Sap\Product\Exterior;
use App\Sap\Product\ExtraOption;
use App\Sap\Product\Finish;
use App\Sap\Product\Finish\Color as FinishGroupColor;
use App\Sap\ProductAttribute;
use App\Sap\ProductEntityValue;
use App\Sap\Product\Exterior\Color;
use App\Sap\ProductOptionTypeIndex;
use App\Sap\OptionalUpgrades;
use App\Sap\OptionalUpgradeType;
// Application and Server information routes. Disabled in Production environment
if (!isProduction()) {
    $router->get('/appinfo', function () use ($router) {
        $versionInfo = env('APP_NAME') . ' (v' . env('APP_VERSION') . ')' . "\n" . $router->app->version();
        return $versionInfo;
    });

    $router->get('/phpinfo', function () use ($router) {
        phpinfo();
        return;
    });
}

// Request Acknowledgment URL for uptime checks
$router->get('/ping', function () {
    return response()->json(['ack' => time()]);
});

// Product detail

$router->get('/product-detail/view/id/{id}', function ($id) {
    session_start();
    $product = Product::where('id',$id)->first();
    $productTypeOptions = ProductOptionTypeIndex::sortOptions($id);
    return view('/pages/productDetail', ['product' => $product, 'productTypeOptions' => $productTypeOptions]);
});

// route to show the login form
$router->get('/', ['uses' => 'SapHomeController@showLogin']);

// route to process the form
$router->post('/', ['uses' => 'SapHomeController@doLogin']);

$router->get('/product-link/product', ['uses' => 'SapHomeController@productConfigurableLink']);
$router->get('/product-link/{id}', ['uses' => 'SapHomeController@findConfigurableLink']);
$router->post('/product-link/save', ['uses' => 'SapHomeController@insertConfigurableLink']);

// the sap dashboard displaying product packagesf$package_products
$router->get('/product[/search/{search}]', function ($search=null) {
    $search = urldecode($search);
    $store_id = $stores = DB::table('stores')->where('is_active',1)->first()->id;
    if(isset($_GET['store'])){
        $store_id = $_GET['store'];
    }
    if ($search)
    {
        $package_products = Product::where('store_id', $store_id)
                                    ->where(function($query) use ($search)
                                    {
                                        $query->where('sku','like','%'.$search.'%')->orWhere('name','like','%'.$search.'%');
                                    })->paginate(50);
    } else {
        $package_products = Product::where('store_id', $store_id)->paginate(50);
    }


    $stores = DB::table('stores')->where('is_active',1)->get();
    $current_store = DB::table('stores')->where('is_active',1)->where('id',$store_id)->first();
    $listproductattributes = ProductAttribute::all();

    return view('/pages/product', [
        'package_products' => $package_products,
        'listproductattributes' => $listproductattributes,
        'stores' => $stores,
        'store_id' => $store_id,
        'current_store' => $current_store,
        'search' => $search]);
});

//the sap dashboard/material-group-options
$router->get('product/material-group-options/{id}', function ($id) {
    $material_link = MaterialLink::where('product_id', $id)->get();
    $material_link_arr = [];
    foreach($material_link as $val){
        array_push($material_link_arr, $val->material_group_option_id);
    }
    $material_group_options = Option::whereIn('id', $material_link_arr)->get();
    $material_group_option_value = new Value;
    $store_id = 1;
    if(isset($_GET['store'])){
        $store_id = $_GET['store'];
    }
    $productattributes = ProductAttribute::all();
    $listproductentityvalue = ProductEntityValue::where('product_id', $id)->where('store_id', $store_id)->get();
    return view('/pages/materialGroupOptions', ['material_group_options' => $material_group_options, 'material_group_option_value' => $material_group_option_value, 'product_id' => $id, 'store_id' => $store_id,'productattributes' => $productattributes, 'listproductentityvalue' => $listproductentityvalue]);
});

// route to logout from dashboard
$router->get('/logout', ['uses' => 'SapHomeController@doLogout']);

$router->get('/product/delete/{id}', ['uses' => 'SapHomeController@removeProduct']);

//swatch Sort
$router->post('/swatch-sort','SapHomeController@swatchSort');

//swatch Sort
$router->post('/optionTypeMappingSave','SapHomeController@optionTypeMappingSave');

// swatch editor page
$router->get('/swatch-editor', function () {
    $material_group_options = Option::orderBy('position')->paginate(100);
    $material_group_option_value = new Value;
    return view('/pages/swatchEditor', ['material_group_options' => $material_group_options, 'material_group_option_value' => $material_group_option_value ]);
});

// upload images controller
$router->post('/swatch-editor','SapHomeController@uploadSwatchImages');

// the sap displaying job
$router->get('/jobs', function () {
    $jobs = DB::table('jobs')->get();
    $stores = DB::table('stores')->where('is_active',1)->get();
    return view('/pages/jobs', ['jobs' => $jobs, 'stores' => $stores ]);
});

// Get Dashboard
$router->get('/dashboard', function () {
    $stores = DB::table('stores')->where('is_active',1)->get();
    return view('/pages/dashboard', ['stores' => $stores]);
});

// route to trigger SAP
$router->get('/jobs/triggerSyncMagento', ['uses' => 'SapHomeController@doTriggerMangeto']);
$router->get('/jobs/triggerSingleSyncMagento/{id}', ['uses' => 'SapHomeController@doTriggerSingleProductToMagento']);
$router->get('/jobs/triggerSingleSyncSap/{id}', ['uses' => 'SapHomeController@doTriggerSingleProductFromSap']);
$router->get('/jobs/triggerSyncSubRangeMagento/{sub_range_code}/{store_id}', ['uses' => 'SapHomeController@doTriggerSyncSubRangeMagento']);
$router->get('/jobs/triggerSyncSap', ['uses' => 'SapHomeController@doTriggerSAP']);
$router->get('/subrange/sync/{id}', ['uses' => 'SapHomeController@doTriggerSyncSubRangeSAP']);

// the sap subrange displaying product packages parent
$router->get('/subrange[/search/{search}]', function ($search=null) {
    $search = urldecode($search);
    $store_id = $stores = DB::table('stores')->where('is_active',1)->first()->id;
    if(isset($_GET['store'])){
        $store_id = $_GET['store'];
    }
    if ($search)
    {
        $package_product_parent = ParentProductPackage::where('store_id', $store_id)
                                ->where(function($query) use ($search){
                                    $query->where('sub_range_code','like','%'.$search.'%')->orWhere('name','like','%'.$search.'%');
                                })->paginate(50);
    } else {
        $package_product_parent = ParentProductPackage::where('store_id', $store_id)->paginate(50);
    }

    $stores = DB::table('stores')->where('is_active',1)->get();

    return view('/pages/subrange', ['package_product_parent' => $package_product_parent, 'stores' => $stores, 'store_id' => $store_id, 'search'=> $search]);
});

//the sap
// $router->get('subrange/sync/{id}', function ($id) {
//     $subRange = ParentProductPackage::where('id', $id)->first();
//     $subRange->sync_status = 0;
//     $subRange->save();
//     $url = 'subrange?store='.$subRange->store_id;
//     return redirect($url);
// });

// product attribute
$router->get('/product-attribute', function (){
    // $product_attribute = ProductAttribute::where('id', $id)->getAll();
    $attributes = DB::table('product_attribute')->get();
    return view('/pages/productAttribute',['attributes' => $attributes]);
});
//the edit attribute
$router->get('product-attribute/{id}', function ($id) {
    $productAttribute = ProductAttribute::where('id', $id)->first();
    return view('/pages/editAttribute',['productAttribute' => $productAttribute]);
});
//the edit optional upgrades
$router->get('edit-optional-upgrades/{id}', function ($id) {
    $optionalUpgrades = OptionalUpgrades::where('id', $id)->first();
    return view('/pages/editOptionalUpgrades',['optionalUpgrades' => $optionalUpgrades]);
});
$router->post('/update-product-attribute',['as' => 'updateProductAttribute',    'uses' => 'SapHomeController@updateProductAttribute']);
// add product attribute
$router->get('/add-product-attribute', function (){
    // $product_attribute = ProductAttribute::where('id', $id)->getAll();
    return view('/pages/createAttribute');
});
// add optional Upgrades
$router->get('/add-optional-upgrades/id/{id}', function ($id){
    $product = Product::where('id',$id)->first();
    return view('/pages/optionalUpgrades', ['product' => $product]);
});
$router->post('/create-product-attribute',['as' => 'createProductAttribute',    'uses' => 'SapHomeController@createProductAttribute']);
$router->post('/create-optional-upgrades',['as' => 'createOptionalUpgrades',    'uses' => 'SapHomeController@createOptionalUpgrades']);
$router->post('/update-optional-upgrades',['as' => 'updateOptionalUpgrades',    'uses' => 'SapHomeController@updateOptionalUpgrades']);
// add package product attribute
$router->post('/updateProductEntity',['as' => 'updateProductEntity',    'uses' => 'SapHomeController@updateProductEntity']);
$router->post('/delete-package-product-attibute',['as' => 'deletePackageProductAttibute',    'uses' => 'SapHomeController@deletePackageProductAttibute']);

$router->post('/delete-custom-image',['as' => 'deleteCustomImage',    'uses' => 'SapHomeController@deleteCustomImage']);
$router->post('/delete-optional-upgrades',['as' => 'deleteOptionalUpgrades', 'uses' => 'SapHomeController@deleteOptionalUpgrades']);

$router->post('/update-active',['as' => 'updateActive',    'uses' => 'SapHomeController@updateActive']);

// Optional Upgrade Type
$router->get('/optional-upgrade-type', function (){    
    $types = DB::table('optional_upgrade_type')->get();
    return view('/pages/optionalUpgradeType',['types' => $types]);
});
// add Optional Upgrade Type
$router->get('/add-optional-upgrade-type', function (){    
    return view('/pages/createOptionalUpgradeType');
});
$router->post('/create-optional-upgrade-type',['as' => 'createOptionalUpgradeType',    'uses' => 'SapHomeController@createOptionalUpgradeType']);
//the edit Optional Upgrade Type
$router->get('optional-upgrade-type/{id}', function ($id) {
    $type = OptionalUpgradeType::where('id', $id)->first();
    return view('/pages/editOptionalUpgradeType',['type' => $type]);
});
$router->post('/update-optional-upgrade-type',['as' => 'updateOptionalUpgradeType',    'uses' => 'SapHomeController@updateOptionalUpgradeType']);

// legs page route
$router->get('/legs[/search/{search}]', function ($search=null) {
    $search = urldecode($search);
    if ($search)
    {
        if(is_numeric($search)) {
            $legs = Legs::where("id",$search)->paginate(1);
            $legsAll = Legs::where("id",$search)->get();

            if(count($legsAll) == 0) {
                $legs = Legs::where("legs_code",'like','%'.$search.'%')->orWhere("legs_name",'like','%'.$search.'%')->paginate(50);
                $legsAll = Legs::where("legs_code",'like','%'.$search.'%')->orWhere("legs_name",'like','%'.$search.'%')->get();
            }
        } else {
            $legs = Legs::where("legs_code",'like','%'.$search.'%')->orWhere("legs_name",'like','%'.$search.'%')->paginate(50);
            $legsAll = Legs::where("legs_code",'like','%'.$search.'%')->orWhere("legs_name",'like','%'.$search.'%')->get();
        }
    } else {
        $legs = Legs::paginate(50);
        $legsAll = Legs::all();
    }


    return view('/pages/legs', ['legs' => $legs, 'legsAll' => $legsAll, 'search'=>$search]);
});


// Upload Legs Image
$router->post('/legs','SapHomeController@uploadLegsImages');


// cushioning page route
$router->get('/cushioning[/search/{search}]', function ($search=null) {
    $search = urldecode($search);
    if ($search)
    {
        if(is_numeric($search)) {
            $cushioning = Cushioning::selectRaw('cushioning.*,package_products.sku')->where("cushioning.id",$search)
            ->join('package_products','package_products.id', '=', 'cushioning.product_id')->paginate(1);
            $cushioningall = Cushioning::selectRaw('cushioning.*,package_products.sku')->where("cushioning.id",$search)
            ->join('package_products','package_products.id', '=', 'cushioning.product_id')->get();

            if(count($cushioningall) == 0) {
                $cushioning = Cushioning::selectRaw('cushioning.*,package_products.sku')->where("cushioning_code",'like','%'.$search.'%')->orWhere("cushioning_name",'like','%'.$search.'%')
                ->join('package_products','package_products.id', '=', 'cushioning.product_id')->orWhere('package_products.sku','like','%'.$search.'%')->paginate(50);
                $cushioningall = Cushioning::selectRaw('cushioning.*,package_products.sku')->where("cushioning_code",'like','%'.$search.'%')->orWhere("cushioning_name",'like','%'.$search.'%')
                ->join('package_products','package_products.id', '=', 'cushioning.product_id')->orWhere('package_products.sku','like','%'.$search.'%')->get();
            }
        } else {
            $cushioning = Cushioning::selectRaw('cushioning.*,package_products.sku')->where("cushioning_code",'like','%'.$search.'%')->orWhere("cushioning_name",'like','%'.$search.'%')
            ->join('package_products','package_products.id', '=', 'cushioning.product_id')->orWhere('package_products.sku','like','%'.$search.'%')->paginate(50);
            $cushioningall = Cushioning::selectRaw('cushioning.*,package_products.sku')->where("cushioning_code",'like','%'.$search.'%')->orWhere("cushioning_name",'like','%'.$search.'%')
            ->join('package_products','package_products.id', '=', 'cushioning.product_id')->orWhere('package_products.sku','like','%'.$search.'%')->get();
        }
        
    } else {
        $cushioning = Cushioning::selectRaw('cushioning.*,package_products.sku')->join('package_products','package_products.id', '=', 'cushioning.product_id')->paginate(50);
        $cushioningall = Cushioning::selectRaw('cushioning.*,package_products.sku')->join('package_products','package_products.id', '=', 'cushioning.product_id')->get();
    }
    return view('/pages/cushioning', ['cushionings' => $cushioning, 'cushioningall' => $cushioningall, 'search'=>$search]);
});

// Upload cushioning Image
$router->post('/cushioning','SapHomeController@uploadCushioningImages');

// exterior page route
$router->get('/exterior', function () {
    $exteriors = Exterior::paginate(50);
    $exterior_group_color = new Color;
    return view('/pages/exterior', ['exteriors' => $exteriors, 'exterior_group_color' => $exterior_group_color]);
});

// Upload exterior Image
$router->post('/exterior','SapHomeController@uploadExteriorImages');


// extraOption page route
$router->get('/extraOptions[/search/{search}]', function ($search=null) {
    $search = urldecode($search);
    if ($search)
    {
        if(is_numeric($search)) {
            $extraOptions = ExtraOption::select('extra_group_option.*')->where("extra_group_option.id",$search)
            ->join('package_products','package_products.id', '=', 'extra_group_option.product_id')->paginate(50);
            $extraOptionsall =ExtraOption::select('extra_group_option.*')->where("extra_group_option.id",$search)
            ->join('package_products','package_products.id', '=', 'extra_group_option.product_id')->get();
            if(count($extraOptionsall) == 0) { 
                $extraOptions = ExtraOption::select('extra_group_option.*')->where("extra_group_option.sku",'like','%'.$search.'%')->orWhere("extra_group_option.name",'like','%'.$search.'%')
                ->join('package_products','package_products.id', '=', 'extra_group_option.product_id')->orWhere('package_products.sku','like','%'.$search.'%')->paginate(50);
                $extraOptionsall = ExtraOption::select('extra_group_option.*')->where("extra_group_option.sku",'like','%'.$search.'%')->orWhere("extra_group_option.name",'like','%'.$search.'%')
                ->join('package_products','package_products.id', '=', 'extra_group_option.product_id')->orWhere('package_products.sku','like','%'.$search.'%')->get();
            }
        } else {
            $extraOptions = ExtraOption::select('extra_group_option.*')->where("extra_group_option.sku",'like','%'.$search.'%')->orWhere("extra_group_option.name",'like','%'.$search.'%')
            ->join('package_products','package_products.id', '=', 'extra_group_option.product_id')->orWhere('package_products.sku','like','%'.$search.'%')->paginate(50);
            $extraOptionsall = ExtraOption::select('extra_group_option.*')->where("extra_group_option.sku",'like','%'.$search.'%')->orWhere("extra_group_option.name",'like','%'.$search.'%')
            ->join('package_products','package_products.id', '=', 'extra_group_option.product_id')->orWhere('package_products.sku','like','%'.$search.'%')->get();
        }
    } else {
        $extraOptions = ExtraOption::select('extra_group_option.*')->join('package_products','package_products.id', '=', 'extra_group_option.product_id')->paginate(50);
        $extraOptionsall = ExtraOption::select('extra_group_option.*')->join('package_products','package_products.id', '=', 'extra_group_option.product_id')->get();
    }
    return view('/pages/extraOptions', ['extraOptions' => $extraOptions, 'extraOptionsall' => $extraOptionsall, 'search'=>$search]);
});

// Upload extraOption Image
$router->post('/extraOptions','SapHomeController@uploadExtraOptionsImages');

// finish page route
$router->get('/finish', function () {
    $finish = Finish::paginate(50);
    $finish_group_color = new FinishGroupColor;
    return view('/pages/finish', ['finish' => $finish, 'finish_group_color' => $finish_group_color]);
});
// Upload finish custom Image
$router->post('/finish','SapHomeController@uploadFinishGroupImages');
$router->post('/update-exterior-name',['as' => 'updateSelectName',    'uses' => 'SapHomeController@updateSelectName']);
$router->post('/update-finish-name',['as' => 'updateSelectName',    'uses' => 'SapHomeController@updateSelectName']);
$router->post('/update-option-entity-value',['as' => 'updateOptionEntityValue',    'uses' => 'SapHomeController@updateOptionEntityValue']);
$router->post('/updateselect-legs-image',['as' => 'updateSelectLegsImage',    'uses' => 'SapHomeController@updateSelectLegsImage']);
$router->post('/updateselect-cushioning-image',['as' => 'updateSelectCushioningImage',    'uses' => 'SapHomeController@updateSelectCushioningImage']);
$router->post('/updateselect-extraoptions-image',['as' => 'updateSelectExtraoptionsImage',    'uses' => 'SapHomeController@updateSelectExtraoptionsImage']);
$router->post('/updateselect-legs-desc',['as' => 'updateSelectLegsDesc',    'uses' => 'SapHomeController@updateSelectLegsDesc']);
$router->post('/updateselect-cushioning-desc',['as' => 'updateSelectCushioningDesc',    'uses' => 'SapHomeController@updateSelectCushioningDesc']);
$router->post('/updateselect-extraoptions-desc',['as' => 'updateSelectExtraoptionsDesc',    'uses' => 'SapHomeController@updateSelectExtraoptionsDesc']);
$router->post('/updateselect-legs-name',['as' => 'updateSelectName',    'uses' => 'SapHomeController@updateSelectName']);
$router->post('/updateselect-cushioning-name',['as' => 'updateSelectName',    'uses' => 'SapHomeController@updateSelectName']);
$router->post('/updateselect-extraoptions-name',['as' => 'updateSelectName',    'uses' => 'SapHomeController@updateSelectName']);
$router->post('/updateselect-swatch-name',['as' => 'updateSelectName',    'uses' => 'SapHomeController@updateSelectName']);
$router->post('/updateselect-swatch-image',['as' => 'updateSelectSwatchImage',    'uses' => 'SapHomeController@updateSelectSwatchImage']);
$router->post('/updateselect-extraoptions-type',['as' => 'updateSelectExtraoptionsType',    'uses' => 'SapHomeController@updateSelectExtraoptionsType']);

//update edit option
$router->post('/update-edit-option','SapHomeController@updateEditOption');

//update product option type
$router->post('/update-product-option-type','SapHomeController@updateProductOptionType');

//update swatch sort index
$router->post('/update-swatch-sort-index','SapHomeController@updateSwatchSortIndex');
$router->post('/sorter-swatch-options','SapHomeController@sorterSwatchOptions');
//update-swatch-parent-sort-index
$router->post('/update-swatch-parent-sort-index','SapHomeController@updateSwatchParentSortIndex');

//update product option index
$router->post('/update-product-option-index','SapHomeController@updateProductOptionIndex');

// Update Cylindo Data - Cylindo Type
$router->post('/update-legs-cylindodata',['as' => 'updateLegsCylindoData', 'uses' => 'SapHomeController@updateLegsCylindoData']);
$router->post('/update-legs-cylindotype',['as' => 'updateLegsCylindoType', 'uses' => 'SapHomeController@updateLegsCylindoType']);
$router->post('/update-cushioning-cylindodata',['as' => 'updateCushioningCylindoData', 'uses' => 'SapHomeController@updateCushioningCylindoData']);
$router->post('/update-cushioning-cylindotype',['as' => 'updateCushioningCylindoType', 'uses' => 'SapHomeController@updateCushioningCylindoType']);
$router->post('/update-extraoptions-cylindodata',['as' => 'updateExtraoptionsCylindoData', 'uses' => 'SapHomeController@updateExtraoptionsCylindoData']);
$router->post('/update-extraoptions-cylindotype',['as' => 'updateExtraoptionsCylindoType', 'uses' => 'SapHomeController@updateExtraoptionsCylindoType']);
$router->post('/update-finish-cylindodata',['as' => 'updateFinishCylindoData', 'uses' => 'SapHomeController@updateFinishCylindoData']);
$router->post('/update-finish-cylindotype',['as' => 'updateFinishCylindoType', 'uses' => 'SapHomeController@updateFinishCylindoType']);
$router->post('/update-exterior-cylindodata',['as' => 'updateExteriorCylindoData', 'uses' => 'SapHomeController@updateExteriorCylindoData']);
$router->post('/update-exterior-cylindotype',['as' => 'updateExteriorCylindoType', 'uses' => 'SapHomeController@updateExteriorCylindoType']);
//update bulk True/False
$router->post('/update-active-legs',['as' => 'updateStatusLegs', 'uses' => 'SapHomeController@updateStatusLegs']);
$router->post('/update-active-cushioning',['as' => 'updateStatusCushioning', 'uses' => 'SapHomeController@updateStatusCushioning']);
$router->post('/update-active-extraOptions',['as' => 'updateStatusExtraOptions', 'uses' => 'SapHomeController@updateStatusExtraOptions']);
$router->post('/update-active-exterior',['as' => 'updateStatusExterior', 'uses' => 'SapHomeController@updateStatusExterior']);
$router->post('/update-active-finish',['as' => 'updateStatusFinish', 'uses' => 'SapHomeController@updateStatusFinish']);
$router->post('/update-active-swatches',['as' => 'updateStatusSwatches', 'uses' => 'SapHomeController@updateStatusSwatches']);
$router->post('/trigger-full-sync',['as' => 'updateFullSync',    'uses' => 'SapHomeController@updateFullSync']);
$router->post('/trigger-sync-to-magento',['as' => 'updateSyncToMagento',    'uses' => 'SapHomeController@updateSyncToMagento']);

$router->put('/product/option/status', ['as' => 'updateProductOptionStatus', 'uses' => 'SapHomeController@updateProductOptionStatus']);

