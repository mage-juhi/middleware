<?php

namespace App\Sap;

use Illuminate\Database\Eloquent\Model;

class OptionalUpgradeType extends Model
{

    protected $table = 'optional_upgrade_type';
    protected $primaryKey = 'id';

    protected $fillable = [
        'name'
    ];
}