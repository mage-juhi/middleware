<?php

session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}

if (aclToClient($_SESSION['username']))
    header("Location:/dashboard");
?>
	@extends('layouts.default')
	@section('content')
    <div class="container">
	    <a href="/add-product-attribute" class="btn btn-success btn-add">Add</a>
		<div class="table-responsive">
			<table class="table table-hover">
				<thead>
					<tr>
						<th>Id</th>
						<th>Code</th>
						<th>Name</th>
						<th>Type</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($attributes as $key => $attribute){?>
					<tr>
						<td><?php echo $attribute->id;?></td>
						<td><?php echo $attribute->code; ?></td>
						<td><?php echo $attribute->name; ?></td>
						<td><?php echo $attribute->type; ?></td>
						<td>
							<a href="product-attribute/<?php echo $attribute->id;?>"​ type="button" class="btn btn-warning btn-edit">Edit</a>
							<!-- <button class="deleteProductEntity btn btn-danger" data-id="<?php echo $attribute->id;?>">Delete</button> -->
							<!-- <button data-url="#"​ type="button" data-target="#delete" data-toggle="modal" class="btn btn-danger btn-delete">Delete</button> -->
							
						</td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
    </div>
@stop
