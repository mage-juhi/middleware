import React from 'react';

class Home extends React.Component{
    render(){
        return (
            <p>Select your view from the Navigation Bar -></p>
        );
    }
}

export default Home;