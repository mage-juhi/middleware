<?php

namespace App\Console\Commands;

use App\Console\AbstractCommand;
use App\Sap\Product;
use App\Sap\Product\ConfigurableMapping;

class ProcessConfigurableCsv extends AbstractCommand
{
    const PROGRESS_BAR_FORMAT = 'debug';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:processconfigurablecsv
                              {store_id : The id the CSV file store should map to}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Takes a CSV file and generates possible configurable mappings';

    private $csv_file = "/import/configurable.csv";

    /**
     * Execute the console command.
     *
     * @param  \App\DripEmailer $drip
     * @return mixed
     */
    public function handle()
    {
        parent::handle();

        $store_id = $this->argument('store_id');

        $storage_path = storage_path();
        $csv_file = fopen ($storage_path . $this->csv_file, "r");

        $i=0;
        $foundSkus = [];
        if ($csv_file !== false)
        {
            while (($row = fgetcsv($csv_file, 1000, ",")) !== FALSE) {
                //assume all rows are sorted alpha
                if (!empty($row[0]))
                {
                    $product = Product::where('sku',trim($row[0]))->where('store_id', $store_id)->first();

                    if ($product)
                    {
                        echo $i++ . $row[0] . "," . $product->id . "\n";

                        $foundSkus[] = $row[0];
                    }

                    if (false)
                    {
                        $grouped_skus = [];
                        foreach ($grouped_skus as $sku)
                        {
                            $product = new Product();
                            $product->sku = $sku;
                            $product->name = $sku;
                            $product->store_id = $store_id;
                            $product->sub_range_code = "CONFIGURABLE";
                            $product->has_material = 0;
                            $product->save();
                        }
                    }
                }
            }
        }

        return;
    }
}