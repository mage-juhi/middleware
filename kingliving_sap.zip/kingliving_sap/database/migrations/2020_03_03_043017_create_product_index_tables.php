<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductIndexTables extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('package_products', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('store_id')->unsigned();
            $table->string('sku');
            $table->string('item_type');
            $table->string('name');
            $table->string('product_image')->nullable();
            $table->string('item_group_name')->nullable();
            $table->string('sub_range_code')->nullable();
            $table->string('sub_range_name')->nullable();
            $table->string('country_of_manufacture')->nullable();

            $table->unique(['sku', 'store_id']);
        });


        Schema::create('product_material_group_link', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('product_id')->unsigned();
            $table->integer('material_group_option_id')->unsigned();
            $table->integer('cushion_id')->unsigned();
            $table->string('code');
            $table->double('sell_price',10,2);
            $table->double('rrp_price',10,2);
            $table->double('king_guard_price',10,2);
        });


        Schema::create('material_group_options', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('type_id')->unsigned();
            $table->string('name');
            $table->string('range_code');
        });

        Schema::create('material_group_types', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->string('title');
        });

        Schema::create('material_group_option_value', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('group_option_id')->unsigned();
            $table->string('colour_name');
            $table->string('colour_code');
            $table->string('colour_image')->nullable();
            $table->boolean('allow_king_guard');
        });




        Schema::create('extra_group_option_value', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('product_id')->unsigned();
            $table->string('sku');
            $table->string('type');
            $table->string('name');
            $table->double('sell_price',10,2);
            $table->integer('quantity');
            $table->boolean('is_required');


            $table->unique(['sku', 'product_id']);
        });


        Schema::table('package_products', function (Blueprint $table) {
            $table->foreign('store_id')->references('id')->on('stores');
        });

        Schema::table('product_material_group_link', function (Blueprint $table) {
            $table->foreign('product_id')->references('id')->on('package_products');
            $table->foreign('material_group_option_id')->references('id')->on('material_group_options');
        });

        Schema::table('material_group_options', function (Blueprint $table) {
            $table->foreign('type_id')->references('id')->on('material_group_types');
        });

        Schema::table('material_group_option_value', function (Blueprint $table) {
            $table->foreign('group_option_id')->references('id')->on('material_group_options');
        });

        Schema::table('extra_group_option_value', function (Blueprint $table) {
            $table->foreign('product_id')->references('id')->on('package_products');
        });




    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_material_group_link');



        Schema::dropIfExists('extra_group_option_value');
        Schema::dropIfExists('extra_group_types');

        Schema::dropIfExists('material_group_option_value');
        Schema::dropIfExists('material_group_options');
        Schema::dropIfExists('material_group_types');
        Schema::dropIfExists('package_products');
    }
}
