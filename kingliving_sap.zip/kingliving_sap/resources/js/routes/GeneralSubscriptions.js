import React from 'react';
import {Button, Card, Pagination, Stack, TextField, Frame, Loading} from '@shopify/polaris';
import GeneralisedTable from '../components/GeneralisedTable/GeneralisedTable';

const API_BASE_URL = '/subscriptions/';
class GeneralSubscriptions extends React.Component{
    state = {
        selectedItems: [],
        searchValue: '',
        filtered : [],
        isLoading: false,
        error: null,
        listItems: [],
        isFirstPage: true,
        isLastPage: false,
        currentPage: 1,
        lastPage: 1,
        sortBy: 'id',
        sortType: 'ASC'
    };

    componentDidMount(){
        const page = this.getQueryStringValue('page');
        Promise.resolve(
            this.setState(() => ({currentPage: page ? page : 1}))
        );
        this.getSubscriptions(this.state.searchValue,this.state.currentPage,this.state.sortBy,this.state.sortType);
        this.setState({filtered: this.props.listItems});
    }

    componentWillReceiveProps(nextProps){
        this.setState({filtered: nextProps.listItems});
    }

    getQueryStringValue(key) {
        const value = decodeURIComponent(
            window.location.search.replace(
                new RegExp(
                    '^(?:.*[&\\?]' +
                    encodeURIComponent(key).replace(/[\.\+\*]/g, '\\$&') +
                    '(?:\\=([^&]*))?)?.*$',
                    'i'
                ),
                '$1'
            )
        );
        return value ? value : null;
    }

    async getSubscriptions(searchval,pagenum,sortby,sorttype){
        try{
            this.setState({isLoading: true});
            const response = await fetch(API_BASE_URL + 'api/lists'+ '?query='+ searchval + '&page=' + pagenum + '&sort=' + sortby + '&sortType=' + sorttype);
            const subslist = await response.json();
            let newArr = []
            for (var i=0; i<subslist.data.collection.length; i++)
            {
                subslist.data.collection[i].url= API_BASE_URL + subslist.data.collection[i].id;
                newArr.push(subslist.data.collection[i]);
            }
            this.setState({ listItems:newArr, isLoading:false, currentPage: subslist.meta.current_page, lastPage: subslist.meta.last_page});
            if(subslist.meta.current_page == subslist.meta.last_page){ //check last page
                this.setState({isFirstPage:false,isLastPage:true});
            }
            if(subslist.meta.current_page == 1){                        //check first page
                this.setState({isFirstPage:true,isLastPage:false});
            }
        }catch(err){
            this.setState({isLoading:false});
            console.error(err);
        }
    }

    handleSearchChange = () => {
        let searchVal = this.state.searchValue;
        this.getSubscriptions(this.state.searchValue,this.state.currentPage,this.state.sortBy,this.state.sortType);
        let currentList = [];
        let newList = [];
        if(searchVal !== ""){
            newList = this.state.listItems;
        }else{
            newList = this.state.listItems;
        }

        this.setState({filtered:newList});

    }

    //handleSelectionChange = (selectedItems) => {
    //    this.setState({selectedItems});
    //}

    handlePreviousPage = () =>{
        let currPage = this.state.currentPage;
        if(currPage != 1 ) {
            currPage -= 1;
            this.setState({isFirstPage:false,isLastPage:false });
        }
        this.getSubscriptions(this.state.searchValue,currPage,this.state.sortBy,this.state.sortType);
    }

    handleNextPage = () =>{
        let currPage = this.state.currentPage;

        if(currPage < (this.state.lastPage) ) {
            currPage += 1;
            this.setState({isFirstPage:false,isLastPage:false });
        }
        this.getSubscriptions(this.state.searchValue,currPage,this.state.sortBy,this.state.sortType);
    }

    handleChange = (searchValue) => {
        this.setState({searchValue});
    }

    handleClearButtonClick = () => {
        this.setState({searchValue:'', currentPage : 1});
        this.getSubscriptions('',1,this.state.sortBy,this.state.sortType);
    }

    handleSortDirection = () => {
        var sorter = this.state.sortType;
        if(sorter == 'ASC')
            sorter = 'DESC';
        else
            sorter = 'ASC';
        this.setState({sortType : sorter});
        this.getSubscriptions(this.state.searchValue,this.state.currentPage,this.state.sortBy,sorter);
    }

    handleSelection = (value) => {
        this.setState({selectedItems: [value]})
    }

    render(){
        const paginationMarkup = this.state.listItems.length > 0
            ? (
            <Pagination
                hasPrevious = {!this.state.isFirstPage}
                onPrevious={this.handlePreviousPage}
                hasNext = {!this.state.isLastPage}
                onNext = {this.handleNextPage}
            />
        )
            : null;

        const loader = (this.state.isLoading)
            ?(
                <Frame>
                    <Loading />
                </Frame>
            )
            : null;

        var renderFunctions = [
            function(item){return item.id },
            function(item){
                return <a href={API_BASE_URL +'edit/' + item.id}>{item.label}</a>
            },
            function(item){return item.method},
            function(item){return item.event},
            function(item){return item.post_params},
            function(item){return item.closure},
            function(item){return item.encode},
        ];

        var tableHeaders = [
            {"title": "S.No", "sortable" : true},
            {"title": "Label","sortable" : false},
            {"title": "method", "sortable" : false},
            {"title": "event", "sortable" : false},
            {"title": "post_params", "sortable" : false},
            {"title": "closure", "sortable" : false},
            {"title":"encode","sortable" : false}
        ];

        return (
            <div>
                {loader}
                <Card title="Subscriptions List">
                    <Stack alignment="center">
                        <TextField
                            placeholder = "Search Subscriptions"
                            onChange = {this.handleChange}
                            value = {this.state.searchValue}
                            clearButton
                            onClearButtonClick = {this.handleClearButtonClick}
                        />
                        <Button outline onClick={this.handleSearchChange}>Search</Button>
                    </Stack>
                    <GeneralisedTable
                        noDataPlaceholderText="No data found"
                        tableData={this.state.listItems}
                        attributeRenderFunctions={renderFunctions}
                        tableHeaders={tableHeaders}
                        sortDirection={this.handleSortDirection}
                    />
                    <br/>
                    <Stack distribution="center">
                        {paginationMarkup}
                    </Stack>
                    <br/>
                </Card>
            </div>
        );
    }
}

export default GeneralSubscriptions;
