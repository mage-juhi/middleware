<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddPackageProductStatus extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable('package_products')) {
            //
            Schema::table('package_products', function (Blueprint $table) {
                $table->integer('status');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (Schema::hasTable('package_products')) {
            Schema::table('package_products', function (Blueprint $table) {
                $table->dropColumn('status');
            });
        }
    }
}
