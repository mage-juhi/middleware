<?php

namespace App\Http\Middleware;

use Closure;

class AppifyAuthenticate
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (session('authorised', false) === false) {
            $response = [];

            $errorCode = 404;
            $response['error'] = [
                'code' => $errorCode,
                'message' => 'A Shop name must be provided'
            ];

            return response()->json($response, $errorCode);
        }

        session([
            'authorised' => session('authorised'),
            'store_id' => session('store_id')
        ]);
        authoriseStore(session('store_id'));

        return $next($request);
    }
}
