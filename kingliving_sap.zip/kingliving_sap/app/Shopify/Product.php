<?php

namespace App\Shopify;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = 'shopify_products';
    protected $primaryKey = 'id';

    protected $fillable = [
        'store_id',
        'id',
        'title',
        'body_html',
        'vendor',
        'product_type',
        'handle',
        'created_at',
        'updated_at',
        'published_at',
        'template_suffix',
        'published_scope'
    ];

    public $incrementing = false;
    public $timestamps = false;

    /**
     * Attempts to pull the latest version of the Shopify Product ID from Shopify and updates the local repository
     */
    public function pullDown()
    {
        if (!isset($this->id) || empty($this->id)) {
            throw new \Exception('Cannot pull data from shopify without an ID set');
        }

        $shopifyProduct = shopify()->getProduct($this->id);

        if (is_object($shopifyProduct) || isset($shopifyProduct->errors)) {
            $errorObj = [
                'code' => $shopifyProduct->errors->status,
                'message' => $shopifyProduct->errors->body->errors
            ];
            throw new \Exception('Error pulling product from shopify: ' . print_r($errorObj, true));
        }

        return $this->loadFromShopifyProduct($shopifyProduct);
    }

    /**
     * Attempts to push the current version of the Shopify Product ID to Shopify and updates the local repository
     */
    public function pushUp()
    {

    }

    /**
     * Allows the retrieval of Variants from the Product Object
     *
     * @return mixed
     */
    public function variants()
    {
        return $this->hasMany('App\Shopify\Product\Variant', 'product_id');
    }

    /**
     * Allows the retrieval of Tags from the Product Object
     *
     * @return mixed
     */
    public function tags()
    {
        return $this->hasMany('App\Shopify\Product\Tag', 'product_id');
    }

    /**
     * Allows the retrieval of Options from the Product Object
     *
     * @return mixed
     */
    public function options()
    {
        return $this->hasMany('App\Shopify\Product\Option', 'product_id');
    }

    /**
     * Allows the retrieval of Images from the Product Object
     *
     * @return mixed
     */
    public function images()
    {
        return $this->hasMany('App\Shopify\Product\Image', 'product_id');
    }

    public function loadFromShopifyProduct(array $shopifyProduct)
    {
        // Prepare the Shopify Product for the integration DB
        $shopifyProduct['store_id'] = store()->id;

        // Convert the Shopify Product Timestamps in to valid mySQL DateTime Timestamps
        $shopifyProduct['created_at'] = $this->convertDateTimezoneToDateTime($shopifyProduct['created_at']);
        $shopifyProduct['updated_at'] = $this->convertDateTimezoneToDateTime($shopifyProduct['updated_at']);
        $shopifyProduct['published_at'] = $this->convertDateTimezoneToDateTime($shopifyProduct['published_at']);

        // Prepare the Shopify Product Tags for the integration DB
        $shopifyProductTags = [];
        if (isset($shopifyProduct['tags']) && !empty($shopifyProduct['tags'])) {
            $shopifyProductTags = $this->explodeTags($shopifyProduct['id'], $shopifyProduct['tags']);
        }

        // Prepare the Shopify Product Variants for the integration DB
        $shopifyProductVariants = [];
        if (isset($shopifyProduct['variants']) && !empty($shopifyProduct['variants'])) {
            $shopifyProductVariants = $shopifyProduct['variants'];
            foreach ($shopifyProductVariants as $k => $variant) {
                // Convert the Shopify Product Variant Timestamps in to valid mySQL DateTime Timestamps
                $shopifyProductVariants[$k]['created_at'] = $this->convertDateTimezoneToDateTime($variant['created_at']);
                $shopifyProductVariants[$k]['updated_at'] = $this->convertDateTimezoneToDateTime($variant['updated_at']);
            }
        }

        // Prepare the Shopify Product Options for the integration DB
        $shopifyProductOptions = [];
        if (isset($shopifyProduct['options']) && !empty($shopifyProduct['options'])) {
            $shopifyProductOptions = $shopifyProduct['options'];

            foreach ($shopifyProductOptions as $k => $option){
                $values = $option['values'];
                foreach ($values as $pos => $value){
                    $values[$pos] = [
                        'option_id' => $option['id'],
                        'position' => $pos,
                        'value' => $value
                    ];
                }
                $shopifyProductOptions[$k]['values'] = $values;
            }
        }

        // Prepare the Shopify Product Images for the integration DB
        $shopifyProductImages = [];
        if (isset($shopifyProduct['images']) && !empty($shopifyProduct['images'])) {
            $shopifyProductImages = $shopifyProduct['images'];

            // Convert the Shopify Image Timestamps in to vaild mySQL DateTime Timestamps
            foreach ($shopifyProductImages as $k => $image) {
                $shopifyProductImages[$k]['created_at'] = $this->convertDateTimezoneToDateTime($image['created_at']);
                $shopifyProductImages[$k]['updated_at'] = $this->convertDateTimezoneToDateTime($image['updated_at']);

                if (isset($image['variant_ids']) && !empty($image['variant_ids'])) {
                    $imageVariantIds = $image['variant_ids'];
                    foreach ($imageVariantIds as $i => $imageVariantId) {
                        $imageVariantIds[$i] = [
                            'image_id' => $image['id'],
                            'variant_id' => $imageVariantId
                        ];
                    }
                    $shopifyProductImages[$k]['variant_ids'] = $imageVariantIds;
                }
            }
        }

        // Check if the product is already in the DB
        $newProd = self::find($shopifyProduct['id']);
        if ($newProd) {
            // Product Exists, Update Data
            $newProd->fill($shopifyProduct);

            $newProd->save();

            // Reset the Tags for a product
            $newProd->tags()->delete();
            if (!empty($shopifyProductTags)) {
                $newProd->tags()->createMany($shopifyProductTags);
            }

            // Update the Variants
            if (!empty($shopifyProductVariants)) {
                // Update existing variants and flag existing variants for removal
                foreach ($newProd->variants as $variant) {
                    $didVariantExist = false;
                    foreach ($shopifyProductVariants as $shopifyVariant) {
                        if ($variant->id == $shopifyVariant['id']) {
                            $didVariantExist = true;
                            $variant->fill($shopifyVariant);
                            $variant->save();
                        }
                    }

                    // If the existing variant did not exist in Shopify, flag for deletion
                    if (!$didVariantExist) {
                        $variant->delete();
                    }
                }

                // Flag new Variants for Creation
                $newVariants = [];
                foreach ($shopifyProductVariants as $shopifyVariant) {
                    $didVariantExist = false;
                    foreach ($newProd->variants as $variant) {
                        if ($shopifyVariant['id'] == $variant->id) {
                            $didVariantExist = true;
                        }
                    }
                    if (!$didVariantExist) {
                        $newVariants[] = $shopifyVariant;
                    }
                }
                if (!empty($newVariants)) {
                    $newProd->variants()->createMany($newVariants);
                }
            }

            // Update the Options
            if (!empty($shopifyProductOptions)) {
                // Update existing options and flag existing options for removal
                foreach ($newProd->options as $option) {
                    $didOptionExist = false;
                    foreach ($shopifyProductOptions as $shopifyOption) {
                        if ($option->id == $shopifyOption['id']) {
                            $didOptionExist = true;
                            $option->fill($shopifyOption);
                            $option->save();

                            // Reset the option Values
                            $option->values()->delete();
                            if (!empty($shopifyOption['values'])) {
                                $option->values()->createMany($shopifyOption['values']);
                            }
                        }
                    }

                    // If the existing option did not exist in Shopify, flag for deletion
                    if (!$didOptionExist) {
                        $option->delete();
                    }
                }

                $newOptions = [];
                foreach ($shopifyProductOptions as $shopifyOption) {
                    $didOptionExist = false;
                    foreach ($newProd->options as $option) {
                        if ($shopifyOption['id'] == $option->id) {
                            $didOptionExist = true;
                        }
                    }
                    if (!$didOptionExist) {
                        $newOptions[] = $shopifyOption;
                    }
                }
                if (!empty($newOptions)) {
                    $newProd->options()->createMany($newOptions);

                    foreach ($newProd->options as $option) {
                        foreach ($newOptions as $shopifyOption) {
                            if ($option->id == $shopifyOption['id']) {
                                if (!empty($shopifyOption['values'])) {
                                    $option->values()->createMany($shopifyOption['values']);
                                }
                            }
                        }
                    }
                }
            }

            // Update the Images
            if (!empty($shopifyProductImages)) {
                // Update existing images and flag existing images for removal
                foreach ($newProd->images as $image) {
                    $didImageExist = false;
                    foreach ($shopifyProductImages as $shopifyImage) {
                        if ($image->id == $shopifyImage['id']) {
                            $didImageExist = true;
                            $image->fill($shopifyImage);
                            $image->save();

                            // Reset the image variants
                            $image->variants()->delete();
                            if (!empty($shopifyImage['variant_ids'])) {
                                $image->variants()->createMany($shopifyImage['variant_ids']);
                            }
                        }
                    }

                    // If the existing image did not exist in Shopify, flag for deletion
                    if (!$didImageExist) {
                        $image->delete();
                    }
                }

                $newImages = [];
                foreach ($shopifyProductImages as $shopifyImage) {
                    $didImageExist = false;
                    foreach ($newProd->images as $image) {
                        if ($shopifyImage['id'] == $image->id) {
                            $didImageExist = true;
                        }
                    }
                    if (!$didImageExist) {
                        $newImages[] = $shopifyImage;
                    }
                }
                if (!empty($newImages)) {
                    $newProd->images()->createMany($newImages);

                    foreach ($newProd->images as $image) {
                        foreach ($newImages as $shopifyImage) {
                            if ($image->id == $shopifyImage['id']) {
                                if (!empty($shopifyImage['variant_ids'])) {
                                    $image->variants()->createMany($shopifyImage['variant_ids']);
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // New Product
            $newProd = new self($shopifyProduct);

            $newProd->save();

            // Save the Tags
            if (!empty($shopifyProductTags)) {
                $newProd->tags()->createMany($shopifyProductTags);
            }

            // Save the Variants
            if (!empty($shopifyProductVariants)) {
                $newProd->variants()->createMany($shopifyProductVariants);
            }

            // Save the Options
            if (!empty($shopifyProductOptions)) {
                $newProd->options()->createMany($shopifyProductOptions);

                foreach ($shopifyProductOptions as $option){
                    if (!empty($option['values'])) {
                        foreach ($newProd->options as $prodOption) {
                            if ($prodOption->id == $option['id']) {
                                $prodOption->values()->createMany($option['values']);
                            }
                        }
                    }
                }
            }

            // Save the Images
            if (!empty($shopifyProductImages)) {
                $newProd->images()->createMany($shopifyProductImages);

                foreach ($shopifyProductImages as $image) {
                    if (isset($image['variant_ids']) && !empty($image['variant_ids'])) {
                        foreach ($newProd->images as $prodImage) {
                            if ($prodImage->id == $image['id']) {
                                $prodImage->variants()->createMany($image['variant_ids']);
                            }
                        }
                    }
                }
            }
        }

        $this->attributes = $newProd->attributes;
        $this->original = $newProd->original;

        return $this;
    }

    protected function convertDateTimezoneToDateTime(string $dateTimezone = null, string $format = null)
    {
        if (empty($dateTimezone)) {
            return null;
        }

        if (!isset($format) || empty($format)) {
            $dateTimeObj = \DateTime::createFromFormat('Y-m-d\TH:i:sT', $dateTimezone);
        } else {
            $dateTimeObj = \DateTime::createFromFormat($format, $dateTimezone);
        }

        if ($dateTimeObj !== false) {
            return $dateTimeObj->format('Y:m:d H:i:s');
        }

        return null;
    }

    protected function explodeTags(int $prodId, string $tags)
    {
        $tagArray = explode(', ', $tags);

        foreach ($tagArray as $k => $v) {
            $tagArray[$k] = ['product_id' => $prodId, 'value' => $v];
        }

        return $tagArray;
    }
}
