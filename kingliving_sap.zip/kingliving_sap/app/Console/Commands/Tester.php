<?php

namespace App\Console\Commands;

use App\Console\AbstractCommand;
use App\Sap\Services\Index\Products;
use App\Sap\ParentProductPackage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Sap\Product;

class Tester extends AbstractCommand
{
    const PROGRESS_BAR_FORMAT = 'debug';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:tester
                              {store_id : The integrations Store ID for the Sap Store}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Function Test command';

    /**
     * Execute the console command.
     *
     * @param  \App\DripEmailer $drip
     * @return mixed
     */
    public function handle()
    {
        parent::handle();
        echo "\n\n";
        $this->info('Tester::handle() EXECUTED');
        $time_start = microtime(true);

        $product = Product::where('id', 6934)->first();
        $product->delete();
        $product = Product::where('id', 6935)->first();
        $product->delete();
        $product = Product::where('id', 6936)->first();
        $product->delete();
        $product = Product::where('id', 6937)->first();
        $product->delete();
        dd('done');


        $hashed_random_password = Hash::make('QWEasdZXC_123');
        dd($hashed_random_password);


        $store_id = $this->argument('store_id');
        $data = Products::syncProductToMagento(3,974);
        dd($data);
        // var_dump($data);
        // // $list = [
        // //     8 => 3911,
        // //     4 => 3954,
        // //     3 => 3993,
        // //     // 5 => 4041,
        // //     // 6 => 4075
        // // ];
        // // foreach ($list as $store_id => $productId) {
        // //     $data = Products::syncProductToMagento($store_id,$productId);
        // //     var_dump($data);
        // // }

        // dd();

        Products::generateProductSubRange(3, 'ASPN', 1);


        


        die();
        // ----------------------------------------------------------------------
        // SYNC TO MAGENTO
        // ----------------------------------------------------------------------
        $stores = DB::table('stores')->where('is_active',1)->get();
        foreach ($stores as $store) {
            $products = DB::table('package_products')->where('store_id',$store->id)->where('sub_range_code','RUGKL')->get();
            foreach ($products as $product) {
                if ($product){
                    $data = Products::syncProductToMagento($store->id,$product->id);
                    var_dump($data);
                }
                
            }
        }
        dd('done');
        
        // ----------------------------------------------------------------------
        // SYNC FROM SAP
        // ----------------------------------------------------------------------
        // $stores = DB::table('stores')->where('is_active',1)->get();
        // foreach ($stores as $store) {
        //     Products::generateProductSubRange($store->id,'J2',0);
        // }
        
        // dd('done');


        // ----------------------------------------------------------------------
        // Test code here
        // ----------------------------------------------------------------------


        // $item_data = Products::generate();
//        $store_id = $this->argument('store_id');
//
//        $stores = \App\DB\Stores::find($store_id); //initialsize first store
//        $baseUrl = $stores->sap_endpoint;
//        $pass = $stores->sap_auth;
//        $sapClient = new \App\Sap\Client($baseUrl, $pass, true);
//
//        $sapProducts = $sapClient->getProductInterface();
//        $allSubRange = $sapProducts->getItemSubRange('DELTA3');
//        print_r($allSubRange);
//        dd('tesst');


        // Products::populatePackageSubRange($store_id);
        $subRanges = ParentProductPackage::where('store_id',$store_id)->get();
        if (count($subRanges) > 0 ){
            foreach ($subRanges as $subRange) {
                echo "Sync sub range" . $subRange->sub_range_code ."\n\n";
                $item_data = Products::generateProductSubRange($store_id,$subRange->sub_range_code,0);
            }
        }
    
        dd('done');

        $data = Products::syncToMagento($store_id);
        dd($data);
        $this->info($data['message']);

      
        // ----------------------------------------------------------------------
        // Test code finished
        // ----------------------------------------------------------------------

        echo "\n\n";

        $time_end = microtime(true);
        $execution_time = $time_end - $time_start;

        $this->info("Tester::handle() COMPLETED in {$execution_time}");

        echo "\n\n";

        return;
    }
}