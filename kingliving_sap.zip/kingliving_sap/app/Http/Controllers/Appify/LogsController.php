<?php

namespace App\Http\Controllers\Appify;

use App\Http\Controllers\Controller;
use App\Http\Resources\LogsCollection;
use App\DB\TransactionLog;

use Illuminate\Http\Request;

class LogsController extends Controller
{
    public function __construct()
    {
        // Todo: AUTH VALIDATION HERE
    }

    public function index(Request $request)
    {
        $data = array('dashboard' => 'logsBoard');
        return view('master', $data);
    }

    public function listing()
    {
        return ['collection' => new LogsCollection(TransactionLog::where('store_id', store()->id)->get())];
    }

    public function view($log_id)
    {
        $log = TransactionLog::findOrFail($log_id);

        $data_params = array();
        $data_params['id'] = $log_id;
        $data_params['name'] = $log->message;
        $data_params['data'] = $log->data;
        $data_params['created_at'] = $log->created_at;

        $data = array('dashboard' => 'logsView', 'data' => $data_params);
        return view('data', $data);
    }

    public function delete($log_id)
    {
        $log = TransactionLog::findOrFail($log_id);
        $log->delete();

        $data = array('dashboard' => 'logsBoard');
        return view('master', $data);
    }

    public function clear()
    {
        TransactionLog::where('store_id', store()->id)->delete();

        $data = array('dashboard' => 'logsBoard');
        return view('master', $data);
    }


    public function download($log_id)
    {
        $data = array('dashboard' => 'logsBoard');
        return view('master', $data);
    }
}
