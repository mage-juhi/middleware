<?php

namespace App\Console\Commands;

use App\Console\AbstractCommand;

class ShopifyProductCount extends AbstractCommand
{
    protected $signature = 'app:shopify:product-count
                                {store_id : The integrations Store ID for the Shopify Store}';

    protected $description = 'Find out the total number of Products and Variants in Shopify';

    public function handle()
    {
        parent::handle();

        shopify()->countProductsAndVariants();
    }
}
