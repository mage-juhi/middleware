import React from 'react';
import ReactDOM from 'react-dom';
import {AppProvider, Page, Card} from '@shopify/polaris';
import Layouts from './components/Layouts';

ReactDOM.render(
    <AppProvider>
        <Page fullWidth={true}>
            <Layouts />
        </Page>
    </AppProvider>,
    document.querySelector('#app')
);