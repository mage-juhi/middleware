<?php

namespace App\Sap\Product;

use Illuminate\Database\Eloquent\Model;

class ConfigurableMapping extends Model
{

    protected $table = 'configurable_mapping_table';
    protected $primaryKey = 'id';
    public $timestamps = false;

    protected $fillable = [
        'product_id',
        'parent_id',
    ];

    public function parent()
    {
        return $this->belongsTo('App\Sap\Product', 'parent_id');
    }

    public function findLinks($productId) {
        return self::where("parent_id",$productId)->get();
    }

}