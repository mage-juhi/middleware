<?php

namespace App\Sap\Product;

use Illuminate\Database\Eloquent\Model;

class Cushioning extends Model
{
    protected $table = 'cushioning';
    protected $primaryKey = 'id';

    protected $fillable = [
        'product_id',
        'cushioning_code',
        'cushioning_name',
        'custom_image'
    ];


    public function product()
    {
        return $this->belongsTo('App\Sap\Product', 'product_id');
    }


}