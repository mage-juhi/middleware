<?php

namespace App\Sap\Product;

use Illuminate\Database\Eloquent\Model;

class FinishLink extends Model
{
    protected $table = 'finish_link';
    protected $primaryKey = 'id';

    protected $fillable = [
        'store_id',
        'product_id',
        'finish_id'
    ];

    public function product()
    {
        return $this->belongsTo('App\Sap\Product', 'product_id');
    }

    public function finish()
    {
        return $this->belongsTo('App\Sap\Product\Finish', 'finish_id');
    }

}