<?php

namespace App\Sap\Product\Material;

use Illuminate\Database\Eloquent\Model;
use App\Sap\Product\Material\Option\Type;
use App\Sap\Product\MaterialLink;
use App\Sap\Product;
use App\Sap\ProductEntityValue;
use App\DB\Stores;

class Option extends Model
{
    protected $table = 'material_group_options';
    protected $primaryKey = 'id';

    protected $fillable = [
        'type_id',
        'name',
        'range_code',
        'custom_image',
        'is_active'
    ];


    public function materialType()
    {
        return $this->belongsTo('App\Sap\Product\Material\Option\Type', 'type_id');
    }
    public function materialValue()
    {
        return $this->hasMany('App\Sap\Product\Material\Option\Value', 'group_option_id');
    }


    public function materialLink()
    {
        return $this->belongsTo('App\Sap\Product\MaterialLink', 'material_group_option_id');
    }


    public function indexMaterial($product, $storeId, $kg_price = null){

        $materialFill= array();
        //$storeId = 1;
        $materialsRange = $product['material'];
        $prod = Product::where('store_id', $storeId)->where('sku', $product['item']['sku'])->first();
        $materialLinkData = array();

        foreach ($materialsRange as $k => $material){
            if (!isset($material['range'])) continue;

            if (isset($material['sale_type']) && isset($material['code']) ){
                $code = $material['code'];
                if ($code == 'F GL 2') {
                    // set sale type to EAV data
                    $sale_type = ProductEntityValue::where('store_id', $storeId)->where('attribute_id', 8)->where('product_id', $prod->id)->first();
                    if ($sale_type) {
                        // $canSave = true;
                        // $caStoreId = Stores::where('magento_store_code','ca')->first();
                        // if (isset($caStoreId->id) && $sale_type->value == 'Ongoing' && $storeId == $caStoreId->id)
                        //     $canSave = false;

                        // if ($canSave){
                        $sale_type->value = $material['sale_type'];
                        $sale_type->save();
                        // }
                    } else {
                        $sale_type = new ProductEntityValue();
                        $sale_type->attribute_id = 8;
                        $sale_type->store_id = $storeId;
                        $sale_type->product_id = $prod->id;
                        $sale_type->value = $material['sale_type'];
                        $sale_type->save();
                    }
                }
            }

            $rangeArray = $material['range'];
            $rangeFill = array();
            // Material Type
            $materialType = Type::where('title', $material['type'])->first();
            if (!$materialType){
                $materialType = new Type(['title' => $material['type']]);
                $materialType->save();
            }

            foreach($rangeArray as $k => $range){
                $isNewRange = false;
                $newRange = self::where('range_code', $range['code'])->first();

                $rangeFill['type_id'] = $materialType->id;
                $rangeFill['name'] = $range['name'];
                $rangeFill['range_code'] = $range['code'];
                $rangeFill['custom_image'] = ($newRange) ? $newRange->custom_image : '';

                if ($newRange) {
                    // Range Exists, Update Data
                    $rangeFill['is_active'] = $newRange->is_active;
                    $newRange->fill($rangeFill);
                    $newRange->save();
                } else {
                    // New Range
                    $isNewRange = true;
                    $rangeFill['is_active'] = 0; // set disable state for new Swatches
                    $newRange = new self($rangeFill);
                    $newRange->save();
                }
                
                if ($prod){
                    $materialLink = MaterialLink::where('product_id', $prod->id)->where('material_group_option_id', $newRange->id)->where('code', $material['code'])->where('store_id', $storeId)->first();
                    $materialLinkFill = array();
                    $materialLinkFill['product_id'] = $prod->id;
                    $materialLinkFill['material_group_option_id'] = $newRange->id;
                    $materialLinkFill['cushion_id'] = 1;
                    $materialLinkFill['code'] = $material['code'];
                    $materialLinkFill['sell_price'] = isset($material['sell_price']) ? $material['sell_price'] : 0;
                    $materialLinkFill['rrp_price'] = isset($material['rrp_price']) ? $material['rrp_price'] : 0;
                    /*if($material['sale_type'] == "Ongoing") {
                        $materialLinkFill['rrp_price'] = isset($material['sell_price']) ? $material['sell_price'] : 0;
                    }*/
                    $materialLinkFill['king_guard_price'] = isset($material['king_guard_price']) ? $material['king_guard_price'] : 0;
                    $materialLinkFill['king_guard_full_price'] = isset($kg_price['KingGuardFullPrice']) ? $kg_price['KingGuardFullPrice'] : 10;
                    $materialLinkFill['king_guard_disc_price'] = isset($kg_price['KingGuardDiscPrice']) ? $kg_price['KingGuardDiscPrice'] : 10;
                    $materialLinkFill['meterage'] = isset($material['meterage']) ? $material['meterage'] : 0;

                    $materialLinkFill['store_id'] = $storeId;
                    if ($materialLink) {
                        // materialLink Exists, Update Data
                        $materialLink->fill($materialLinkFill);
                        $materialLink->save();
                    } else {
                        // New materialLink
                        $materialLink = new MaterialLink($materialLinkFill);
                        $materialLink->save();
                    }
                    $materialLinkData[] = ['material_group_option_id' => $newRange->id, 'code' => $material['code']];
                }

                $colours = $range['colours'];
                $codes = array();

                // This is for temporary fix to ignore Colours for Malibu Aur and Raf, Bowen Pure White
                // this will be remove after the KL-1382 is deployed.
//                if ($range['code'] == 'MBU' || $range['code'] == 'BWN') {
//                    $colours = collect($colours)->filter(function($colour, $key) {
//                        return $key != 'Aut' && $key != 'Raf' && $key != 'PUW';
//                    })->toArray();
//                }

                if ($range['code'] == 'BWN') {
                    $colours = collect($colours)->filter(function($colour, $key) {
                        return $key != 'PUW';
                    })->toArray();
                }

                if ($range['code'] == 'OLS') {
                    $colours = collect($colours)->filter(function($colour, $key) {
                        $olsenDisallow = ['STN','SMK','HCK','SLT','HBL'];
                        return !in_array($key,$olsenDisallow);
                    })->toArray();
                }

                foreach($colours as $k => $colour){
                    $colourFill = array();
                    $colourFill['allow_king_guard'] = isset($colour[0]['allow_king_guard']) ? $colour[0]['allow_king_guard'] : '' ;
                    $colourFill['colour_name'] = isset($colour[0]['colour_name']) ? $colour[0]['colour_name'] : '';
                    $colourFill['colour_image'] = isset($colour[0]['colour_image']) ? $colour[0]['colour_image'] : '';
//                    $colourFill['custom_image'] = '';
                    if ($isNewRange) $colourFill['is_active'] = 0;
                    $newRange->materialValue()->updateOrCreate(['colour_code' => $colour[0]['colour_code']], $colourFill);
                    $codes[] = $colour[0]['colour_code'];
                }
                // delete unused
                foreach ($newRange->materialValue as $middleColor) {
                    if (!in_array($middleColor->colour_code, $codes)){
                        $middleColor->delete();
                    }
                }
            }
        }


        // Unlink material
        if ($prod){
            foreach ($prod->materialLinks as $materialLink) {
                $materialLinkKey = ['material_group_option_id' => $materialLink->material_group_option_id, 'code' => $materialLink->code];
                if (!in_array($materialLinkKey, $materialLinkData)){
                    $materialLink->delete();
                }
            }
        }
    }
}