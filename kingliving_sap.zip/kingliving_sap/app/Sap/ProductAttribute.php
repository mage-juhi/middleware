<?php

namespace App\Sap;

use Illuminate\Database\Eloquent\Model;

class ProductAttribute extends Model {
	protected $table = 'product_attribute';
    protected $primaryKey = 'id';

	protected $fillable = [
        'id',
        'code',
        'name',
        'type',
        'is_required',
        'default_value',
    ];
}