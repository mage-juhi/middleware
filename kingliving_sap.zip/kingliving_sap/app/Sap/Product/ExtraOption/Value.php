<?php

namespace App\Sap\Product\ExtraOption;

use Illuminate\Database\Eloquent\Model;

class Value extends Model
{
    protected $table = 'extra_group_option_value';
    protected $primaryKey = 'id';

    protected $fillable = [
        'extra_group_option_id',
        'store_id',
        'quantity',
        'sell_price',
        'rrp_price',
        'is_required'
    ];

}