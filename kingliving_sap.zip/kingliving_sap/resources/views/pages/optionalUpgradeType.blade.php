<?php

session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}

if (aclToClient($_SESSION['username']))
    header("Location:/dashboard");
?>
	@extends('layouts.default')
	@section('content')
    <div class="container">
		<h1 class="display-3">Manager Optional Upgrade Type</h1>
	    <a href="/add-optional-upgrade-type" class="btn btn-success btn-add">Add</a>
		<div class="table-responsive">
			<table class="table table-hover">
				<thead>
					<tr>
						<th>Id</th>
						<th>Name</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($types as $key => $type){?>
					<tr>
						<td><?php echo $type->id;?></td>
						<td><?php echo $type->name; ?></td>
						<td>
							<a href="optional-upgrade-type/<?php echo $type->id;?>"​ type="button" class="btn btn-warning btn-edit">Edit</a>
							<!-- <button class="deleteProductEntity btn btn-danger" data-id="<?php echo $type->id;?>">Delete</button> -->
							<!-- <button data-url="#"​ type="button" data-target="#delete" data-toggle="modal" class="btn btn-danger btn-delete">Delete</button> -->
						</td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
    </div>
@stop
