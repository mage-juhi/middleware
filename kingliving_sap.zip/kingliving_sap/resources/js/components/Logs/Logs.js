import React from 'react';
import LogsList from '../../routes/LogsList';

class Logs extends React.Component{

    render(){
        return (
            <LogsList />
        );
    }
}

export default Logs;