<form class="form-inline mt-2 mt-md-0" _lpchecked="1" method="get" id="keyword-form-search">
    <input class="form-control mr-sm-2" type="text" placeholder="Search id, sku code" aria-label="Search"
           name="search" value="<?= $search ?>">
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
</form>
<script>
    (function($){
        $(function () {
            $('#keyword-form-search').submit(function(e){
                e.preventDefault();
                let search = encodeURI($(this).find('[name="search"]').val());
                let params = window.location.search;
                params = params.replace(/page=\d+/, "");
                if (search)
                    window.location= "/<?=explode("/",app('request')->path())[0]?>/search/" + search + params;
                else
                    window.location= "/<?=explode("/",app('request')->path())[0]?>" + params;
            });
        })
    })(jQuery);
</script>
