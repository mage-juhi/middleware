@extends('layouts.default')
@section('content')
<div class="row">
 <div class="col-sm-8 offset-sm-2">
    <h1 class="display-3">Edit Product Attribute</h1>
  <div>
      <form id="updateProductAttribute" method="post" action="{{route('updateProductAttribute')}}">
            <input type="hidden"  name="id" value="<?php if (isset($productAttribute)) echo $productAttribute->id;?>">
        
          <div class="form-group">    
              <label for="code">Code</label>
              <input type="text" class="form-control" name="code" value="<?php if (isset($productAttribute)) echo $productAttribute->code;?>"/>
          </div>

          <div class="form-group">
              <label for="name">Name</label>
              <input type="text" class="form-control" name="name" value="<?php if (isset($productAttribute)) echo $productAttribute->name;?>"/>
          </div>

          <div class="form-group">
              <label for="type">Type:</label>
              <select class="select form-control" name="type" id="type">
                <option value="">Please select type</option>
                <option value="int" <?php if (isset($productAttribute) && $productAttribute->type == "int") echo "selected";?>>Int</option>
                <option value="string" <?php if (isset($productAttribute) && $productAttribute->type == "string") echo "selected";?>>String</option>
                <option value="text" <?php if (isset($productAttribute) && $productAttribute->type == "text") echo "selected";?>>Text</option>
              </select>
          </div>
          <div class="form-group">
              <label for="isrequired">Required</label>
              <div class="col-sm-12 form-group">
	              <div class="col-sm-6 radio-inline">
	              		<input type="radio" name="isrequired" value="1" <?php if (isset($productAttribute) && $productAttribute->is_required == "1") echo "checked";?> /> Yes
	              </div>
	              <div class="radio-inline">
	              		<input type="radio" name="isrequired" value="0" <?php if (isset($productAttribute) && $productAttribute->is_required == "0") echo "checked";?>/> No
	              </div>
              </div>
          </div>
          <div class="form-group">
              <label for="defaultvalue">Default Value</label>
              <input type="text" class="form-control" name="defaultvalue" value="<?php if (isset($productAttribute)) echo $productAttribute->default_value;?>"/>
          </div>                        
          <button type="submit" class="btn btn-success">Save</button>
      </form>
  </div>
</div>
</div>
<script type="text/javascript">
jQuery(document).ready(function($) {
  function setvalidate(_type)
  {
      switch(_type) {
        case "int":
          $("input[name=defaultvalue]").attr("number",true);
          $("input[name=defaultvalue]").attr("type","number");
          $("input[name=defaultvalue]").attr("min","0");
          $("input[name=defaultvalue]").removeAttr("minlength");
          break;
        case "string":
          $("input[name=defaultvalue]").removeAttr("number");
          $("input[name=defaultvalue]").removeAttr("min");
          $("input[name=defaultvalue]").attr("type","text");
          $("input[name=defaultvalue]").attr("minlength","3");
          break;
        case "text":
          $("input[name=defaultvalue]").removeAttr("number");
          $("input[name=defaultvalue]").removeAttr("min");
          $("input[name=defaultvalue]").attr("type","text");
          $("input[name=defaultvalue]").attr("minlength","3");
          break;
      }
  };
  function checkvalidate(_type,_isrequired)
  {
    if(_isrequired == "1")
    {
      $("input[name=defaultvalue]").prop('required', true);
      setvalidate(_type);
    }
    else
    {
      $("input[name=defaultvalue]").prop('required', false);
      setvalidate(_type)
    }    
  }   
  $("select#type").change(function(){
    var _type = $("select#type").val();
    var _isrequired = $("input[name=isrequired]:checked").val();
    checkvalidate(_type,_isrequired);
  });
  $("input[name=isrequired]").click(function(){
    var _type = $("select#type").val();
    var _isrequired = $("input[name=isrequired]:checked").val();
    checkvalidate(_type,_isrequired)
  });
  $("select#type").trigger("change");
  $("#updateProductAttribute").validate({
    rules: {
      code : {
        required: true,
        minlength: 3
      },      
      name : {
        required: true,
        minlength: 3
      },
      type: {
        required: true
      },
      isrequired: {
        required: true
      }
    },
    messages : {
      code: {
        required: "Please enter attribute code",
        minlength: "Code should be at least 3 characters"
      },
      name: {
        required: "Please enter attribute name",
        minlength: "Name should be at least 3 characters"
      },
      type: {
        required: "Please select attribute type"
      },
      isrequired: {
        required: "Please choose attribute required"
      }
    }
  });
});
</script>
@stop