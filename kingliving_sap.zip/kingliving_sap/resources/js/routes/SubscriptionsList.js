import React from 'react';
import {Card, FilterType, Pagination, Stack, ResourceList, Select, TextField, TextStyle} from '@shopify/polaris';

const API_BASE_URL = '/subscriptions/';
class SubscriptionsList extends React.Component{
    state = {
        selectedItems: [],
        searchValue: '',
        isLoading: false,
        error: null,
        listItems: [],
        isFirstPage: true,
        isLastPage: false,
        currentPage: 1,
        lastPage: 1,
    };

    componentDidMount(){
        const page = this.getQueryStringValue('page');
        Promise.resolve(
            this.setState(() => ({currentPage: page ? page : 1}))
        );
        console.log('components before ' + this.state.currentPage);
        this.getSubscriptions(this.state.currentPage);
        console.log('components after ' + this.state.currentPage);
    }

    getQueryStringValue(key) {
        const value = decodeURIComponent(
            window.location.search.replace(
                new RegExp(
                    '^(?:.*[&\\?]' +
                    encodeURIComponent(key).replace(/[\.\+\*]/g, '\\$&') +
                    '(?:\\=([^&]*))?)?.*$',
                    'i'
                ),
                '$1'
            )
        );
        return value ? value : null;
    }

    async getSubscriptions(pagenum){
        try{
            this.setState({isLoading: true});
            const response = await fetch(API_BASE_URL + 'api/list' + '?page=' + pagenum);
            const subslist = await response.json();
            let newArr = []
            for (var i=0; i<subslist.data.collection.length; i++)
            {
                subslist.data.collection[i].url= API_BASE_URL + subslist.data.collection[i].id;
                newArr.push(subslist.data.collection[i]);
            }
            this.setState({ listItems:newArr, isLoading:false, currentPage: subslist.meta.current_page, lastPage: subslist.meta.last_page});
            if(subslist.meta.current_page == subslist.meta.last_page){ //check last page
                this.setState({isFirstPage:false,isLastPage:true});
            }
            if(subslist.meta.current_page == 1){                        //check first page
                this.setState({isFirstPage:true,isLastPage:false});
            }
        }catch(err){
            this.setState({isLoading:false});
            console.error(err);
        }
    }

    handleSearchChange = (searchValue) => {
        this.setState({searchValue});
        console.log(this.state.searchValue);
    }

    handleSelectionChange = (selectedItems) => {
        this.setState({selectedItems});
    }

    handlePreviousPage = () =>{
        let currPage = this.state.currentPage;
        if(currPage != 1 ) {
            currPage -= 1;
            this.setState({isFirstPage:false,isLastPage:false });
        }
        this.getSubscriptions(currPage);
    }

    handleNextPage = () =>{
        let currPage = this.state.currentPage;

        if(currPage < (this.state.lastPage) ) {
            currPage += 1;
            this.setState({isFirstPage:false,isLastPage:false });
        }
        this.getSubscriptions(currPage);

    }

    renderItem = (item) => {
        const {id,label,method,event,post_params,closure,encode} = item;
        const shortcutActions = id
            ? [{content: 'Edit Subscription', url: API_BASE_URL +'edit/' + id},{content: 'Delete Subscription', url: API_BASE_URL +'delete/' + id}]
            : null;

        return (
            <ResourceList.Item
                id={id}
                label = {label}
                method = {method}
                event = {event}
                post_params = {post_params}
                closure = {closure}
                encode = {encode}
                accessibilityLabel={`View details for ${label}`}
                shortcutActions = {shortcutActions}
                persistActions
            >
                <div>{label}</div><div>{method}</div><div>{event}</div><div>{post_params}</div><div>{closure}</div><div>{encode}</div>
            </ResourceList.Item>
        );
    };

    render(){

        const resourceName = {
            singular: 'subscription',
            plural: 'subscriptions'
        };

        const paginationMarkup = this.state.listItems.length > 0
            ? (
                <Pagination
                    hasPrevious = {!this.state.isFirstPage}
                    onPrevious={this.handlePreviousPage}
                    hasNext = {!this.state.isLastPage}
                    onNext = {this.handleNextPage}
                />
            )
            : null;

        const filterControl = (
            <ResourceList.FilterControl
                searchValue = {this.state.searchValue}
                onSearchChange = {this.handleSearchChange}
            />
        );
        //const items = [
        //    {
        //        id: 6,
        //        url: 'subscription/6',
        //        label: 'Subscription One',
        //        location: 'subscription 1'
        //    }
        //];

        const bulkActions = [
            {
                content: 'Delete Subscription',
                onAction: () => console.log('Delete bugs'),
            }
        ];

        return (
            <div>
                <Card title="Subscriptions List">
                    <ResourceList
                        resourceName = {resourceName}
                        items = {this.state.listItems}
                        renderItem = {this.renderItem}
                        selectedItems = {this.state.selectedItems}
                        onSelectionChange = {this.handleSelectionChange}
                        bulkActions = {bulkActions}
                        filterControl = {filterControl}
                    />
                    <br/>
                    <Stack distribution="center">
                        {paginationMarkup}
                    </Stack>
                    <br/>
                </Card>
            </div>
        );
    }
}

export default SubscriptionsList;
