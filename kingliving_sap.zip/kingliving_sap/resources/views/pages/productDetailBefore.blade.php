@section('before')
<div class="container mt-3 sort-option">
    <div style="text-align:center;" class="title-product">
        <h3><?= "Product Name: ".$product->name?></h3>
        <p><?= "SKU: ".$product->sku?></p>
    </div>
    <a href="/add-optional-upgrades/id/{{ $product->id }}" style="margin-bottom:10px;" class="btn btn-success btn-add">Add Optional Upgrades</a>
    <div class="accordion" id="accordionExample">
        <ul id="sortableProductType" product_id="{{ $product->id }}">
@stop
