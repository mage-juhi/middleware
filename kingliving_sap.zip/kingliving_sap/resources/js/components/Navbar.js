import React from 'react';
import {Navigation} from '@shopify/polaris';
import {OrdersMajorTwotone, ProductsMajorTwotone,SettingsMajorMonotone,CodeMajorMonotone} from '@shopify/polaris-icons';

class Navbar extends React.Component{
    render(){
        return (
            <Navigation location="/">
                <Navigation.Section
                    items={[
                        {
                            url:'/subscriptions',
                            label: 'Subscriptions',
                            icon: ProductsMajorTwotone,
                        },
                    ]}
                    separator
                />
                <Navigation.Section
                    items={[
                        {
                            url:'/logs',
                            label: 'Logs',
                            icon: CodeMajorMonotone,
                        },
                    ]}
                    separator
                />
                <Navigation.Section
                    items={[
                        {
                            url:'/settings',
                            label: 'Settings',
                            icon: SettingsMajorMonotone,
                        },
                    ]}
                    separator
                />
            </Navigation>
        );
    }
}

export default Navbar;