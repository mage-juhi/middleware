<?php
/**
 * Created by PhpStorm.
 * User: thanhdang
 * Date: 1/14/21
 * Time: 15:51
 */

namespace App\Console\Commands;
use App\Console\AbstractCommand;
use App\Sap\Services\Index\Products;

class MagentoAvailOnline extends AbstractCommand
{
    const PROGRESS_BAR_FORMAT = 'debug';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:magento:availonline
                              {store_id : The integrations Store ID for the Sap Store}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Function process sync availonline product to magento command';

    /**
     * Execute the console command.
     *
     * @param  \App\DripEmailer $drip
     * @return mixed
     */
    public function handle()
    {
        parent::handle();

        $min = \Carbon\Carbon::today()->subDays(7);
        $store_id = $this->argument('store_id');
        // \DB::connection()->enableQueryLog();
        $products = \App\Sap\Product::where('status',\App\Sap\Product::UNAVAILABLE)->where('updated_at', '<=', date($min))->where('store_id',$store_id)->get();
        // $queries = \DB::getQueryLog();
        // dd($queries);
        foreach ($products as $product) {
            Products::syncProductToMagento($store_id,$product->id);
            $product->status = \App\Sap\Product::DISABLED;
            $product->save();
        }

        return;
    }
}