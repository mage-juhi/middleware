<?php

namespace App\Shopify;

use OhMyBrew\BasicShopifyAPI;
use App\Console\ConsoleCommand;

class Client extends BasicShopifyAPI
{
    const ORDER_SYNC_TAG = 'Synced with App';

    protected $isCli = false;
    protected $cli;

    public function __construct(bool $private = false)
    {
        $this->isCli = app()->runningInConsole();
        $this->cli = new ConsoleCommand;

        return parent::__construct($private);
    }

    /**
     * App Specific Data Manipulation Functions
     */

    /**
     * Product Specific Shopify Endpoints
     */

    public function countProductsAndVariants()
    {
        if ($this->isCli) {
            $this->cli->line('');
            $this->cli->info('Counting the total number of Products in Shopify');
        }

        $shopifyProducts = $this->getAllProducts();

        $variants = [];
        foreach ($shopifyProducts as $shopifyProduct) {
            foreach ($shopifyProduct['variants'] as $shopifyVariant) {
                $variants[] = $shopifyVariant;
            }
        }

        $result = [
            'product_count' => count($shopifyProducts),
            'variant_count' => count($variants)
        ];

        if ($this->isCli) {
            $this->cli->line('');
            $this->cli->info("There are {$result['product_count']} Products in Shopify");
            $this->cli->info("There are {$result['variant_count']} Variants in Shopify");
            $this->cli->line('');
        }

        return $result;
    }

    public function getAllProducts(array $filter = [])
    {
        // Remove any page indexing as it is no longer a valid filter parameter
        if (isset($filter['page']) && !empty($filter['page'])) {
            unset($filter['page']);
        }

        // Set the number of products per page
        $productsPerPage = 250;
        if (isset($filter['limit']) && !empty($filter['limit'])) {
            $productsPerPage = (int)$filter['limit'];
            unset($filter['limit']);
        }

        $numOfProducts = $this->getProductCount($filter);

        if (is_object($numOfProducts) && $numOfProducts->errors) {
            return $numOfProducts;
        }

        $numOfProductPages = ceil($numOfProducts / $productsPerPage);

        if ($this->isCli) {
            $this->cli->line('');
            $this->cli->info("Fetching products from Shopify by pages:");
            $bar = $this->cli->getOutput()->createProgressBar($numOfProductPages);
            $bar->setFormat('debug');
            $bar->start();
        }

        $products = [];
        $nextPageId = false;
        do {
            $data = ['limit' => $productsPerPage];

            if ($nextPageId) {
                $data = ['page_info' => $nextPageId];
            }

            $data += $filter;

            $response = $this->getProducts($data, true);

            if (isset($response->link->next)) {
                $nextPageId = $response->link->next;
            } else {
                $nextPageId = false;
            }

            // If the current request fails, stop fetching and return the error
            if ($response->errors) {
                return $response;
            }

            $responseProducts = json_decode(
                json_encode($response->body->products),
                true
            );

            $products = array_merge($products, $responseProducts);

            if ($this->isCli) {
                $bar->advance();
            }
        } while ($nextPageId !== false);

        if ($this->isCli) {
            $bar->finish();
            $this->cli->line('');
        }

        return $products;
    }

    public function getProduct(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/products/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }


        $responseProduct = json_decode(
            json_encode($response->body->product),
            true
        );

        return $responseProduct;
    }

    public function getProducts(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/products.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseProducts = json_decode(
            json_encode($response->body->products),
            true
        );

        return $responseProducts;
    }

    public function getProductCount(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/products/count.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->count;
    }

    public function getProductMetafields(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/products/{$id}/metafields.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->metafields;
    }

    public function createProduct(array $payload, bool $getFullResponse = false)
    {
        $data = ['product' => $payload];
        $response = $this->rest('POST', '/admin/products.json', $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseProduct = json_decode(
            json_encode($response->body->product),
            true
        );

        return $responseProduct;
    }

    public function updateProduct(int $id, array $payload, bool $getFullResponse = false)
    {
        $data = ['product' => $payload];
        $response = $this->rest('PUT', "/admin/products/{$id}.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseProduct = json_decode(
            json_encode($response->body->product),
            true
        );

        return $responseProduct;
    }

    public function deleteProduct(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('DELETE', "/admin/products/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        if ($response->response->getStatusCode() === 200) {
            return true;
        }

        return false;
    }

    /**
     * Variant Specific Shopify Endpoints
     */

    public function createVariant(int $productId, array $payload, bool $getFullResponse = false)
    {
        $data = ['variant' => $payload];
        $response = $this->rest('POST', "/admin/products/{$productId}/variants.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseVariant = json_decode(
            json_encode($response->body->variant),
            true
        );

        return $responseVariant;
    }

    public function updateVariant(int $id, array $payload, bool $getFullResponse = false)
    {
        $data = ['variant' => $payload];
        $response = $this->rest('PUT', "/admin/variants/{$id}.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseVariant = json_decode(
            json_encode($response->body->variant),
            true
        );

        return $responseVariant;
    }

    public function deleteVariant(int $productId, int $variantId, bool $getFullResponse = false)
    {
        $response = $this->rest('DELETE', "/admin/products/{$productId}/variants/{$variantId}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        if ($response->response->getStatusCode() === 200) {
            return true;
        }

        return false;
    }

    /**
     * Inventory Specific Endpoints
     */

    public function setInventoryLevel(int $locId, int $invItemId, int $qty, bool $getFullResponse = false)
    {
        $payload = [
            'location_id' => $locId,
            'inventory_item_id' => $invItemId,
            'available' => $qty
        ];
        $response = $this->rest('POST', '/admin/inventory_levels/set.json', $payload);


        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseInventoryLevel = json_decode(
            json_encode($response->body->inventory_level),
            true
        );

        return $responseInventoryLevel;
    }

    public function adjustInventoryLevel(int $locId, int $invItemId, int $qty, bool $getFullResponse = false)
    {
        $payload = [
            'location_id' => $locId,
            'inventory_item_id' => $invItemId,
            'available_adjustment' => $qty
        ];
        $response = $this->rest('POST', '/admin/inventory_levels/adjust.json', $payload);


        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseInventoryLevel = json_decode(
            json_encode($response->body->inventory_level),
            true
        );

        return $responseInventoryLevel;
    }

    public function updateInventoryItem(int $id, array $payload, bool $getFullResponse = false)
    {
        $data = ['inventory_item' => $payload];
        $response = $this->rest('PUT', "/admin/inventory_items/{$id}.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseInventoryItem = json_decode(
            json_encode($response->body->inventory_item),
            true
        );

        return $responseInventoryItem;
    }

    public function getLocations(bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/locations.json');

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseLocations = json_decode(
            json_encode($response->body->locations),
            true
        );

        return $responseLocations;
    }

    /**
     * Order Specific Endpoints
     */

    public function updateOrder(int $id, array $payload, bool $getFullResponse = false)
    {
        $data = ['order' => $payload];
        $response = $this->rest('PUT', "/admin/orders/{$id}.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->order;
    }

    public function getAllOrders(array $filter = [])
    {
        // Remove any page indexing as it is no longer a valid filter parameter
        if (isset($filter['page']) && !empty($filter['page'])) {
            unset($filter['page']);
        }

        // Set the number of products per page
        $ordersPerPage = 250;
        if (isset($filter['limit']) && !empty($filter['limit'])) {
            $ordersPerPage = (int)$filter['limit'];
            unset($filter['limit']);
        }

        $numOfOrders = $this->getOrdersCount($filter);

        if (is_object($numOfOrders) && $numOfOrders->errors) {
            return $numOfOrders;
        }

        $numOfOrderPages = ceil($numOfOrders / $ordersPerPage);

        if ($this->isCli) {
            $this->cli->line('');
            $this->cli->info("Fetching orders from Shopify by pages:");
            $bar = $this->cli->getOutput()->createProgressBar($numOfOrderPages);
            $bar->setFormat('debug');
            $bar->start();
        }

        $orders = [];
        $nextPageId = false;
        do {
            $data = ['limit' => $ordersPerPage];

            if ($nextPageId) {
                $data = ['page_info' => $nextPageId];
            }

            $data += $filter;

            $response = $this->getOrders($data, true);

            if (isset($response->link->next)) {
                $nextPageId = $response->link->next;
            } else {
                $nextPageId = false;
            }

            // If the current request fails, stop fetching and return the error
            if ($response->errors) {
                return $response;
            }

            $responseOrders = json_decode(
                json_encode($response->body->orders),
                true
            );

            $orders = array_merge($orders, $responseOrders);

            if ($this->isCli) {
                $bar->advance();
            }
        } while ($nextPageId !== false);

        if ($this->isCli) {
            $bar->finish();
            $this->cli->line('');
        }

        return $orders;
    }

    public function getOrders(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/orders.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->orders;
    }

    public function getOrder(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/orders/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseOrder = json_decode(
            json_encode($response->body->order),
            true
        );

        return $responseOrder;
    }

    public function getOrdersCount(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/orders/count.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->count;
    }

    public function getOrderTransactions(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/orders/{$id}/transactions.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $array_data = json_decode(json_encode($response->body->transactions), true);

        return $array_data;
    }

    public function setFulfillment(int $id, array $payload, bool $getFullResponse = false)
    {
        $data = ['fulfillment' => $payload];
        $response = $this->rest('POST', "/admin/orders/{$id}/fulfillments.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $array_data = json_decode(json_encode($response->body->fulfillment), true);

        return $array_data;
    }

    /**
     * Customer Specific Endpoints
     */

    public function searchCustomers(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/customers/search.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->customers;
    }

    public function getAllCustomers(array $filter = [])
    {
        // Remove any page indexing as it is no longer a valid filter parameter
        if (isset($filter['page']) && !empty($filter['page'])) {
            unset($filter['page']);
        }

        // Set the number of products per page
        $customersPerPage = 250;
        if (isset($filter['limit']) && !empty($filter['limit'])) {
            $customersPerPage = (int)$filter['limit'];
            unset($filter['limit']);
        }

        $numOfCustomers = $this->getCustomerCount($filter);

        if (is_object($numOfCustomers) && $numOfCustomers->errors) {
            return $numOfCustomers;
        }

        $numOfCustomerPages = ceil($numOfCustomers / $customersPerPage);

        if ($this->isCli) {
            $this->cli->line('');
            $this->cli->info("Fetching customers from Shopify by pages:");
            $bar = $this->cli->getOutput()->createProgressBar($numOfCustomerPages);
            $bar->setFormat('debug');
            $bar->start();
        }

        $customers = [];
        $nextPageId = false;
        do {
            $data = ['limit' => $customersPerPage];

            if ($nextPageId) {
                $data = ['page_info' => $nextPageId];
            }

            $data += $filter;

            $response = $this->getCustomers($data, true);

            if (isset($response->link->next)) {
                $nextPageId = $response->link->next;
            } else {
                $nextPageId = false;
            }

            // If the current request fails, stop fetching and return the error
            if ($response->errors) {
                return $response;
            }

            $responseCustomers = json_decode(
                json_encode($response->body->customers),
                true
            );

            $customers = array_merge($customers, $responseCustomers);

            if ($this->isCli) {
                $bar->advance();
            }
        } while ($nextPageId !== false);

        if ($this->isCli) {
            $bar->finish();
            $this->cli->line('');
        }

        return $customers;
    }

    public function getCustomers(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/customers.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->customers;
    }

    public function getCustomerCount(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/customers/count.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->count;
    }

    public function getCustomer(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/customers/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->customer;
    }

    public function createCustomer(array $payload, bool $getFullResponse = false)
    {
        $data = ['customer' => $payload];
        $response = $this->rest('POST', '/admin/customers.json', $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->customer;
    }

    public function updateCustomer(int $id, array $payload, bool $getFullResponse = false)
    {
        $data = ['customer' => $payload];
        $response = $this->rest('PUT', "/admin/customers/{$id}.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->customer;
    }

    public function getCustomerMetaFields(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/customers/{$id}/metafields.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->metafields;
    }

    /**
     * Collect Specific Endpoints
     */

    public function getCollect(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/collects/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }


        $responseCollect = json_decode(
            json_encode($response->body->collect),
            true
        );

        return $responseCollect;
    }

    public function getCollects(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/collects.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseCollects = json_decode(
            json_encode($response->body->collects),
            true
        );

        return $responseCollects;
    }

    public function getAllCollects(array $filter = [])
    {
        // Remove any page indexing as it is no longer a valid filter parameter
        if (isset($filter['page']) && !empty($filter['page'])) {
            unset($filter['page']);
        }

        // Set the number of products per page
        $collectsPerPage = 250;
        if (isset($filter['limit']) && !empty($filter['limit'])) {
            $collectsPerPage = (int)$filter['limit'];
            unset($filter['limit']);
        }

        $numOfCollects = $this->getCollectsCount($filter);
        if (is_object($numOfCollects) && $numOfCollects->errors) {
            return $numOfCollects;
        }
        $numOfCollectPages = ceil($numOfCollects / $collectsPerPage);

        if ($this->isCli) {
            $this->cli->line('');
            $this->cli->info("Fetching collects from Shopify by pages:");
            $bar = $this->cli->getOutput()->createProgressBar($numOfCollectPages);
            $bar->setFormat('debug');
            $bar->start();
        }

        $collects = [];
        $nextPageId = false;
        do {
            $data = ['limit' => $collectsPerPage];

            if ($nextPageId) {
                $data = ['page_info' => $nextPageId];
            }

            $data += $filter;

            $response = $this->getCollects($data, true);

            if (isset($response->link->next)) {
                $nextPageId = $response->link->next;
            } else {
                $nextPageId = false;
            }

            // If the current request fails, stop fetching and return the error
            if ($response->errors) {
                return $response;
            }

            $responseCollects = json_decode(
                json_encode($response->body->collects),
                true
            );

            $collects = array_merge($collects, $responseCollects);

            if ($this->isCli) {
                $bar->advance();
            }
        } while ($nextPageId !== false);

        if ($this->isCli) {
            $bar->finish();
            $this->cli->line('');
        }

        return $collects;
    }

    public function getCollectsCount(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/collects/count.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->count;
    }

    public function createCollect(array $payload, bool $getFullResponse = false)
    {
        $data = ['collect' => $payload];
        $response = $this->rest('POST', '/admin/collects.json', $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseCollect = json_decode(
            json_encode($response->body->collect),
            true
        );

        return $responseCollect;
    }

    public function deleteCollect(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('DELETE', "/admin/collects/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        if ($response->response->getStatusCode() === 200) {
            return true;
        }

        return false;
    }

    /**
     * Collection Specific Endpoints
     */

    public function getCollection(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/collections/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseCollection = json_decode(
            json_encode($response->body->collection),
            true
        );

        return $responseCollection;
    }

    public function getCollectionProducts(int $id, array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/collections/{$id}}/products.json", $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseProducts = json_decode(
            json_encode($response->body->products),
            true
        );

        return $responseProducts;
    }

    public function getAllCollectionProducts(int $id, array $filter = [], bool $getFullResponse = false)
    {
        // Remove any page indexing as it is no longer a valid filter parameter
        if (isset($filter['page']) && !empty($filter['page'])) {
            unset($filter['page']);
        }

        // Set the number of products per page
        $productsPerPage = 250;
        if (isset($filter['limit']) && !empty($filter['limit'])) {
            $productsPerPage = (int)$filter['limit'];
            unset($filter['limit']);
        }

        $numOfProducts = $this->getCollection($id);
        if (is_object($numOfProducts) && $numOfProducts->errors) {
            return $numOfProducts;
        }
        $numOfProducts = $numOfProducts['products_count'];

        $numOfProductPages = ceil($numOfProducts / $productsPerPage);

        if ($this->isCli) {
            $this->cli->line('');
            $this->cli->info("Fetching products from collection from Shopify by pages:");
            $bar = $this->cli->getOutput()->createProgressBar($numOfProductPages);
            $bar->setFormat('debug');
            $bar->start();
        }

        $products = [];
        $nextPageId = false;
        do {
            $data = ['limit' => $productsPerPage];

            if ($nextPageId) {
                $data = ['page_info' => $nextPageId];
            }

            $data += $filter;

            $response = $this->getCollectionProducts($id, $data, true);

            if (isset($response->link->next)) {
                $nextPageId = $response->link->next;
            } else {
                $nextPageId = false;
            }

            // If the current request fails, stop fetching and return the error
            if ($response->errors) {
                return $response;
            }

            $responseProducts = json_decode(
                json_encode($response->body->products),
                true
            );

            $products = array_merge($products, $responseProducts);

            if ($this->isCli) {
                $bar->advance();
            }
        } while ($nextPageId !== false);

        if ($this->isCli) {
            $bar->finish();
            $this->cli->line('');
        }

        return $products;
    }

    /**
     * Custom Collection Specific Endpoints
     */

    public function getCustomCollection(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/custom_collections/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseCustomCollection = json_decode(
            json_encode($response->body->custom_collection),
            true
        );

        return $responseCustomCollection;
    }

    public function getCustomCollections(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/custom_collections.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseCustomCollections = json_decode(
            json_encode($response->body->custom_collections),
            true
        );

        return $responseCustomCollections;
    }

    public function getAllCustomCollections(array $filter = [])
    {
        // Remove any page indexing as it is no longer a valid filter parameter
        if (isset($filter['page']) && !empty($filter['page'])) {
            unset($filter['page']);
        }

        // Set the number of products per page
        $collectionsPerPage = 250;
        if (isset($filter['limit']) && !empty($filter['limit'])) {
            $collectionsPerPage = (int)$filter['limit'];
            unset($filter['limit']);
        }

        $numOfCollections = $this->getCustomCollectionsCount($filter);
        if (is_object($numOfCollections) && $numOfCollections->errors) {
            return $numOfCollections;
        }

        $numOfCollectionPages = ceil($numOfCollections / $collectionsPerPage);

        if ($this->isCli) {
            $this->cli->line('');
            $this->cli->info("Fetching custom collections from Shopify by pages:");
            $bar = $this->cli->getOutput()->createProgressBar($numOfCollectionPages);
            $bar->setFormat('debug');
            $bar->start();
        }

        $collections = [];
        $nextPageId = false;
        do {
            $data = ['limit' => $collectionsPerPage];

            if ($nextPageId) {
                $data = ['page_info' => $nextPageId];
            }

            $data += $filter;

            $response = $this->getCustomCollections($data, true);

            if (isset($response->link->next)) {
                $nextPageId = $response->link->next;
            } else {
                $nextPageId = false;
            }

            // If the current request fails, stop fetching and return the error
            if ($response->errors) {
                return $response;
            }

            $responseCustomCollections = json_decode(
                json_encode($response->body->custom_collections),
                true
            );

            $collections = array_merge($collections, $responseCustomCollections);

            if ($this->isCli) {
                $bar->advance();
            }
        } while ($nextPageId !== false);

        if ($this->isCli) {
            $bar->finish();
            $this->cli->line('');
        }

        return $collections;
    }

    public function getCustomCollectionsCount(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/custom_collections/count.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->count;
    }

    public function createCustomCollection(array $payload, bool $getFullResponse = false)
    {
        $data = ['custom_collection' => $payload];
        $response = $this->rest('POST', '/admin/custom_collections.json', $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseCustomCollection = json_decode(
            json_encode($response->body->custom_collection),
            true
        );

        return $responseCustomCollection;
    }

    public function updateCustomCollection(int $id, array $payload, bool $getFullResponse = false)
    {
        $data = ['custom_collection' => $payload];
        $response = $this->rest('PUT', "/admin/custom_collections/{$id}.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseCustomCollection = json_decode(
            json_encode($response->body->custom_collection),
            true
        );

        return $responseCustomCollection;
    }

    public function deleteCustomCollection(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('DELETE', "/admin/custom_collections/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        if ($response->response->getStatusCode() === 200) {
            return true;
        }

        return false;
    }

    /**
     * Smart Collection Specific Endpoints
     */

    public function getSmartCollection(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/smart_collections/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseSmartCollection = json_decode(
            json_encode($response->body->smart_collection),
            true
        );

        return $responseSmartCollection;
    }

    public function getSmartCollections(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/smart_collections.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseSmartCollections = json_decode(
            json_encode($response->body->smart_collections),
            true
        );

        return $responseSmartCollections;
    }

    public function getAllSmartCollections(array $filter = [])
    {
        // Remove any page indexing as it is no longer a valid filter parameter
        if (isset($filter['page']) && !empty($filter['page'])) {
            unset($filter['page']);
        }

        // Set the number of products per page
        $collectionsPerPage = 250;
        if (isset($filter['limit']) && !empty($filter['limit'])) {
            $collectionsPerPage = (int)$filter['limit'];
            unset($filter['limit']);
        }

        $numOfCollections = $this->getSmartCollectionsCount($filter);
        if (is_object($numOfCollections) && $numOfCollections->errors) {
            return $numOfCollections;
        }

        $numOfCollectionPages = ceil($numOfCollections / $collectionsPerPage);

        if ($this->isCli) {
            $this->cli->line('');
            $this->cli->info("Fetching smart collections from Shopify by pages:");
            $bar = $this->cli->getOutput()->createProgressBar($numOfCollectionPages);
            $bar->setFormat('debug');
            $bar->start();
        }

        $collections = [];
        $nextPageId = false;
        do {
            $data = ['limit' => $collectionsPerPage];

            if ($nextPageId) {
                $data = ['page_info' => $nextPageId];
            }

            $data += $filter;

            $response = $this->getSmartCollections($data, true);

            if (isset($response->link->next)) {
                $nextPageId = $response->link->next;
            } else {
                $nextPageId = false;
            }

            // If the current request fails, stop fetching and return the error
            if ($response->errors) {
                return $response;
            }

            $responseSmartCollections = json_decode(
                json_encode($response->body->smart_collections),
                true
            );

            $collections = array_merge($collections, $responseSmartCollections);

            if ($this->isCli) {
                $bar->advance();
            }
        } while ($nextPageId !== false);

        if ($this->isCli) {
            $bar->finish();
            $this->cli->line('');
        }

        return $collections;
    }

    public function getSmartCollectionsCount(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/smart_collections/count.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->count;
    }

    public function createSmartCollection(array $payload, bool $getFullResponse = false)
    {
        $data = ['smart_collection' => $payload];
        $response = $this->rest('POST', '/admin/smart_collections.json', $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseSmartCollection = json_decode(
            json_encode($response->body->smart_collection),
            true
        );

        return $responseSmartCollection;
    }

    public function updateSmartCollection(int $id, array $payload, bool $getFullResponse = false)
    {
        $data = ['smart_collection' => $payload];
        $response = $this->rest('PUT', "/admin/smart_collections/{$id}.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseSmartCollection = json_decode(
            json_encode($response->body->smart_collection),
            true
        );

        return $responseSmartCollection;
    }

    public function deleteSmartCollection(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('DELETE', "/admin/smart_collections/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        if ($response->response->getStatusCode() === 200) {
            return true;
        }

        return false;
    }

    /**
     * Shop Specific Endpoints
     */

    public function getShop(array $filter = null, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/shop.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseShop = json_decode(
            json_encode($response->body->shop),
            true
        );

        return $responseShop;
    }

    /**
     * Webhook Specific Endpoints
     */

    public function getAllWebhooks(array $filter = [])
    {
        // Remove any page indexing because we are fetching everything
        if (isset($filter['page']) && !empty($filter['page'])) {
            unset($filter['page']);
        }

        // Set the number of products per page
        $webhooksPerPage = 250;
        if (isset($filter['limit']) && !empty($filter['limit'])) {
            $webhooksPerPage = (int)$filter['limit'];
            unset($filter['limit']);
        }

        $numOfWebhooks = $this->getWebhookCount($filter);
        if (is_object($numOfWebhooks) && $numOfWebhooks->errors) {
            return $numOfWebhooks;
        }
        $numOfWebhookPages = ceil($numOfWebhooks / $webhooksPerPage);

        if ($this->isCli) {
            $this->cli->line('');
            $this->cli->info("Fetching webhooks from Shopify by pages:");
            $bar = $this->cli->getOutput()->createProgressBar($numOfWebhookPages);
            $bar->setFormat('debug');
            $bar->start();
        }

        $webhooks = [];
        $nextPageId = false;
        do {
            $data = ['limit' => $webhooksPerPage];

            if ($nextPageId) {
                $data = ['page_info' => $nextPageId];
            }

            $data += $filter;

            $response = $this->getWebhooks($data, true);

            if (isset($response->link->next)) {
                $nextPageId = $response->link->next;
            } else {
                $nextPageId = false;
            }

            // If the current request fails, stop fetching and return the error
            if ($response->errors) {
                return $response;
            }

            $responseWebhooks = json_decode(
                json_encode($response->body->webhooks),
                true
            );

            $webhooks = array_merge($webhooks, $responseWebhooks);

            if ($this->isCli) {
                $bar->advance();
            }
        } while ($nextPageId !== false);

        if ($this->isCli) {
            $bar->finish();
            $this->cli->line('');
        }

        return $webhooks;
    }

    public function getWebhooks(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/webhooks.json", $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseWebhooks = json_decode(
            json_encode($response->body->webhooks),
            true
        );

        return $responseWebhooks;
    }

    public function getWebhookCount(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/webhooks/count.json", $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->body->count;
    }

    public function getWebhook(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/webhooks/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseWebhook = json_decode(
            json_encode($response->body->webhook),
            true
        );

        return $responseWebhook;
    }

    public function createWebhookJson(string $topic, string $endpoint, bool $getFullResponse = false)
    {
        $payload = [
            'topic' => $topic,
            'address' => $endpoint,
            'format' => 'json'
        ];
        return $this->createWebhook($payload, $getFullResponse);
    }

    public function createWebhook(array $payload, bool $getFullResponse = false)
    {
        $data = ['webhook' => $payload];
        $response = $this->rest('POST', '/admin/webhooks.json', $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseWebhook = json_decode(
            json_encode($response->body->webhook),
            true
        );

        return $responseWebhook;
    }

    public function updateWebhook(int $id, array $payload, bool $getFullResponse = false)
    {
        $data = ['webhook' => $payload];
        $response = $this->rest('PUT', "/admin/webhooks/{$id}.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseWebhook = json_decode(
            json_encode($response->body->webhook),
            true
        );

        return $responseWebhook;
    }

    public function deleteWebhook(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('DELETE', "/admin/webhooks/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        if ($response->response->getStatusCode() === 200) {
            return true;
        }

        return false;
    }

    /**
     * Gift Card Specific Endpoints
     */

    public function getGiftCards(array $filter = [], bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/gift_cards.json', $filter);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseGiftCards = json_decode(
            json_encode($response->body->gift_cards),
            true
        );

        return $responseGiftCards;
    }

    public function getAllGiftCards(array $filter = null)
    {
        // Remove any page indexing as it is no longer a valid filter parameter
        if (isset($filter['page']) && !empty($filter['page'])) {
            unset($filter['page']);
        }

        // Set the number of products per page
        $giftCardsPerPage = 250;
        if (isset($filter['limit']) && !empty($filter['limit'])) {
            $giftCardsPerPage = (int)$filter['limit'];
            unset($filter['limit']);
        }

        $numOfGiftCards = $this->getGiftCardCount($filter);
        if (is_object($numOfGiftCards) && $numOfGiftCards->errors) {
            return $numOfGiftCards;
        }
        $numOfGiftCardPages = ceil($numOfGiftCards / $giftCardsPerPage);

        if ($this->isCli) {
            $this->cli->line('');
            $this->cli->info("Fetching gift cards from Shopify by pages:");
            $bar = $this->cli->getOutput()->createProgressBar($numOfGiftCardPages);
            $bar->setFormat('debug');
            $bar->start();
        }

        $giftCards = [];
        $nextPageId = false;
        do {
            $data = ['limit' => $giftCardsPerPage];

            if ($nextPageId) {
                $data = ['page_info' => $nextPageId];
            }

            $data += $filter;

            $response = $this->getGiftCards($data, true);

            if (isset($response->link->next)) {
                $nextPageId = $response->link->next;
            } else {
                $nextPageId = false;
            }

            // If the current request fails, stop fetching and return the error
            if ($response->errors) {
                return $response;
            }

            $responseGiftCards = json_decode(
                json_encode($response->body->gift_cards),
                true
            );

            $giftCards = array_merge($giftCards, $responseGiftCards);

            if ($this->isCli) {
                $bar->advance();
            }
        } while ($nextPageId !== false);

        if ($this->isCli) {
            $bar->finish();
            $this->cli->line('');
        }

        return $giftCards;
    }

    public function getGiftCard(int $id, bool $getFullResponse = false)
    {
        $response = $this->rest('GET', "/admin/gift_cards/{$id}.json");

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseData = json_decode(
            json_encode($response->body->gift_card),
            true
        );

        return $responseData;
    }

    public function getGiftCardCount(bool $getFullResponse = false)
    {
        $response = $this->rest('GET', '/admin/gift_cards/count.json');

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        return $response->count;
    }

    public function createGiftCard(array $payload, bool $getFullResponse = false)
    {
        $data = ['gift_card' => $payload];
        $response = $this->rest('POST', '/admin/gift_cards.json', $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseGiftCard = json_decode(
            json_encode($response->body->gift_card),
            true
        );

        return $responseGiftCard;
    }

    public function updateGiftCard(int $id, array $payload, bool $getFullResponse = false)
    {
        $data = ['gift_card' => $payload];
        $response = $this->rest('PUT', "/admin/gift_cards/{$id}.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseGiftCard = json_decode(
            json_encode($response->body->gift_card),
            true
        );

        return $responseGiftCard;
    }

    public function disableGiftCard(int $id, bool $getFullResponse = false)
    {
        $data = ['gift_card' => [
            'id' => $id
        ]];
        $response = $this->rest('POST', "/admin/gift_cards/{$id}/disable.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseGiftCard = json_decode(
            json_encode($response->body->gift_card),
            true
        );

        return $responseGiftCard;
    }

    public function adjustGiftCard(int $id, float $amount, bool $getFullResponse = false)
    {
        $data = ['adjustment' => [
            'amount' => $amount,
            'note' => 'Adjusted via ' . env('APP_NAME')
        ]];
        $response = $this->rest('POST', "/admin/api/2019-10/gift_cards/{$id}/adjustments.json", $data);

        if ($getFullResponse) {
            return $response;
        }

        if ($response->errors) {
            return $response;
        }

        $responseAdjustment = json_decode(
            json_encode($response->body->adjustment),
            true
        );

        return $responseAdjustment;
    }
}
