<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMiscTables extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cushioning', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('product_id')->unsigned();
            $table->string('cushioning_code');
            $table->string('cushioning_name');
        });

        Schema::create('legs', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('product_id')->unsigned();
            $table->string('legs_code');
            $table->string('legs_name');
            $table->integer('quantity');
            $table->boolean('is_default');
            $table->boolean('is_included');
        });

        Schema::create('exterior', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('product_id')->unsigned();
            $table->string('exterior_code');
            $table->string('exterior_name');
        });

        Schema::create('exterior_group_color', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('exterior_id')->unsigned();
            $table->string('colour_name');
            $table->string('colour_code');
            $table->string('colour_image')->nullable();
        });

        Schema::table('cushioning', function (Blueprint $table) {
            $table->foreign('product_id')->references('id')->on('package_products');
        });

        Schema::table('legs', function (Blueprint $table) {
            $table->foreign('product_id')->references('id')->on('package_products');
        });

        Schema::table('exterior', function (Blueprint $table) {
            $table->foreign('product_id')->references('id')->on('package_products');
        });
        
        Schema::table('exterior_group_color', function (Blueprint $table) {
            $table->foreign('exterior_id')->references('id')->on('exterior');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cushioning');
        Schema::dropIfExists('legs');
        Schema::dropIfExists('exterior');
        Schema::dropIfExists('exterior_group_color');
    }
}
