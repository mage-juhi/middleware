import React from 'react';
import {Page, Banner, Button, ButtonGroup, Form, FormLayout, TextField, Heading} from '@shopify/polaris';

const API_BASE_URL = '/subscriptions/';

class SubscriptionForm extends React.Component{
    state = {
        label: params[0].label,
        closure: params[0].closure,
        subId: params[0].id,
        isLoading:false,
        subData: [],
        msg: '',
        bannerLoaded: false
    };

    handleSubmit = (event) => {
        this.setState({bannerLoaded:false});
        var data = {
            label: this.state.label,
            closure: this.state.closure,
            subId: this.state.subId
        }
        fetch(API_BASE_URL + 'api/update/' + this.state.subId, {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        }).then(response => {return response.json();
        }).then(data => {
            if(data.success == "success"){
                this.setState({msg: "Subscription Updated!", bannerLoaded:true});
            }
            if(data.success == "error"){
                this.setState({msg: "Something went wrong!", bannerLoaded:true});
            }
        }).catch(function(err) {
            this.setState({bannerLoaded:false})
            console.log(err)
        });
    };

    //handleDelete = (event) => {
    //    this.setState({bannerLoaded:false});
    //
    //    fetch(API_BASE_URL + 'api/delete/' + this.state.subId, {
    //        method: 'POST',
    //        headers: {
    //            Accept: 'application/json',
    //            'Content-Type': 'application/json',
    //        }
    //    }).then(response => {return response.json();
    //    }).then(data => {
    //        if(data.success == "success"){
    //            this.setState({msg: "Subscription Deleted!", bannerLoaded:true});
    //        }
    //        if(data.success == "error"){
    //            this.setState({msg: "Something went wrong!", bannerLoaded:true});
    //        }
    //    }).catch(function(err) {
    //        this.setState({bannerLoaded:false})
    //        console.log(err)
    //    });
    //};

    handleChange = (field) => {
        return (value) => this.setState({[field]: value});
    };

    toggleBanner = () =>{
        this.setState(({bannerLoaded}) => ({bannerLoaded: !bannerLoaded}));
    };

    render(){
        const {label, closure, subId} = this.state;
        let banner;

        if(this.state.bannerLoaded){
            banner = <Banner title={this.state.msg} status="success" onDismiss={this.toggleBanner} />
        }
        return (
        <Page
            title="Edit Subscription"
            breadcrumbs={[{content: 'Back to Subscriptions', url: '/subscriptions'}]}
            >
            {banner}
            <Form onSubmit={this.handleSubmit}>
                <FormLayout>
                    <TextField
                        value={label}
                        onChange={this.handleChange('label')}
                        label="Label"
                        type="text"
                    />
                    <TextField
                        value={closure}
                        onChange={this.handleChange('closure')}
                        label="Closure"
                        type="text"
                    />
                    <TextField
                        value={subId}
                        type="hidden"
                    />
                    <ButtonGroup>
                        <Button submit primary>Submit</Button>
                    </ButtonGroup>
                </FormLayout>
            </Form>
        </Page>
        );
    }
}

export default SubscriptionForm;