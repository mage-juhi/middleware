<?php

namespace App\Sap\Product;

use Illuminate\Database\Eloquent\Model;

class MaterialLink extends Model
{
    protected $table = 'product_material_group_link';
    protected $primaryKey = 'id';

    protected $fillable = [
        'store_id',
        'product_id',
        'material_group_option_id',
        'cushion_id',
        'code',
        'sell_price',
        'rrp_price',
        'king_guard_price',
        'king_guard_full_price',
        'king_guard_disc_price',
        'meterage'
    ];

    public function product()
    {
        return $this->belongsTo('App\Sap\Product', 'product_id');
    }

    public function option()
    {
        return $this->belongsTo('App\Sap\Product\Material\Option', 'material_group_option_id');
    }

}