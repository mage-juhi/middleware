import React, {Component} from 'react';
import {
    Layout,
    Page,
    Stack,
    RadioButton
} from '@shopify/polaris';

import SettingsApiDetails from "../../routes/SettingsApiDetails";

class Settings extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: 'disabled'
        };
    }

    render() {
        const primaryAction = {content: 'Save Settings'};

        const choiceListItems = [
            {label: 'Disable', value: 'false'},
            {label: 'Enable', value: 'true'},
        ];
        const {value} = this.state;

        return (

            <Page
                title="Configuration"
                primaryAction={primaryAction}
            >
                <Layout>
                    <Layout.AnnotatedSection
                        title="Integration Status">
                        <Stack vertical>
                            <RadioButton
                                label="Enable Integration"
                                helpText="All CRON Jobs and Events will trigger actions/responses throughout entire integration."
                                checked={value === 'enabled'}
                                id="enabled"
                                name="status"
                                onChange={this.valueUpdater('status')}
                            />
                            <RadioButton
                                label="Disable Integration"
                                helpText="All CRON Jobs and Events will be disabled and perform no actions."
                                id="disabled"
                                name="status"
                                checked={value === 'disabled'}
                                onChange={this.valueUpdater('status')}
                            />
                        </Stack>
                    </Layout.AnnotatedSection>

                    <SettingsApiDetails/>

                </Layout>
            </Page>
        );
    }

    valueUpdater(field) {
        return (value) => this.setState({[field]: value});
    }
}

export default Settings;