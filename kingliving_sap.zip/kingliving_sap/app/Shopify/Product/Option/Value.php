<?php

namespace App\Shopify\Product\Option;

use Illuminate\Database\Eloquent\Model;

class Value extends Model
{
    protected $table = 'shopify_product_option_values';
    protected $primaryKey = 'id';

    protected $fillable = [
        'option_id',
        'position',
        'value'
    ];

    public $timestamps = false;

    public function option()
    {
        return $this->belongsTo('App\Shopify\Product\Option', 'option_id');
    }
}
