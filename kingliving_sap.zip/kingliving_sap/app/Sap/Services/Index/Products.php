<?php

namespace App\Sap\Services\Index;

use App\Console\ConsoleCommand;
use App\DB\Logger;
use App\Sap\OptionShowFrontendMapping;
use Monolog\Handler\StreamHandler;
use App\Sap\Product;
use App\Sap\ParentProductPackage;
use App\Sap\Product\Material\Option;
use App\Sap\Product\Exterior;
use App\Sap\Product\Finish;
use App\Sap\ProductAttribute;
use App\Sap\ProductEntityValue;
use App\Sap\Product\MaterialLink;
use App\Sap\Product\ConfigurableMapping;
use App\Sap\OptionEntityValue;
use Illuminate\Support\Facades\Log;
use App\Sap\ProductOptionIndex;
use App\Sap\ProductOptionTypeIndex;
use App\Sap\OptionTypeRequiredMapping;
use App\Sap\OptionalUpgrades;
use App\Sap\OptionalUpgradeType;

class Products
{

    public static function populatePackageSubRange($store_id = 1)
    {
        $stores = \App\DB\Stores::find($store_id); //initialsize first store
        $baseUrl = $stores->sap_endpoint;
        $pass = $stores->sap_auth;
        $sapClient = new \App\Sap\Client($baseUrl, $pass, true);

        $sapProducts = $sapClient->getProductInterface();
        $allSubRange = $sapProducts->getAllItemSubRange();
        Log::info("Sub range data");
        Log::info($allSubRange);
        if (is_array($allSubRange))
            foreach ($allSubRange as $subRange)
            {
                //$material = $sapProducts->getItemSubRange($subRange['Code']);
                $hasMaterial = 1; //assume has material until we don't
                //if (count($material) > 1)
                $subRange['Name'] = $subRange['Name'] ?? "No name provided";
                $newProductParent = ParentProductPackage::updateOrCreate(['store_id'=>$store_id,'sub_range_code'=>$subRange['Code']],[
                    'name'=>$subRange['Name'],
                    'sync_status'=>0,
                ]);

                $newProductParent->save();
            }

        return $allSubRange;
    }

    public static function generateProductSubRange($store_id = 1, $subRange, $tries = 1, $singleSku = null)
    {
        Log::info('Get product data from sub range '.$subRange);
        $stores = \App\DB\Stores::find($store_id); //initialsize first store
        $baseUrl = $stores->sap_endpoint;
        $pass = $stores->sap_auth;
        $sapClient = new \App\Sap\Client($baseUrl, $pass, true);

        $sapProducts = $sapClient->getProductInterface();
        $products = $sapProducts->getItemSubRange($subRange);
        $productList = \App\Sap\Product::where('store_id', $store_id)->where('sub_range_code', $subRange)->get();
        // Log::info($products);
        $syncedProduct = [];
        // KG price
        $kg_price = isset($products['kg_price']) ? $products['kg_price'] : null;

        if (count($products)>0){
            $subRange = \App\Sap\ParentProductPackage::where('store_id',$store_id)->where('sub_range_code', $subRange)->first();
            $subRange->sync_status = 1;
            $subRange->save();
            foreach ($products as $product){
                if (!isset($product['item']))
                {
                    // break because data is not product
                    continue;
                }

                // continue with single sync
                if ($singleSku != null && $singleSku != $product['item']['sku'])
                    continue;

                // set the product status to AVAILABLE from SAP
                $objectProduct = \App\Sap\Product::where('store_id', $store_id)->where('sku', $product['item']['sku'])->first();
                if ($objectProduct){
                    $objectProduct->magento_sync_status = 0;
                    $objectProduct->status = \App\Sap\Product::AVAILABLE;
                    $objectProduct->save();
                }

                $product['item']['store_id'] = $store_id;
                $prodObj = new Product();
                $prodObj->indexPackageProduct($product);

                $materialObj = new Option();
                $materialObj->indexMaterial($product, $store_id, $kg_price);

                $exteriorObj = new Exterior();
                $exteriorObj->indexExterior($product);

                $finishObj = new Finish();
                $finishObj->indexFinish($product);

                $syncedProduct[] = $product['item']['sku'];
            }
        }

        // set status to UNAVAILABLE
        if (count($productList)>0){
            foreach ($productList as $product) {
                if (!in_array($product->sku,$syncedProduct)){
                    $product->status = \App\Sap\Product::UNAVAILABLE;
                    $product->save();
                }
            }
        }

        if (count($products) == 0 || empty($products)) {
            Log::info("Empty reponse for ($store_id)".$subRange);

            //$subRange = \App\Sap\ParentProductPackage::where('store_id',$store_id)->where('sub_range_code', $subRange)->first();
            //$subRange->sync_status = 1;
            //$subRange->save();

            //$productSubRange = new \App\Jobs\ProcessSubRangeLines($store_id, $subRange);
            //$productSubRange->setNoFurtherAction(true);

            //dispatch($productSubRange)->delay(now()->addMinutes(30)); //delayed 30 minute dispatch

        } else {

            Log::info('Sync done '.$subRange);

            if ($tries){
                // dispatch next subrange
                $subRange = \App\Sap\ParentProductPackage::where('store_id',$store_id)->where('sync_status', 0)->first();
                // check if has sub range should be sync
                if ($subRange){
                    $productSubRange = new \App\Jobs\ProcessSubRangeLines($store_id, $subRange->sub_range_code);
                    dispatch($productSubRange);
                }
            }
        }


        return true;
    }

    public static function generate($store_id = 1)
    {
        $stores = \App\DB\Stores::find($store_id); //initialsize first store
        $baseUrl = $stores->sap_endpoint;
        $pass = $stores->access_token;
        $sapClient = new \App\Sap\Client($baseUrl, $pass, true);

        $sapProducts = $sapClient->getProductInterface();

        $products = $sapProducts->getItem();

        foreach ($products as $product){
            if (!isset($product['item']))
            {
                // break becasue data is not product
                continue;
            }
            $prodObj = new Product();
            $prodObj->indexPackageProduct($product);

            $materialObj = new Option();
            $materialObj->indexMaterial($product, $store_id);

            $exteriorObj = new Exterior();
            $exteriorObj->indexExterior($product);

            $finishObj = new Finish();
            $finishObj->indexFinish($product);
        }
    }

    public static function syncToMagento($storeId){
        $logger = self::getMagentoLogger();
        $stores = \App\DB\Stores::find($storeId);
        // get data from DB
        $products = Product::where('magento_sync_status', '=', 0)
            //->where('status','=', Product::SYNCED)
            ->where('store_id',$storeId)->get();
        $logger->info('Total Product:  '.count($products));
        $attributes = ProductAttribute::all();

        foreach ($products as $product) {
            $product_json = [];
            $data = [];
            $data['sku'] = $product->sku;
            $data['store_code'] = $stores->magento_store_code;
            $data['status'] = $product->status;
            $data['attribute']['middleware_url'] =  env('APP_URL') . 'product-detail/view/id/' . $product->id;
            $data['attribute']['sap_status'] = $product->status > 1 ? 'NOT Enabled In SAP' : 'Enabled In SAP';
            // sync item type and part code
            $data['attribute']['item_type'] = $product->item_type;
            $data['attribute']['part_code'] = $product->part_code;
            $data['attribute']['sub_range_code'] = $product->sub_range_code;
            //group the extra options first
            $grouped_extra_options = [];
            foreach ($product->extraOptions as $option) {
                $grouped_extra_options[$option->type] = 1;
            }

            if (count($grouped_extra_options) > 1)
            {
                // get extra option require price
                $minExtraOptionPrice = 0;
                $data['attribute']['extra_option_group_price'] = [];
                $data['attribute']['extra_option_group_rrp_price'] = [];
                foreach ($product->extraOptions as $option) {
                    if ($option->is_active == 0)
                        continue;
                    $optionTypeName = OptionEntityValue::getValue($option,'extra_option_type');
                    $optionType = $optionTypeName ? $optionTypeName->value : $option->type;
                    foreach ($option->extraOptionValue as $optionValue) {
                        $mappingRequired = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type',$optionType)->first();
                        $isRequired = isset($mappingRequired) ? $mappingRequired->is_required : $optionValue->is_required;
                        if ($optionValue->store_id == $product->store_id && $isRequired){
                            $tempPrice = $optionValue->sell_price * $optionValue->quantity;
                            if (!isset($data['attribute']['extra_option_group_price'][$optionType]))
                            {
                                $data['attribute']['extra_option_group_price'][$optionType]['extra_option_price'] = $tempPrice;
                            } elseif ((float) $tempPrice < (float) $data['attribute']['extra_option_group_price'][$optionType]['extra_option_price']) {
                                $data['attribute']['extra_option_group_price'][$optionType]['extra_option_price'] = $tempPrice;
                            }
                        }
                        if ($optionValue->store_id == $product->store_id && $isRequired){
                            $tempRRPPrice = $optionValue->rrp_price * $optionValue->quantity;
                            if (!isset($data['attribute']['extra_option_group_rrp_price'][$optionType]))
                            {
                                $data['attribute']['extra_option_group_rrp_price'][$optionType]['extra_option_rrp_price'] = $tempRRPPrice;
                            } elseif ((float) $tempRRPPrice < (float) $data['attribute']['extra_option_group_rrp_price'][$optionType]['extra_option_rrp_price']) {
                                $data['attribute']['extra_option_group_rrp_price'][$optionType]['extra_option_rrp_price'] = $tempRRPPrice;
                            }
                        }
                    }
                }
            } else {
                // get extra option require price
                $minExtraOptionPrice = 0;
                $minExtraOptionRRPPrice = 0;
                foreach ($product->extraOptions as $option) {
                    if ($option->is_active == 0)
                        continue;
                    foreach ($option->extraOptionValue as $optionValue) {
                        $optionTypeName = OptionEntityValue::getValue($option,'extra_option_type');
                        $optionType = $optionTypeName ? $optionTypeName->value : $option->type;
                        $mappingRequired = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type',$optionType)->first();
                        $isRequired = isset($mappingRequired) ? $mappingRequired->is_required : $optionValue->is_required;
                        if ($optionValue->store_id == $product->store_id && $isRequired){
                            $tempPrice = $optionValue->sell_price * $optionValue->quantity;
                            if ($minExtraOptionPrice == 0)
                                $minExtraOptionPrice = $tempPrice;
                            else if ($tempPrice < $minExtraOptionPrice)
                                $minExtraOptionPrice = $tempPrice;
                        }
                        if ($optionValue->store_id == $product->store_id && $isRequired){
                            $tempRRPPrice = $optionValue->rrp_price * $optionValue->quantity;
                            if ($minExtraOptionRRPPrice == 0)
                                $minExtraOptionRRPPrice = $tempRRPPrice;
                            else if ($tempRRPPrice < $minExtraOptionRRPPrice)
                                $minExtraOptionRRPPrice = $tempRRPPrice;
                        }
                    }
                }
                $data['attribute']['extra_option_price'] = $minExtraOptionPrice;
                $data['attribute']['extra_option_rrp_price'] = $minExtraOptionRRPPrice;
            }

            // sync product attribute
            foreach($attributes as $attribute){
                $entityValue = ProductEntityValue::where('store_id',$storeId)->where('attribute_id', $attribute->id)->where('product_id', $product->id)->first();
                if (isset($entityValue->id) && $attribute->code !='sku'){
                    $data['attribute'][$attribute->code] = $entityValue->value;
                }
                else if ($attribute->code == 'full_price'){
                    $materialLink = MaterialLink::where('product_id', $product->id)->where('store_id', $storeId)->orderBy('rrp_price', 'ASC')->first();
                    if (isset($materialLink))
                        $data['attribute'][$attribute->code] = $materialLink->rrp_price;
                }
                else if ($attribute->code == 'product_fromprice'){
                    $materialLink = MaterialLink::where('product_id', $product->id)->where('store_id', $storeId)->orderBy('sell_price', 'ASC')->first();
                    if (isset($materialLink))
                        $data['attribute'][$attribute->code] = $materialLink->sell_price;
                }
            }
            if ($product->sub_range_code == 'CONFIGURABLE'){
                $data['type'] = 'configurable';
                $data['attribute_type'] = $product->sub_range_name;
                $link = ConfigurableMapping::where('parent_id',$product->id)->get();
                $data['associated'] = [];
                if (count($link) > 0){
                    foreach ($link as $l) {
                        $child = Product::where('id', '=', $l->product_id)->where('store_id',$storeId)->first();
                        if ($child)
                            $data['associated'][] = $child->sku;
                    }
                }
                $data['option_data'] = [];
            } else{
                $data['type'] = 'simple';
                $data['option_data'] = self::convertData($product);
            }
            $product_json[] = $data;
            // Log::info($product_json);
            $status = magento($storeId)->syncProducts($product_json);

            if ($status){
                $product->magento_sync_status = 1;
                $product->save();
                echo "Synced product $product->id \n";
                $logger->info('Synced product '.$product->id);
            }else{
                $logger->info('Can not sync product '.$product->id);
                echo "Can not sync product $product->id \n";
            }

        }
        return true;
    }

    public static  function syncProductToMagento($storeId, $productId) {
        $stores = \App\DB\Stores::find($storeId);
        // get data from DB
        $products = Product::where('id', '=', $productId)->where('store_id',$storeId)->get();
        $attributes = ProductAttribute::all();
        $product_json = [];
        foreach ($products as $product) {
            $data = [];
            $data['sku'] = $product->sku;
            $data['store_code'] = $stores->magento_store_code;
            $data['status'] = $product->status;
            $data['attribute']['middleware_url'] =  env('APP_URL') . 'product-detail/view/id/' . $product->id;
            $data['attribute']['sap_status'] = $product->status > 1 ? 'NOT Enabled In SAP' : 'Enabled In SAP';
            // sync item type and part code
            $data['attribute']['item_type'] = $product->item_type;
            $data['attribute']['part_code'] = $product->part_code;
            $data['attribute']['sub_range_code'] = $product->sub_range_code;
            //group the extra options first
            $grouped_extra_options = [];
            foreach ($product->extraOptions as $option) {
                $grouped_extra_options[$option->type] = 1;
            }

            if (count($grouped_extra_options) > 1)
            {
                // get extra option require price
                $minExtraOptionPrice = 0;
                $data['attribute']['extra_option_group_price'] = [];
                $data['attribute']['extra_option_group_rrp_price'] = [];
                foreach ($product->extraOptions as $option) {
                    if ($option->is_active == 0)
                        continue;
                    $optionTypeName = OptionEntityValue::getValue($option,'extra_option_type');
                    $optionType = $optionTypeName ? $optionTypeName->value : $option->type;
                    foreach ($option->extraOptionValue as $optionValue) {
                        $mappingRequired = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type',$optionType)->first();
                        $isRequired = isset($mappingRequired) ? $mappingRequired->is_required : $optionValue->is_required;
                        if ($optionValue->store_id == $product->store_id && $isRequired){
                            $tempPrice = $optionValue->sell_price * $optionValue->quantity;
                            if (!isset($data['attribute']['extra_option_group_price'][$optionType]))
                            {
                                $data['attribute']['extra_option_group_price'][$optionType]['extra_option_price'] = $tempPrice;
                            } elseif ((float) $tempPrice < (float) $data['attribute']['extra_option_group_price'][$optionType]['extra_option_price']) {
                                $data['attribute']['extra_option_group_price'][$optionType]['extra_option_price'] = $tempPrice;
                            }
                        }
                        if ($optionValue->store_id == $product->store_id && $isRequired){
                            $tempRRPPrice = $optionValue->rrp_price * $optionValue->quantity;
                            if (!isset($data['attribute']['extra_option_group_rrp_price'][$optionType]))
                            {
                                $data['attribute']['extra_option_group_rrp_price'][$optionType]['extra_option_rrp_price'] = $tempRRPPrice;
                            } elseif ((float) $tempRRPPrice < (float) $data['attribute']['extra_option_group_rrp_price'][$optionType]['extra_option_rrp_price']) {
                                $data['attribute']['extra_option_group_rrp_price'][$optionType]['extra_option_rrp_price'] = $tempRRPPrice;
                            }
                        }
                    }
                }
            } else {
                // get extra option require price
                $minExtraOptionPrice = 0;
                $minExtraOptionRRPPrice = 0;
                foreach ($product->extraOptions as $option) {
                    if ($option->is_active == 0)
                        continue;
                    foreach ($option->extraOptionValue as $optionValue) {
                        $optionTypeName = OptionEntityValue::getValue($option,'extra_option_type');
                        $optionType = $optionTypeName ? $optionTypeName->value : $option->type;
                        $mappingRequired = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type',$optionType)->first();
                        $isRequired = isset($mappingRequired) ? $mappingRequired->is_required : $optionValue->is_required;
                        if ($optionValue->store_id == $product->store_id && $isRequired){
                            $tempPrice = $optionValue->sell_price * $optionValue->quantity;
                            if ($minExtraOptionPrice == 0)
                                $minExtraOptionPrice = $tempPrice;
                            else if ($tempPrice < $minExtraOptionPrice)
                                $minExtraOptionPrice = $tempPrice;
                        }
                        if ($optionValue->store_id == $product->store_id && $isRequired){
                            $tempRRPPrice = $optionValue->rrp_price * $optionValue->quantity;
                            if ($minExtraOptionRRPPrice == 0)
                                $minExtraOptionRRPPrice = $tempRRPPrice;
                            else if ($tempRRPPrice < $minExtraOptionRRPPrice)
                                $minExtraOptionRRPPrice = $tempRRPPrice;
                        }
                    }
                }
                $data['attribute']['extra_option_price'] = $minExtraOptionPrice;
                $data['attribute']['extra_option_rrp_price'] = $minExtraOptionRRPPrice;
            }


            // sync product attribute
            foreach($attributes as $attribute){
                $entityValue = ProductEntityValue::where('store_id',$storeId)->where('attribute_id', $attribute->id)->where('product_id', $product->id)->first();
                if (isset($entityValue->id) && $attribute->code !='sku'){
                    $data['attribute'][$attribute->code] = $entityValue->value;
                }
                else if ($attribute->code == 'full_price'){
                    $materialLink = MaterialLink::where('product_id', $product->id)->where('store_id', $storeId)->orderBy('rrp_price', 'ASC')->first();
                    if (isset($materialLink))
                        $data['attribute'][$attribute->code] = $materialLink->rrp_price;
                }
                else if ($attribute->code == 'product_fromprice'){
                    $materialLink = MaterialLink::where('product_id', $product->id)->where('store_id', $storeId)->orderBy('sell_price', 'ASC')->first();
                    if (isset($materialLink))
                        $data['attribute'][$attribute->code] = $materialLink->sell_price;
                }
            }
            if ($product->sub_range_code == 'CONFIGURABLE'){
                $data['type'] = 'configurable';
                $data['attribute_type'] = $product->sub_range_name;
                $link = ConfigurableMapping::where('parent_id',$product->id)->get();
                $data['associated'] = [];
                if (count($link) > 0){
                    foreach ($link as $l) {
                        $child = Product::where('id', '=', $l->product_id)->where('store_id',$storeId)->first();
                        if ($child)
                            $data['associated'][] = $child->sku;
                    }
                }
                $data['option_data'] = [];
            } else{
                $data['type'] = 'simple';
                $data['option_data'] = self::convertData($product);
            }
            $product_json[] = $data;
        }

        $logger = self::getMagentoLogger();
        $logger->info($storeId);
        $logger->info($productId);
        $logger->info(json_encode($product_json));

        return magento($storeId)->syncProducts($product_json);
    }

    public static function convertData($product)
    {
        // $prod = Product::where('sku', 'jasper-ii-package-1ab-offer-period')->first();
        $data = array();

        // cushioning option
        if ($product->cushioning){
            $productTypePosition = ProductOptionTypeIndex::getPosition($product->id,'cushionings');
            $typeOption = array();
            $is_required = [];
            $mappingRequired = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type','cushioning')->first();
            isset($mappingRequired) ? $is_required['cushioning'] = $mappingRequired->is_required : $is_required['cushioning'] = 1;
            $optionShowOnFrontEnd = OptionShowFrontendMapping::where('product_id',$product->id)->where('option_type','cushioning')->first();

            foreach ($product->cushioning as $option) {
                if ($option->is_active == 0)
                    continue;
                $name = OptionEntityValue::getValue($option,'cushioning_name');
                $position = ProductOptionIndex::getPosition($product->id,$option->id,'cushionings');
                $typeOption[] = [
                    'title' => $name ? $name->value : $option->cushioning_name,
                    'price' => 0,
                    'optioncode' => $option->cushioning_code,
                    'optionimage' => $option->custom_image,
                    'optiondata' => [
                        'image_folder' => 'cushioning',
                        'description' => $option->description,
                        'position' => $position,
                        'cylindo_data' => $option->cylindo_data,
                        'cylindo_type' => $option->cylindo_type,
                        'cylindo_data_optional' => $option->cylindo_data_optional,
                        'cylindo_type_optional' => $option->cylindo_type_optional
                    ]
                ];
            }
            if (count($typeOption) > 0)
                $data[] = [
                    'title' => 'Cushioning',
                    'optioncode' => 'cushioning',
                    'type' => 'radio',
                    'type_option' => $typeOption,
                    'optiondata' => [
                        'material_type' => 'Cushionings',
                        'productTypePosition' => $productTypePosition,
                        'is_required' => $is_required['cushioning'],
                        'option_show_on_frontend' => ($optionShowOnFrontEnd && $optionShowOnFrontEnd->is_show) ? 1 : 0
                    ]
                ];
        }

        // legs option
        if ($product->legs){
            $productTypePosition = ProductOptionTypeIndex::getPosition($product->id,'legs');
            $typeOption = array();
            $is_required = [];
            $mappingRequired = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type','legs')->first();
            isset($mappingRequired) ? $is_required['legs'] = $mappingRequired->is_required : $is_required['legs'] = 1;
            $optionShowOnFrontEnd = OptionShowFrontendMapping::where('product_id',$product->id)->where('option_type','legs')->first();

            foreach ($product->legs as $option) {
                if ($option->is_active == 0)
                    continue;

                $name = OptionEntityValue::getValue($option,'leg_name');
                $position = ProductOptionIndex::getPosition($product->id,$option->id,'legs');
                $typeOption[] = [
                    'title' => $name ? $name->value : $option->legs_name,
                    'price' => $option->total_price,
                    'optioncode' => $option->legs_code,
                    'optionimage' => $option->custom_image,
                    'optiondata' => [
                        'image_folder' => 'legs',
                        'quantity' => $option->quantity,
                        'is_default' => $option->is_default,
                        'is_included' => $option->is_included,
                        'unit_price' => $option->unit_price,
                        'total_price' => $option->total_price,
                        'description' => $option->description,
                        'position' => $position,
                        'cylindo_data' => $option->cylindo_data,
                        'cylindo_type' => $option->cylindo_type,
                        'cylindo_data_optional' => $option->cylindo_data_optional,
                        'cylindo_type_optional' => $option->cylindo_type_optional
                    ]

                ];
            }

            if (count($typeOption) > 0)
                $data[] = [
                    'title' => 'Legs',
                    'optioncode' => 'legs',
                    'type' => 'radio',
                    'type_option' => $typeOption,
                    'optiondata' => [
                        'material_type' => 'Legs',
                        'productTypePosition' => $productTypePosition,
                        'is_required' => $is_required['legs'],
                        'option_show_on_frontend' => ($optionShowOnFrontEnd && $optionShowOnFrontEnd->is_show) ? 1 : 0
                    ]
                ];
        }

        // exterior option
        if ($product->exteriorLinks){
            $productTypePosition = ProductOptionTypeIndex::getPosition($product->id,'exterior');
            $is_required = [];
            foreach ($product->exteriorLinks as $exteriorLink) {
                $exterior = $exteriorLink->exterior;
                if ($exterior->is_active == 0)
                    continue;
                $typeOption = array();
                $mappingRequired = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type',$exterior->exterior_code ? $exterior->exterior_code : '')->first();
                isset($mappingRequired) ? $is_required[$exterior->exterior_code] = $mappingRequired->is_required : $is_required[$exterior->exterior_code] = 1;
                $optionShowOnFrontEnd = OptionShowFrontendMapping::where('product_id',$product->id)->where('option_type', $exterior->exterior_code)->first();

                foreach ($exterior->exteriorColor as $option) {
                    $name = OptionEntityValue::getValue($option,'exterior_colour_name',$product->id);
                    $getObj = OptionEntityValue::getValue($option, 'cylindo_data', $product->id);
                    $option->cylindo_data = $getObj ? $getObj->value : $option->cylindo_data;
                    $getObj = OptionEntityValue::getValue($option, 'cylindo_type', $product->id);
                    $option->cylindo_type = $getObj ? $getObj->value : $option->cylindo_type;
                    $getObj = OptionEntityValue::getValue($option, 'cylindo_type_optional', $product->id);
                    $option->cylindo_type_optional = $getObj ? $getObj->value : $option->cylindo_type_optional;
                    $getObj = OptionEntityValue::getValue($option, 'cylindo_data_optional', $product->id);
                    $option->cylindo_data_optional = $getObj ? $getObj->value : $option->cylindo_data_optional;
                    $position = ProductOptionIndex::getPosition($product->id,$option->id,$exterior->exterior_name);
                    $typeOption[] = [
                        'title' => $name ? $name->value : $option->colour_name,
                        'price' => 0,
                        'optionimage' => $option->custom_image,
                        'optioncode' => $option->colour_code,
                        'optiondata' => [
                            'image_folder' => 'exterior',
                            'material_type' => 'Exterior',
                            'description' => $option->description,
                            'position' => $position,
                            'cylindo_data' => $option->cylindo_data,
                            'cylindo_type' => $option->cylindo_type,
                            'cylindo_data_optional' => $option->cylindo_data_optional,
                            'cylindo_type_optional' => $option->cylindo_type_optional
                        ]
                    ];
                }
                if (count($typeOption) > 0){
                    $name = OptionEntityValue::getValue($exterior,'exterior_name');
                    $data[] = [
                        'title' => $name ? $name->value : $exterior->exterior_name,
                        'optioncode' => $exterior->exterior_code,
                        'optionimage' => $exterior->custom_image,
                        'type' => 'radio',
                        'type_option' => $typeOption,
                        'optiondata' => [
                            'image_folder' => 'exterior',
                            'material_type' => 'Exterior',
                            'productTypePosition' => $productTypePosition,
                            'is_required' => $is_required[$exterior->exterior_code],
                            'option_show_on_frontend' => ($optionShowOnFrontEnd && $optionShowOnFrontEnd->is_show) ? 1 : 0
                        ]
                    ];
                }
            }
        }

        // finish option
        if ($product->finishLinks){
            $productTypePosition = ProductOptionTypeIndex::getPosition($product->id,'finish');
            $is_required = [];
            foreach ($product->finishLinks as $finishLink) {
                $finish = $finishLink->finish;
                if ($finish->is_active == 0)
                    continue;
                $typeOption = array();
                $mappingRequired = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type',$finish->finish_code ? $finish->finish_code : '')->first();
                isset($mappingRequired) ? $is_required[$finish->finish_code] = $mappingRequired->is_required : $is_required[$finish->finish_code] = 1;
                $optionShowOnFrontEnd = OptionShowFrontendMapping::where('product_id',$product->id)->where('option_type', $finish->finish_code)->first();

                foreach ($finish->finishColor as $option) {
                    if($option->is_active == 1) {
                        $name = OptionEntityValue::getValue($option, 'finish_colour_name', $product->id);
                        $getObj = OptionEntityValue::getValue($option, 'cylindo_data', $product->id);
                        $option->cylindo_data = $getObj ? $getObj->value : $option->cylindo_data;
                        $getObj = OptionEntityValue::getValue($option, 'cylindo_type', $product->id);
                        $option->cylindo_type = $getObj ? $getObj->value : $option->cylindo_type;
                        $getObj = OptionEntityValue::getValue($option, 'cylindo_type_optional', $product->id);
                        $option->cylindo_type_optional = $getObj ? $getObj->value : $option->cylindo_type_optional;
                        $getObj = OptionEntityValue::getValue($option, 'cylindo_data_optional', $product->id);
                        $option->cylindo_data_optional = $getObj ? $getObj->value : $option->cylindo_data_optional;
                        $position = ProductOptionIndex::getPosition($product->id, $option->id, $finish->finish_name);
                        $typeOption[] = [
                            'title' => $name ? $name->value : $option->colour_name,
                            'price' => 0,
                            'optionimage' => $option->custom_image,
                            'optioncode' => $option->colour_code,
                            'optiondata' => [
                                'image_folder' => 'finish',
                                'material_type' => 'Finish',
                                'description' => $option->description,
                                'position' => $position,
                                'cylindo_data' => $option->cylindo_data,
                                'cylindo_type' => $option->cylindo_type,
                                'cylindo_data_optional' => $option->cylindo_data_optional,
                                'cylindo_type_optional' => $option->cylindo_type_optional
                            ]
                        ];
                    }
                }
                if (count($typeOption) > 0){
                    $name = OptionEntityValue::getValue($finish,'finish_name');
                    $data[] = [
                        'title' => $name ? $name->value : $finish->finish_name,
                        'optioncode' => $finish->finish_code,
                        'optionimage' => $finish->custom_image,
                        'type' => 'radio',
                        'type_option' => $typeOption,
                        'optiondata' => [
                            'image_folder' => 'finish',
                            'material_type' => 'Finish',
                            'productTypePosition' => $productTypePosition,
                            'is_required' => $is_required[$finish->finish_code],
                            'option_show_on_frontend' => ($optionShowOnFrontEnd && $optionShowOnFrontEnd->is_show) ? 1 : 0
                        ]
                    ];
                }
            }
        }

        // extra options
        if ($product->extraOptions){
            // get type
            $productTypePosition = ProductOptionTypeIndex::getPosition($product->id,'extraOptions');
            $type = [];
            $is_required = [];
            $optionShowOnFrontEnd = [];
            foreach ($product->extraOptions as $key => $option) {
                if (!in_array($option->type,$type)){
                    $name = OptionEntityValue::getValue($option,'extra_option_type');
                    $type[] = $name ? $name->value : $option->type;
                    $mappingRequired = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type',$name ? $name->value : $option->type)->first();
                    isset($mappingRequired) ? $is_required[$name ? $name->value : $option->type] = $mappingRequired->is_required : $is_required[$name ? $name->value : $option->type] = 1;
                    $optionShowOnFrontEnd[$name ? $name->value : $option->type] = OptionShowFrontendMapping::where('product_id',$product->id)->where('option_type', $name ? $name->value : $option->type)->first();
                }
            }
            foreach ($type as $value) {
                $typeOption = array();
                foreach ($product->extraOptions as $option) {
                    if ($option->is_active == 0)
                        continue;
                    $nameTemp = OptionEntityValue::getValue($option,'extra_option_type');
                    $typeTemp = $nameTemp ? $nameTemp->value : $option->type;
                    if ($typeTemp == $value){
                        // get the extra option value with product store id
                        foreach ($option->extraOptionValue as $optionValue) {
                            if ($optionValue->store_id == $product->store_id){
                                $position = ProductOptionIndex::getPosition($product->id,$option->id,$value);
                                $name = OptionEntityValue::getValue($option,'extra_option_name');
                                $typeOption[] = [
                                    'title' => $name ? $name->value : $option->name,
                                    'price' => $optionValue->sell_price * $optionValue->quantity,
                                    'rrp_price' => $optionValue->rrp_price * $optionValue->quantity,
                                    'optioncode' => $option->sku,
                                    'optionimage' => $option->custom_image,
                                    'optiondata' => [
                                        'material_type' => 'extraOption',
                                        'sell_price' => $optionValue->sell_price * $optionValue->quantity,
                                        'rrp_price' => $optionValue->rrp_price * $optionValue->quantity,
                                        'quantity' => $optionValue->quantity,
                                        'is_required' => $optionValue->is_required,
                                        'image_folder' => 'extraOption',
                                        'description' => $option->description,
                                        'position' => $position,
                                        'cylindo_data' => $option->cylindo_data,
                                        'cylindo_type' => $option->cylindo_type,
                                        'cylindo_data_optional' => $option->cylindo_data_optional,
                                        'cylindo_type_optional' => $option->cylindo_type_optional
                                    ]
                                ];
                            }
                        }
                    }
                }

                if (count($typeOption) > 0)
                    $data[] = [
                        'title' => $value,
                        'optioncode' => $value,
                        'type' => 'radio',
                        'type_option' => $typeOption,
                        'optiondata' => [
                            'material_type' => 'extraOption',
                            'productTypePosition' => $productTypePosition,
                            'is_required' => $is_required[$value],
                            'option_show_on_frontend' => ($optionShowOnFrontEnd && $optionShowOnFrontEnd[$value] && $optionShowOnFrontEnd[$value]->is_show) ? 1 : 0
                        ]
                    ];
            }
        }

        // productuct material link
        $kingGuardPrice = [];
        $kgSAPPrice = [];
        if (count($product->materialLinks) > 0){
            $productTypePosition = ProductOptionTypeIndex::getPosition($product->id,'cover');
            foreach ($product->materialLinks as $materialLink) {
                $typeOption = array();
                $range = $materialLink->option;
                if ($range->is_active == 0)
                    continue;

                // set king guard price
                if ($materialLink->king_guard_price != 0 && !in_array($materialLink->king_guard_price,$kingGuardPrice)){
                    $kingGuardPrice[] = $materialLink->king_guard_price;
                    $kgSAPPrice[$materialLink->king_guard_price]['king_guard_full_price'] = $materialLink->king_guard_full_price;
                    $kgSAPPrice[$materialLink->king_guard_price]['king_guard_disc_price'] = $materialLink->king_guard_disc_price;
                    $kgSAPPrice[$materialLink->king_guard_price]['meterage'] = $materialLink->meterage;
                }

                $type = $range->materialType;
                foreach ($range->materialValue as $option) {
                    if($option->is_active == 0)
                        continue;
                    $name = OptionEntityValue::getValueByTable($option,'material_group_option_value','material_group_option_colour_name');
                    $typeOption[] = [
                        'title' => $name ? $name->value : $option->colour_name,
                        'price' => $materialLink->sell_price,
                        'rrp_price' => $materialLink->rrp_price,
                        'optionimage' => $option->custom_image,
                        'optioncode' => $option->colour_code,
                        'optiondata' => [
                            'allow_king_guard' => $option->allow_king_guard,
                            'cylindo_type' => 'UPHOLSTERY',
                            'cylindo_data' => $option->cylindo_data,
                            'cylindo_data_optional' => $option->cylindo_data_optional,
                            'sell_price' => $materialLink->sell_price,
                            'rrp_price' => $materialLink->rrp_price,
                            'position' => $option->position,
                            'colour_description' => $option->colour_description,
                            'colour_description_image' => $option->colour_description_image,
                        ]
                    ];
                }
                $name = OptionEntityValue::getValue($range, 'material_group_option_name') ? OptionEntityValue::getValue($range, 'material_group_option_name') : OptionEntityValue::getValueByTable($range,'material_group_option','material_group_option_name');
                    //$name = OptionEntityValue::getValueByTable($range,'material_group_option','material_group_option_name');
                $position = ProductOptionIndex::getPosition($product->id,$range->id,$type->title);
                $data[] = [
                    'title' => $name ? $name->value : $range->name,
                    'optioncode' => $range->range_code,
                    'type' => 'radio',
                    'type_option' => $typeOption,
                    'optionimage' => $range->custom_image,
                    'optiondata' => [
                        'code' => $materialLink->code,
                        'sell_price' => $materialLink->sell_price,
                        'rrp_price' => $materialLink->rrp_price,
                        'king_guard_price' => $materialLink->king_guard_price,
                        'material_type' => $type->title,
                        'position' => $position ? $position : $range->position,
                        'productTypePosition' => $productTypePosition
                    ]
                ];
            }
        }

        // king guard options
        if(count($kingGuardPrice) > 0){
            foreach ($kingGuardPrice as $kingGuard) {
                $data[] = [
                    'title' => 'KingGuard® Fabric Protection',
                    'optioncode' => 'king_guard_'.$kingGuard,
                    'type' => 'radio',
                    'optiondata' => [
                        'kingguard_id' => $kingGuard,
                        'material_type' => 'kingguard'
                    ],
                    'type_option' =>
                        [
                            [
                                'title' => 'Add KingGuard® Fabric Protection',
                                'price' => $kingGuard,
                                'rrp_price' => $kingGuard,
                                'optionimage' => 'KingGuard.jpg',
                                'optioncode' => 'king_guard_'.$kingGuard,
                                'optiondata' => [
                                    'king_guard_disc_price' => $kgSAPPrice[$kingGuard]['king_guard_disc_price'],
                                    'king_guard_full_price' => $kgSAPPrice[$kingGuard]['king_guard_full_price'],
                                    'meterage' => $kgSAPPrice[$kingGuard]['meterage'],
                                ]
                            ],
                            [
                                'title' => 'No KingGuard® Fabric Protection',
                                'price' => 0,
                                'rrp_price' => 0,
                                'optionimage' => 'No-KingGuard.jpg',
                                'optioncode' => 'no_king_guard'
                            ]
                        ]
                ];
            }
        }

        // Optional Upgrades
        if (count($product->optionalUpgrades) > 0){
            // get type
            $types = OptionalUpgradeType::get();         
           
            foreach ($types as $type) {
                $typeOption = array();
                foreach ($product->optionalUpgrades as $option) {
                    if ($option->type_id == $type->id){
                        $typeOption[] = [
                            'title' => $option->name,
                            'price' => $option->price,
                            'optioncode' => str_replace(' ','_',strtolower($option->name)).'_'.$option->product_id,
                            'optionimage' => $option->image,
                            'optiondata' => [
                                'material_type' => 'optional_upgrades',
                                'price' => $option->price,
                                'image_folder' => 'optionalUpgrade',
                            ],

                        ];                       
                    }
                }
                if (count($typeOption) > 0)
                    $data[] = [
                        'title' => $type->name,
                        'optioncode' => str_replace(' ','_',strtolower($type->id)),
                        'type' => 'radio',
                        'type_option' => $typeOption,
                        'optiondata' => [
                            'image_folder' => 'optionalUpgrade',
                            'material_type' => 'optional_upgrades'
                        ]
                    ];

                   
            }
          

        }

        return $data;
    }

    static private function getMagentoLogger()
    {
        $logger = new Logger('Magento_Log');
        $loggerFilename = storage_path(
            'logs/Magento_SyncProduct.log'
        );
        $logger->pushHandler(new StreamHandler($loggerFilename), Logger::INFO);

        return $logger;
    }
}