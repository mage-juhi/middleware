<?php
use App\Sap\OptionEntityValue;
use App\Sap\ProductOptionIndex;
use App\Sap\OptionTypeRequiredMapping;
$optionTypeValue = "";
if(isset($_GET['optionTypeValue'])){
    $optionTypeValue = $_GET['optionTypeValue'];
}
$sort = "";
if(isset($_GET['sort'])){
    $sort = $_GET['sort'];
}
$legs = ProductOptionIndex::sortOptions($product->legs,$product->id,'legs');
$cushionings = ProductOptionIndex::sortOptions($product->cushioning,$product->id,'cushionings');
$extraOptions = $product->extraOptions;
$exteriorLinks = $product->exteriorLinks;
$finishLinks = $product->finishLinks;
$materialTypes = DB::table('material_group_types')->get();
$materialLinks = $product->materialLinks;
$cylindoType = cylindoTypeList();
?>
@section('exterior')
    <?php if (count($exteriorLinks) > 0) : ?>
    <li id = 'exterior' class="border-table">
        <div class="move-heading"></div>
        <a class="card-link" data-toggle="collapse" href="#collapseFor">Exterior</a>
        <div id="collapseFor" class="collapse" aria-labelledby="headingFor" data-parent="#accordionExample">
            <?php  foreach ($exteriorLinks as $index => $exteriorLink) {
            $exterior = $exteriorLink->exterior;?>
            <?php if ($exterior->is_active == 0)
                continue;
            ?>
            <?php $OptionTypeRequiredMapping = OptionTypeRequiredMapping::where('product_id',$product->id)->where('option_type', $exterior->exterior_code)->first();?>
            <?php $optionTypeRequired = (isset($OptionTypeRequiredMapping->is_required)) ? $OptionTypeRequiredMapping->is_required : 1;?>
            <?php $optionShowOnFrontEnd = \App\Sap\OptionShowFrontendMapping::where('product_id',$product->id)->where('option_type', $exterior->exterior_code)->first();?>
            <?php $exteriorColors = ProductOptionIndex::sortOptions($exterior->exteriorColor,$product->id,$exterior->exterior_name); ?>
            <form method="post" enctype="multipart/form-data" action="/optionTypeMappingSave">
                <input type='hidden' value='0' name='is_required'>
                <input type="checkbox" id="optionTypeRequired" name="is_required" value="1" <?php echo ($optionTypeRequired == 1) ?'checked' : '';?> onchange="this.form.submit()"><label for="is_required"> Is Required</label>
                @if (count($exteriorColors) <= 1)
                    <input type="checkbox" name="show_option_on_frontend" value="1" style="margin-right:5px; margin-left:10px;"  <?php echo ($optionShowOnFrontEnd && $optionShowOnFrontEnd->is_show) ? 'checked' : '';?> onchange="this.form.submit()"><label for="show_option_on_frontend"> Always Show Option On Frontend (if only one option within)</label>
                @endif()
                <input type = "hidden" name="product_id" value="<?= $product->id ?>"/>
                <input type = "hidden" name="option_type" value="{{$exterior->exterior_code}}"/>
            </form>
            <form action="/swatch-sort" method="post" enctype="multipart/form-data">
                <div class="toolbar-sorter sorter">
                    <select id="sorter" name="sort" data-role="sorter" class="sorter-options" onchange='this.form.submit()'>
                        <?php
                        $sort = "";
                        if(isset($_GET['sort'])){
                            $sort = $_GET['sort'];
                        }
                        ?>
                        <option value="#">Please choose sort</option>
                        <option <?php echo ($sort==1 && $optionTypeValue==$exterior->exterior_name) ? "selected" : "" ?> value="1">A -> Z</option>
                        <option <?php echo ($sort==2 && $optionTypeValue==$exterior->exterior_name) ? "selected" : "" ?> value="2">Z -> A</option>
                    </select>
                    <noscript><input type="submit" value="Submit"></noscript>
                    <input type = "hidden" name="option_type" value="exterior"/>
                    <input type = "hidden" name="option_type_value" value="<?= $exterior->exterior_name; ?>"/>
                    <input type = "hidden" name="product_id" value="<?= $product->id ?>"/>
                </div>
                <table class="table table-exteriors sortable-index">
                    <thead>
                    <h3><?= $exterior->exterior_name; ?></h3>
                    <tr>
                        <th>Exterior ID</th>
                        <th>Exterior Code</th>
                        <th>Exterior Name</th>
                        <th>Exterior Custom Image</th>
                    </tr>
                    </thead>
                    
                    <?php
                    foreach($exteriorColors as $key => $exteriorsColor){
                    ?>
                   <tbody id="<?php echo $exteriorsColor->id;?>">
                    <tr id="option-id-<?php echo $exteriorsColor->id; ?>">
                        <td class="first-row"><div class="move-heading-item"></div><?= $exteriorsColor->id;?></td>
                        <td><?= $exteriorsColor->colour_code;?></td>
                        <?php
                            $getObj = OptionEntityValue::getValue($exteriorsColor, 'exterior_colour_name', $product->id);
                            $exteriorsColor->colour_name = $getObj ? $getObj->value : $exteriorsColor->colour_name;
                            $getObj = OptionEntityValue::getValue($exteriorsColor, 'cylindo_data', $product->id);
                            $exteriorsColor->cylindo_data = $getObj ? $getObj->value : $exteriorsColor->cylindo_data;
                            $getObj = OptionEntityValue::getValue($exteriorsColor, 'cylindo_type', $product->id);
                            $exteriorsColor->cylindo_type = $getObj ? $getObj->value : $exteriorsColor->cylindo_type;
                            $getObj = OptionEntityValue::getValue($exteriorsColor, 'cylindo_type_optional', $product->id);
                            $exteriorsColor->cylindo_type_optional = $getObj ? $getObj->value : $exteriorsColor->cylindo_type_optional;
                            $getObj = OptionEntityValue::getValue($exteriorsColor, 'cylindo_data_optional', $product->id);
                            $exteriorsColor->cylindo_data_optional = $getObj ? $getObj->value : $exteriorsColor->cylindo_data_optional;
                        ?>
                        <td><?= $exteriorsColor->colour_name;?></td>
                        <td class="exterior-custom-image-<?php echo $exteriorsColor->id;?> StyleCustomImage">
                            <?php if($exteriorsColor->custom_image):?>
                            <p><img style= "height:80px;" src="<?php echo "/upload/images/exterior/".$exteriorsColor->custom_image; ?>"/></p>
                            <?php endif;?>
                        </td>
                        <td><button type="button" class="btn btn-primary collapsed" data-toggle="collapse" data-target="#option-value-<?php echo $exteriorsColor->id; ?>" aria-expanded="false">Edit</button></td>
                    </tr>
                    <tr id="option-value-<?php echo $exteriorsColor->id; ?>" class="collapse edit-product-detail">
                        <td colspan="10">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Attribute Name</th>
                                    <th>Attribute Value</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Name</td>
                                    <td><textarea id = "name-<?php echo $exteriorsColor->id;?>" class="name-<?php echo $exteriorsColor->id;?>" data-id="<?php echo $exteriorsColor->id;?>" data-colour="<?php echo $exteriorsColor->colour_code; ?>"><?php echo $exteriorsColor->colour_name; ?></textarea></td>
                                </tr>
                                <tr>
                                    <td>Cylindo Data</td>
                                    <td>
                                        <div class="custom-select">
                                            <select id="cylindo_type" data-id="<?php echo $exteriorsColor->id;?>" name="cylindo_type" class="cylindo-type-<?php echo $exteriorsColor->id;?>">
                                                <option value="">CHOOSE CYLINDO TYPE</option>
                                                <?php foreach ($cylindoType as $value) { ?>
                                                <option <?= $exteriorsColor->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <textarea style=" margin-top: 10px; " data-id="<?php echo $exteriorsColor->id;?>" name="cylindo_data" class="cylindo-data-<?php echo $exteriorsColor->id;?>"><?php echo $exteriorsColor->cylindo_data; ?></textarea>
                                        <div class="custom-select" style=" margin-top: 20px; ">
                                            <select id="cylindo_type_optional" data-id="<?php echo $exteriorsColor->id;?>" name="cylindo_type_optional" class="cylindo-type-optional-<?php echo $exteriorsColor->id;?>">
                                                <option value="">CHOOSE CYLINDO TYPE</option>
                                                <?php foreach ($cylindoType as $value) { ?>
                                                <option <?= $exteriorsColor->cylindo_type_optional == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <textarea style=" margin-top: 10px; " data-id="<?php echo $exteriorsColor->id;?>" name="cylindo_data_optional" class="cylindo-data-optional-<?php echo $exteriorsColor->id;?>"><?php echo $exteriorsColor->cylindo_data_optional; ?></textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2"><button entity_id="<?php echo $product->id;?>" type="submit-edit" product-type="exterior" data-id="<?php echo $exteriorsColor->id;?>" class="btn btn-primary btn-save">Save</button></td>
                                </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    </tbody>
                    <?php } ?>
                    
                </table>
            </form>
            <?php } ?>
        </div>
    </li>
    <?php endif; ?>
@stop
