@extends('layouts.default')
@section('content')
<div class="row">
 <div class="col-sm-8 offset-sm-2">
    <h1 class="display-3">Edit Optional Upgrade Type</h1>
  <div>
      <form id="updateOptionalUpgradeType" method="post" action="{{route('updateOptionalUpgradeType')}}">
          <input type="hidden"  name="id" value="<?php if (isset($type)) echo $type->id;?>">       
          
          <div class="form-group">
              <label for="name">Name</label>
              <input type="text" class="form-control" name="name" value="<?php if (isset($type)) echo $type->name;?>"/>
          </div>       
          <button type="submit" class="btn btn-success">Save</button>
      </form>
  </div>
</div>
</div>
<script type="text/javascript">
jQuery(document).ready(function($) {
  function setvalidate(_type)
  {
      switch(_type) {
        case "int":
          $("input[name=defaultvalue]").attr("number",true);
          $("input[name=defaultvalue]").attr("type","number");
          $("input[name=defaultvalue]").attr("min","0");
          $("input[name=defaultvalue]").removeAttr("minlength");
          break;
        case "string":
          $("input[name=defaultvalue]").removeAttr("number");
          $("input[name=defaultvalue]").removeAttr("min");
          $("input[name=defaultvalue]").attr("type","text");
          $("input[name=defaultvalue]").attr("minlength","3");
          break;
        case "text":
          $("input[name=defaultvalue]").removeAttr("number");
          $("input[name=defaultvalue]").removeAttr("min");
          $("input[name=defaultvalue]").attr("type","text");
          $("input[name=defaultvalue]").attr("minlength","3");
          break;
      }
  };
  function checkvalidate(_type,_isrequired)
  {
    if(_isrequired == "1")
    {
      $("input[name=defaultvalue]").prop('required', true);
      setvalidate(_type);
    }
    else
    {
      $("input[name=defaultvalue]").prop('required', false);
      setvalidate(_type)
    }    
  }   
  // $("select#type").change(function(){
  //   var _type = $("select#type").val();
  //   var _isrequired = $("input[name=isrequired]:checked").val();
  //   checkvalidate(_type,_isrequired);
  // });
  $("input[name=isrequired]").click(function(){
    var _type = $("select#type").val();
    var _isrequired = $("input[name=isrequired]:checked").val();
    checkvalidate(_type,_isrequired)
  });
  $("select#type").trigger("change");
  $("#updateOptionalUpgradeType").validate({
    rules: {  
      name : {
        required: true,
        minlength: 3
      }
    },
    messages : {
      name: {
        required: "Please enter attribute name",
        minlength: "Name should be at least 3 characters"
      },
    }
  });
});
</script>
@stop