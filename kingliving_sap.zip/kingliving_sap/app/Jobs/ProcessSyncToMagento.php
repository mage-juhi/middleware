<?php

namespace App\Jobs;

use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Sap\Services\Index\Products;

use Illuminate\Support\Facades\Log;
use App\Jobs\ProcessProductLines;

class ProcessSyncToMagento implements ShouldQueue
{

    public $connection = 'database';
    public $queue = 'sync_to_magento';
    protected $storeId = 1;
    protected $productId;

    /**
     * Create a new job instance.
     * @param $storeId
     * @param $productId
     * @return void
     */
    public function __construct(int $storeId = null, int $productId = null)
    {
        $this->storeId = $storeId;
        $this->productId = $productId;
    }

    /**
     * Execute the job.
     * @return void
     */
    public function handle()
    {

        if ($this->productId)
        {
            //single product dispatching, ignore checks
            $products = \App\Sap\Product::where('id',$this->productId)->get();
            if ($products)
            {
                foreach ($products as $product) {
                    $product = new ProcessProductLines($product->store_id, $product->id);
                    dispatch($product);
                }
            }

        } else {
            // Process uploaded podcast...
            //$data = Products::syncToMagento($this->storeId);
            $time_start = microtime(true);
            Log::info('Create Product Sync Queue');
            //Log::info($data['message']);

            //do some checks, prevent duplicate jobs
            $count_jobs = \DB::table('jobs')->where('queue', '=', 'product_sync_to_magento')->where('payload','like','%storeId\";i:'.$this->storeId.'%')->count();

            if (!$count_jobs) {
                // get data from DB
                $products = \App\Sap\Product::where('store_id',$this->storeId)
                    ->where('status','=', \App\Sap\Product::SYNCED)
                    ->where('magento_sync_status', '0')->get();
                $product_json = [];
                foreach ($products as $product) {
                    $product = new ProcessProductLines($this->storeId, $product->id);
                    dispatch($product);
                }
            }

            $time_end = microtime(true);
            $execution_time = $time_end - $time_start;

            Log::info("Queue COMPLETED in {$execution_time}");
        }

    }
}