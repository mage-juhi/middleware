<?php
use Illuminate\Database\Seeder;
use App\Sap\Users;
use Illuminate\Support\Facades\Hash;

class UserTableSeeder extends Seeder {

    public function run()
    {

        Users::create(['name' => 'tim', 'username' => 'KingLiving','email' => 'timothy.brennan@kingliving.com.au', 'password' => Hash::make('kingliving123'), 'type'=>'client']);
    }

}