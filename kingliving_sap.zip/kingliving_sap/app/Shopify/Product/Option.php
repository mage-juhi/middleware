<?php

namespace App\Shopify\Product;

use Illuminate\Database\Eloquent\Model;

class Option extends Model
{
    protected $table = 'shopify_product_options';
    protected $primaryKey = 'id';

    protected $fillable = [
        'id',
        'product_id',
        'name',
        'position',
    ];
//    protected $guarded = [];

    public $incrementing = false;
    public $timestamps = false;

    public function product()
    {
        return $this->belongsTo('App\Shopify\Product', 'product_id');
    }

    /**
     * Allows the retrieval of Options from the Product Object
     *
     * @return mixed
     */
    public function values()
    {
        return $this->hasMany('App\Shopify\Product\Option\Value', 'option_id');
    }
}
