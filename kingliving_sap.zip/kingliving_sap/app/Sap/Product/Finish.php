<?php

namespace App\Sap\Product;
use App\Sap\Product\FinishLink;
use Illuminate\Database\Eloquent\Model;

class Finish extends Model
{
    protected $table = 'finish';
    protected $primaryKey = 'id';

    protected $fillable = [
        'finish_code',
        'finish_name',
        'custom_image'
    ];

    /**
     * Allows the retrieval of Finish from the Product Object
     *
     * @return mixed
     */
    public function finishColor()
    {
        return $this->hasMany('App\Sap\Product\Finish\Color', 'finish_id');
    }

    public function indexFinish($product){
        $finishArray= array();
        $storeId = $product['item']['store_id'];
        $prod = \App\Sap\Product::where('store_id', $storeId)->where('sku', $product['item']['sku'])->first();
        if (isset($product['finish'])){
            $finishData = $product['finish'];
            if (!empty($finishData))
            {
                // List Old Finish
                $finishLinks = FinishLink::select('finish_id')->where('product_id', $prod->id)->where('store_id', $storeId)->get();
                $arrayFinishId = [];
                foreach ($finishLinks as $value) {
                    array_push($arrayFinishId, $value->finish_id);
                }
                $arrayfinishObjectId = [];
                foreach ($finishData as $finish){
                    $finishObject = self::where('finish_code', $finish['code'])->first();
                    if ($finishObject) {
                        // finish Exists, Update Data
                        $colours = $finish['colours'];
                        $codes = array();
                        foreach($colours as $colour){
                            if (!isset($colour['code']))
                                continue;
                            $colourFill = array();
                            $colourFill['colour_name'] = $colour['name'];
                            $colourFill['colour_image'] = $colour['image'];
                            //$colourFill['custom_image'] = '';
                            $colourFull[] =$colourFill;
                            $finishObject->finishColor()->updateOrCreate(['colour_code' => $colour['code']], $colourFill);
                            $codes[] = $colour['code'];
                        }
                        // delete unused
                        foreach ($finishObject->finishColor as $middleFinishColor) {
                            if (!in_array($middleFinishColor->colour_code, $codes)){
                                $middleFinishColor->delete();
                            }
                        }
                        if ($prod){
                            array_push($arrayfinishObjectId,$finishObject->id);
                            $finishLink = FinishLink::where('product_id', $prod->id)->where('finish_id', $finishObject->id)->where('store_id', $storeId)->first();
                            if (!$finishLink)
                            {
                                $finishLink = new FinishLink();
                                $finishLink->product_id = $prod->id;
                                $finishLink->finish_id = $finishObject->id;
                                $finishLink->store_id = $storeId;
                                $finishLink->save();
                            }
                        }
                    } 
                }
                //Remove Old Finish
                if(count($arrayFinishId) > 0 && count($arrayfinishObjectId) > 0) {
                    foreach ($arrayFinishId as $value) {
                        if(!in_array($value, $arrayfinishObjectId)) {
                            FinishLink::where('product_id',$prod->id)->where('store_id', $storeId)->where('finish_id', $value)->delete();
                        }
                    }
                }
            }else{
                if ($prod){
                    foreach ($prod->finishLinks as $link) {
                        if ($link->store_id == $storeId){
                            $link->delete();
                        }
                    }
                }
            }
        }
    }
}