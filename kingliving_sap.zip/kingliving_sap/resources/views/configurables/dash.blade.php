@extends('layouts.default')
@section('content')

    <div class="container mt-3">
        <h3>Configurable Group links</h3>
        <button class="btn btn-primary">Create Mapping</button>

        <input type="text" class="findProduct" />
        <button class="btn btn-primary">Add to mapping</button>
        
        <?=print_r($link,true) ?>
    </div>

@stop