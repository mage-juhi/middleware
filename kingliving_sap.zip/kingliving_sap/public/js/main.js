jQuery(function(){
    jQuery("form#select-store select").change(function(){
        window.location.href = '/product?' + jQuery("form#select-store").serialize();
        // jQuery.ajax({
        //     type: "GET",
        //     url: '/dashboard',
        //     data: jQuery("form#select-store").serialize(),
        //     success: function(data){
        //         var store_id = jQuery("form#select-store").serialize().split("=").pop();
        //         var newHTML = document.open("text/html", "replace");
        //         newHTML.write(data);
        //         newHTML.close();
        //         $("form#select-store select").val(store_id);
        //         console.log('change store successful');
        //     }
        // });
    });

    jQuery("form#subrange-select-store select").change(function(){
        window.location.href = '/subrange?' + jQuery("form#subrange-select-store").serialize();
        // jQuery.ajax({
        //     type: "GET",
        //     url: '/subrange',
        //     data: jQuery("form#subrange-select-store").serialize(),
        //     success: function(data){
        //         var store_id = jQuery("form#subrange-select-store").serialize().split("=").pop();
        //         var newHTML = document.open("text/html", "replace");
        //         newHTML.write(data);
        //         newHTML.close();
        //         $("form#subrange-select-store select").val(store_id);
        //         console.log('change store successful');
        //     }
        // });
    });

    jQuery('.synctomagento').click(function () {
        var url = '/jobs/triggerSingleSyncMagento/';
        var product_id = $(this).data('product-id');

        if (product_id)
            jQuery.get(url + product_id,function () {
                alert("Job Dispatched");
            });
    });

    jQuery('.syncfromsap').click(function () {
        var url = '/jobs/triggerSingleSyncSap/';
        var product_id = $(this).data('product-id');

        if (product_id)
            jQuery.get(url + product_id,function () {
                alert("Job Dispatched");
            });
    });

    jQuery('.findinmagento').click(function () {
        var product_id = $(this).data('sku');
        var product_url = $(this).data('point-url');

        window.open(product_url + "sku/"+ product_id);
    });

    // jQuery('.action-multicheck-toggle, .action-select-wrap, .action-menu').click(function () {
    //    $(this).toggleClass('active');
    // });
    // $('body').click(function(e) {
    //     // $(".box").hide();
    //         $(".action-select-wrap").removeClass('active');
    // });
    // if($(".action-select-wrap").is("active")) {
    //     $('body').click(function(event) { 
           
    //         $('.action-select-wrap.active').removeClass('active');
    //     });  
    // }
    $(".action-select").click(function () {
        // var isCheckedChild = $(".input-checkbox-child").is(":checked");
        // var isChecked = $(".input-checkbox").is(":checked");
        //     if (!isChecked || !isCheckedChild) {
        //         return false;
        //     }
    });

    $('.action-select-wrap').click(function(e) {    
        e.stopPropagation();
        $(this).toggleClass('active');
    });
      
    $('body').click(function(e) {
        $(".action-select-wrap").removeClass('active');
    });
    
    
    $('#select-all').click(function(event) {   
        if(this.checked) {
            $('.input-checkbox-child').each(function() {
                this.checked = true;
            });
            updateCounter();
        } else {
            $('.input-checkbox-child').each(function() {
                this.checked = false;                       
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
            updateCounter();
        }
    });
    
    $('#selectall').click(function(event) {
        $('.input-checkbox').each(function() {
            this.checked = true;
        });
        $('.input-checkbox-child').each(function() {
            this.checked = true;                        
        });
        $('#selectallpagesFlag').each(function() {
            this.checked = false;
        });
        updateCounter();
    });

    $('#deselect-all').click(function(event) {
        $('.input-checkbox').each(function() {
            this.checked = false;
        });
        $('.input-checkbox-child').each(function() {
            this.checked = false;                        
        });
        $('#selectallpagesFlag').each(function() {
            this.checked = false;
        });
        updateCounter();
    });

    function updateCounter() {
        var len = $('.input-checkbox-child:checked').length;
        if(len>0){$("#search-count-result i .counter").text('('+len+' selected)');}else{$("#search-count-result i .counter").text(' ');}
    }

    jQuery('.syncsubrangetomagento').click(function () {
        var url = '/jobs/triggerSyncSubRangeMagento/';
        var sub_range_code = $(this).data('sub-range-code');
        var store_id = $(this).data('store-id');
        if (sub_range_code)
            jQuery.get(url + sub_range_code + '/' + store_id,function () {
                alert("Job Dispatched");
            });
    });

    $('.input-checkbox__dashboard').click(function(){
        $('.input-checkbox__dashboard').each(function(){
            $(this).prop('checked', false);
        });
        $(this).prop('checked', true);
    });
});

jQuery(document).ready(function($) {
    $( ".StyleCustomImage" ).on( "click", ".deleteCustomImage" ,function(e) {
        e.preventDefault();
        var result = confirm("Are you sure?");
        if(result)
        {
            var id     = $(this).data("id");
            var option = $(this).data("type");
            $.ajax(
                {
                    url: "/delete-custom-image",
                    type: 'post',
                    dataType: "json",
                    data: {
                        "id": id,
                        "option": option
                    },
                    success: function (response)
                    {
                        $("#custom-image-"+id).html("");
                        switch(option) {
                            case "leg":
                                $(".leg-custom-image-"+id+"").html("");
                                break;
                            case "extraOption":
                                $(".extraOption-custom-image-"+id+"").html("");
                                break;
                            case "cushioning":
                                $(".cushioning-custom-image-"+id+"").html("");
                                break;
                            default:
                                break;
                          };
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    }
                });
        }
    });

    $(".deleteOptionalUpgrades").click(function(e){
        e.preventDefault();
        var result = confirm("Are you sure?");
        if(result)
        {
            var id_optional = $(this).data("id");

            $.ajax(
                {
                    url: "/delete-optional-upgrades",
                    type: 'post',
                    dataType: "json",
                    data: {
                        "id_optional": id_optional
                    },
                    success: function (response)
                    {
                        console.log(response);
                        $('#optional-upgrades-'+id_optional).remove();
                        location.reload();
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    }
                });
        }
    });

    $(".btn-save").click(function(e) {
        e.preventDefault();
        
        var id = $(this).attr('data-id');
        var type = $(this).attr('product-type');
        var name = $('#name-'+id).val();
        var des = $('.description-'+id).val();
        var isRequired = $('input[name="Extra-isRequired"]:checked').val();
        var cylindoData = $('.cylindo-data-'+id).val();
        var cylindoType = $('.cylindo-type-'+id).val();
        var cylindoDataOptional = $('.cylindo-data-optional-'+id).val();
        var cylindoTypeOptional = $('.cylindo-type-optional-'+id).val();
        var entity_id = $(this).attr("entity_id");
        var entity_field = $(this).attr("entity_field");
        var formData = new FormData();
        if (typeof $('.custom-image-'+id)[0] !== 'undefined'){
            var imageFile = $('.custom-image-'+id)[0].files;
            if(imageFile.length > 0) {
                formData.append('custom_image',imageFile[0]);
            }
        }

        formData.append('id',id);
        formData.append('type',type);
        formData.append('name',name);
        formData.append('des',des);
        formData.append('isRequired',isRequired);
        formData.append('cylindoData',cylindoData);
        formData.append('cylindoType',cylindoType);
        formData.append('cylindoDataOptional',cylindoDataOptional);
        formData.append('cylindoTypeOptional',cylindoTypeOptional);
        formData.append('entity_id',entity_id);
        formData.append('entity_field',entity_field);
        console.log(cylindoDataOptional,cylindoTypeOptional);
        $.ajax(
            {
                url: "/update-edit-option",
                type: 'post',
                dataType: "json",
                cache: false,
                contentType: false,
                processData: false,
                data: formData,
                success: function (response)
                {
                    console.log(response);
                    document.getElementById("option-id-"+id+"").innerHTML = response.template_table;
                    if (response.template_image)
                        document.getElementById("custom-image-"+id+"").innerHTML = response.template_image;
                    alert("You have successfully updated!");
                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                    alert("Update failed!");
                }
            });
    });

    $( "#sortableProductType" ).sortable({
        handle: ".move-heading",
        cursor: "move",
        stop: function(event, ui) {
            var sortedIDs = $( "#sortableProductType" ).sortable( "toArray", {attribute: 'id'});
            var product_id = $( "ul#sortableProductType" ).attr('product_id');
            console.log(sortedIDs);
            console.log(product_id);

            $.ajax(
                {
                    url: "/update-product-option-type",
                    type: 'post',
                    dataType: "json",
                    data: {
                        "product_id": product_id,
                        sortedIDs: JSON.stringify(sortedIDs)
                    },
                    success: function (response)
                    {
                        console.log(response);
                        location.reload();
                    },
                    error: function(data, xhr) {
                        //console.log(xhr.responseText);
                    }
                });
        }
    });
    $( "table.sortable-index" ).sortable({
        handle: ".move-heading-item",
        cursor: "move",
        items: "> tbody",
        tolerance: "pointer",
        stop: function(event, ui) {
            var optionType = $(this).siblings( ".toolbar-sorter" ).children( "input[name='option_type']" ).val();
            var optionTypeValue = $(this).siblings( ".toolbar-sorter" ).children( "input[name='option_type_value']" ).val();
            var productId = $(this).siblings( ".toolbar-sorter" ).children( "input[name='product_id']" ).val();
            var sortedIDs = $(this).sortable( "toArray", {attribute: 'id'});
            console.log(productId);
            console.log(sortedIDs);
            if(optionTypeValue) {
                optionType = optionTypeValue
            }
            $.ajax(
                {
                    url: "/update-product-option-index",
                    type: 'post',
                    dataType: "json",
                    data: {
                        "optionType": optionType,
                        "product_id": productId,
                        sortedIDs: JSON.stringify(sortedIDs)
                    },
                    success: function (response)
                    {
                        console.log(response);
                        location.reload();
                    },
                    error: function(data, xhr) {
                        //console.log(xhr.responseText);
                    }
                });
            ui.item.removeClass("item-drap");
        },
        activate: function( event, ui ) {
            ui.item.addClass("item-drap");
        }
    });

    $("#updateOptionalUpgrades").validate({
        rules: {
            name : {
                required: true,
                minlength: 3
            },
            price : {
                required: true,
                number: true
            },
            sale_price: {
                required: true,
                number: true
            },
            type: {
                required: true
            }
        },
        messages : {
            name: {
                required: "Please enter field name",
                minlength: "Name should be at least 3 characters"
            },
            price: {
                required: "Please enter field price",
                number: "Please enter the number"

            },
            sale_price: {
                required: "Please select field sale price",
                number: "Please enter the number"
            },
            type: {
                required: "Please select field type"
            }
        }
    });
    $("#OptionalUpgrades").validate({
        rules: {
            name : {
                required: true,
                minlength: 3
            },
            price : {
                required: true,
                number: true
            },
            sale_price: {
                required: true,
                number: true
            },
            type: {
                required: true
            }
        },
        messages : {
            name: {
                required: "Please enter field name",
                minlength: "Name should be at least 3 characters"
            },
            price: {
                required: "Please enter field price",
                number: "Please enter the number"

            },
            sale_price: {
                required: "Please select field sale price",
                number: "Please enter the number"
            },
            type: {
                required: "Please select field type"
            }
        }
    });

    $( "table.sortable-swatch" ).sortable({
        handle: ".move-heading-item",
        cursor: "move",
        items: "> tbody",
        tolerance: "pointer",
        stop: function(event, ui) {
            var groupOptionId = $(this).attr("data-id");
            var sortedItemIds = $(this).sortable( "toArray", {attribute: 'id'});
            $.ajax(
                {
                    url: "/update-swatch-sort-index",
                    type: 'post',
                    dataType: "json",
                    data: {
                        "groupOptionId": groupOptionId,
                        sortedItemIds: JSON.stringify(sortedItemIds)
                    },
                    success: function (response)
                    {
                        console.log(response);
                        location.reload();
                    },
                    error: function(data, xhr) {
                        //console.log(xhr.responseText);
                    }
                });
            ui.item.removeClass("item-drap");
        },
        activate: function( event, ui ) {
            ui.item.addClass("item-drap");
        }
    });
    $( "table.swatch-sort-parent" ).sortable({
        handle: ".move-heading-item",
        cursor: "move",
        items: "> tbody",
        tolerance: "pointer",
        stop: function(event, ui) {
            var sortedSwatchIds = $(this).sortable( "toArray", {attribute: 'id'});
            console.log(sortedSwatchIds);
            $.ajax(
                {
                    url: "/update-swatch-parent-sort-index",
                    type: 'post',
                    dataType: "json",
                    data: {
                        sortedSwatchIds: JSON.stringify(sortedSwatchIds)
                    },
                    success: function (response)
                    {
                        console.log(response);
                        location.reload();
                    },
                    error: function(data, xhr) {
                        //console.log(xhr.responseText);
                    }
                });
            ui.item.removeClass("item-drap");
        },
        activate: function( event, ui ) {
            ui.item.addClass("item-drap");
        }
    });
});

