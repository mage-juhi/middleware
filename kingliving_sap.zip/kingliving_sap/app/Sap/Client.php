<?php

namespace App\Sap;

use App\Logger;
use Monolog\Handler\StreamHandler;

use App\Sap\Client\Products as SapProducts;

use GuzzleHttp\Client as httpClient;
use GuzzleHttp\Pool as httpPool;
use GuzzleHttp\Psr7\Request as httpRequest;
use GuzzleHttp\Psr7\Uri as httpUri;
use GuzzleHttp\Exception\RequestException;

class Client
{

    protected $_baseUrl;
    protected $_password;
    protected $_verifySsl;

    protected $_httpClient;

    const GET = 'GET';
    const POST = 'POST';
    const PUT = 'PUT';

    public function __construct(
        string $baseUrl,
        string $password,
        bool $verifySsl
    )
    {
        $this->_baseUrl = $baseUrl;
        $this->_password = $password;
        $this->_verifySsl = $verifySsl;

        $this->_httpClient = new httpClient([
            'headers' => [
                'User-Agent' => 'SAP Middleware by MindArc',
                'Accept' => 'application/json'
            ],
            'base_uri' => $this->_baseUrl,
//            'auth' => $this->_password,
            'verify' => $verifySsl
        ]);
    }


    public function getProductInterface()
    {
        return new \App\Sap\Client\Products(
            $this->_baseUrl,
            $this->_password,
            $this->_verifySsl
        );
    }


    public function request(string $method, string $uri, array $data = null)
    {

        $result = [];

        if (!isset($data['auth'])) {
            $data['auth'] = $this->_password;
        }

        try {
            $response = $this->_httpClient->request($method, $uri, ['json' => $data]);
        } catch (RequestException $e) {
            if ($e->hasResponse()) {
                $errorResponse = $e->getResponse();

                $result['success'] = false;
                $result['status_code'] = $errorResponse->getStatusCode();
                $result['message'] = $errorResponse->getReasonPhrase();
            } else {
                $result['success'] = false;
                $result['status_code'] = $e->getCode();
                $result['message'] = $e->getMessage();
            }

            return $result;
        } catch (\Exception $e) {

            $result['success'] = false;
            $result['status_code'] = $e->getCode();
            $result['message'] = $e->getMessage();

            return $result;
        }

        if ((200 <= $response->getStatusCode()) && $response->getStatusCode() < 300) {
            $result['success'] = true;
            $result['status_code'] = $response->getStatusCode();
            $result['headers'] = $response->getHeaders();
            $result['message'] = $response->getBody()->getContents();
        } else {
            $result['success'] = false;
            $result['status_code'] = $response->getStatusCode();
            $result['headers'] = $response->getHeaders();
            $result['message'] = $response->getReasonPhrase();
        }

        return $result;
    }

}
