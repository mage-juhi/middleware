<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOptionalUpgradesTypeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('optional_upgrade_type', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->timestamps();
        });
        
        Schema::table('optional_upgrades', function (Blueprint $table) {
            $table->dropColumn('type');
        });
      
        Schema::table('optional_upgrades', function (Blueprint $table) {
            $table->integer('type_id')->nullable()->unsigned()->index();  
        });
        Schema::table('optional_upgrades', function (Blueprint $table) {
            $table->foreign('type_id')->references('id')->on('optional_upgrade_type')->onDelete('cascade');;    
        });
        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('optional_upgrades_type');
    }
}
