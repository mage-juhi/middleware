<?php

session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}
//if (aclToClient($_SESSION['username']))
//    header("Location:/dashboard");

?>
@extends('layouts.default')
@section('content')
    <div class="container mt-3">
        <table class="table" id="exterior_table">
            <thead>
            <tr>
                <th>Id</th>
                <th>Exterior Code</th>
                <th>Exterior Name</th>
                <th>Image</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($exteriors as $key => $exterior){?>
            <form action="/exterior" method="post" enctype="multipart/form-data">
                <tr>
                    <td><?php echo $exterior->id;?></td>
                    <td><?php echo $exterior->exterior_code; ?></td>
                    <td><?php echo $exterior->exterior_name; ?></td>
                    <td class="exterior-custom-image-<?php echo $exterior->id;?>">
                        <?php if($exterior->custom_image):?>
                            <p><img style= "height:80px;" src="<?php echo "/upload/images/exterior/".$exterior->custom_image; ?>"/></p>
                            <a class="btn btn-danger deleteCustomImage" data-id="<?php echo $exterior->id;?>" href="javascript:void();">X</a>
                        <?php endif;?>
                    </td>
                    <td><input type="file" id="custom_image" name="exterior_custom_image" value="<?php echo $exterior->custom_image; ?>"/></td>
                    <input type = "hidden" name="exterior_id" value="<?php echo $exterior->id;?>?>"/>
                    <td><button type="submit" class="btn btn-primary">Update</button></td>
                </tr>
            </form>
            <?php } ?>
            </tbody>
        </table>
    </div>
<script type="text/javascript">
jQuery(document).ready(function($) {
  $(".deleteCustomImage").click(function(e){
        e.preventDefault();
        var result = confirm("Are you sure?");
        if(result)
        {
            var id = $(this).data("id");
            $.ajax(
            {
                url: "/delete-custom-image",
                type: 'post',
                dataType: "json",
                data: {
                    "id": id,
                    "option": "exterior"
                },
                success: function (response)
                {
                    console.log(response);
                    $(".exterior-custom-image-"+id).html("");
                },
                error: function(xhr) {
                 console.log(xhr.responseText);
               }
            });
        }
   });
});
</script>
@stop