<?php

namespace App\Sap;

use Illuminate\Database\Eloquent\Model;

class ProductOptionTypeIndex extends Model
{

    protected $table = 'product_option_type_index';
    protected $primaryKey = 'id';

    protected $fillable = [
        'store_id',
        'product_id',
        'option_type',
        'position',
    ];

    public static function getPosition($productId, $optionType)
    {
        $optionIndex = self::where('product_id', $productId)
            ->where('option_type', $optionType)->first();
        return $optionIndex ? $optionIndex->position : 0;
    }

    public static function sortOptions($productId)
    {
        $sort = [];
        $optionIndex = self::where('product_id', $productId)->get();
        $hasOptinal = false;
        foreach($optionIndex as $option){
            if ($option->option_type == 'optionalUpgrades')
                $hasOptinal = true;
            $sort[$option->position] = $option->option_type;
        }
        if (!$hasOptinal && count($sort) > 0)
            $sort[] = 'optionalUpgrades';

        ksort($sort);

        return collect($sort)->filter()->values()->toArray();
    }
}