<?php

namespace App\Shopify\Product;

use Illuminate\Database\Eloquent\Model;

class Variant extends Model
{
    const DO_NOT_UPDATE_INV_TAG = 'inv_hold';

    protected $table = 'shopify_product_variants';
    protected $primaryKey = 'id';

    protected $fillable = [
        'id',
        'product_id',
        'inventory_item_id',
        'created_at',
        'updated_at',
        'title',
        'sku',
        'position',
        'price',
        'compare_at_price',
        'inventory_policy',
        'fulfillment_service',
        'inventory_management',
        'option1',
        'option2',
        'option3',
        'barcode',
        'taxable',
        'tax_code',
        'grams',
        'image_id',
        'weight',
        'weight_unit',
        'inventory_quantity',
    ];
//    protected $guarded = [];

    public $incrementing = false;
    public $timestamps = false;

    public function product()
    {
        return $this->belongsTo('App\Shopify\Product', 'product_id');
    }

    public function isInventoryOnHold()
    {
        $tags = $this->product->tags;

        $holdInv = false;
        foreach ($tags as $tag) {
            if ($tag->value == self::DO_NOT_UPDATE_INV_TAG) {
                $holdInv = true;
                break;
            }
        }

        return $holdInv;
    }
}
