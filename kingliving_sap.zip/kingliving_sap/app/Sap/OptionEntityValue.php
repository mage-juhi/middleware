<?php

namespace App\Sap;

use Illuminate\Database\Eloquent\Model;

class OptionEntityValue extends Model {
	protected $table = 'option_entity_value';
    protected $primaryKey = 'id';

	protected $fillable = [
        'id',
        'entity_table',
        'entity_id',
        'entity_field',
        'value',
        'product_id'
    ];

    public static function getValue($entity,$entityField,$productId = NULL)
    {
        if ($productId) {
            $object = self::where('entity_table', $entity->getTable())
                            ->where('entity_id', $entity->id)
                            ->where('product_id', $productId)
                            ->where('entity_field', $entityField)->first();
            if (!$object)
                $productId = NULL;
        }

        return self::where('entity_table', $entity->getTable())
                    ->where('entity_id', $entity->id)
                    ->where('product_id', $productId)
                    ->where('entity_field', $entityField)->first();
    }

    public static function getValueByTable($entity,$table,$entityField)
    {
        return self::where('entity_table', $table)
                    ->where('entity_id', $entity->id)
                    ->where('entity_field', $entityField)->first();
    }
}