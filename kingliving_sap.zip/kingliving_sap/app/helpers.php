<?php

if (!function_exists('asset')) {
    function asset($path, $secure = null)
    {
        return app('url')->asset($path, $secure);
    }
}

if (!function_exists('isProduction')) {
    function isProduction()
    {
        return env('APP_ENV') == env('APP_ENV_PROD_CODE');
    }
}

if (!function_exists('session')) {
    /**
     * Get / set the specified session value.
     *
     * If an array is passed as the key, we will assume you want to set an array of values.
     *
     * @param  array|string $key
     * @param  mixed $default
     * @return mixed|\Illuminate\Session\Store|\Illuminate\Session\SessionManager
     */
    function session($key = null, $default = null)
    {
        if (is_null($key)) {
            return app('request')->session();
        }
        if (is_array($key)) {
            return app('request')->session()->put($key);
        }
        return app('request')->session()->get($key, $default);
    }
}

if (!function_exists('setShopifyTopics')) {
    function setShopifyTopics(array $shopifyTopics)
    {
        config(['shopify_topics' => $shopifyTopics]);
    }
}

if (!function_exists('getShopifyTopics')) {
    function getShopifyTopics()
    {
        return config('shopify_topics', false);
    }
}

if (!function_exists('getQueryParams')) {
    /**
     * Takes a standard QueryString String and breaks it down in to an associative array
     *
     * @param $queryString
     * @return array
     */
    function getQueryParams($queryString)
    {
        if (empty($queryString)) {
            return [];
        }

        $parameters = [];
        $explodedQueryString = explode('&', $queryString);
        foreach ($explodedQueryString as $string) {
            $values = explode('=', $string);
            $key = $values[0];
            $val = $values[1];
            $parameters[$key] = $val;
        }
        return $parameters;
    }
}

if (!function_exists('isAuthorised')) {
    function isAuthorised()
    {
        return config('authorised', false);
    }
}

if (!function_exists('authoriseStore')) {
    function authoriseStore(int $storeId)
    {
        try {
            $store = \App\DB\Store::findOrFail($storeId);
        } catch (\Exception $e) {
            return false;
        }

        config([
            'authorised' => true,
            'store_id' => $store->id
        ]);

        // A store has been authorised, ensure all singletons are reset
        config(['store' => false]);
        config(['shopify' => false]);
        config(['account' => false]);

        return true;
    }
}

if (!function_exists('store')) {
    function store()
    {
        if (!isAuthorised()) {
            return false;
        }

        // Fetch from Singleton
        $store = config('store', false);

        if (!$store) {
            // Initialise Current Store Singleton
            try {
                $store = \App\DB\Store::findOrFail(config('store_id', false));
            } catch (\Exception $e) {
                return false;
            }

            // Store as a Singleton
            config(['store' => $store]);
        }

        return $store;
    }
}

if (!function_exists('shopify')) {
    function shopify()
    {
        // Fetch from Singleton
        $shopify = config('shopify', false);

        if (!$shopify) {
            // Initialise Shopify API Client Singleton
            $shopify = new \App\Shopify\Client();
            $shopify->setShop(store()->hostname);
            $shopify->setAccessToken(store()->access_token);
            $shopify->setVersion(env('SHOPIFY_APP_API_VERSION'));
            $shopify->enableRateLimiting(1000, 1000);

            // Store as a Singleton
            config(['shopify' => $shopify]);
        }

        return $shopify;
    }
}


if (!function_exists('account')) {
    function account()
    {
        if (!isAuthorised()) {
            return false;
        }

        // Fetch from Singleton
        $account = config('account', false);

        if (!$account) {
            // Initialise Current Store Singleton, then retrieve Account
            try {
                $store = \App\DB\Store::findOrFail(config('store_id', false));
                $account = \App\DB\Accounts::findOrFail($store['account_id']);
                $account['stores'] = $store = \App\DB\Store::where('account_id', $store['account_id'])->get();
            } catch (\Exception $e) {
                return false;
            }

            // Store as a Singleton
            config(['account' => $account]);
        }

        return $account;
    }
}


if (!function_exists('sap')) {
    function sap()
    {
        // Fetch from Singleton
        $sap = config('sap', false);

        if (!$sap) {
            $baseUrl = 'https://testkingau.doapi.kingliving.com.au/simple/sapb1_api/';
            $pass= 'a97771a6-a8a0-4ff0-9929-37fbeea7245d';
            // Initialise SAP API Client Singleton
            $sap = new \App\Sap\Client($baseUrl,$pass,true);

            
            // Store as a Singleton
            config(['sap' => $sap]);
        }

        return $sap;
    }
}

if (!function_exists('magento')) {
    function magento($storeId)
    {
        // Fetch from Singleton
        $magento = config('magento', false);

        if (!$magento) {
            // Initialise Magento API Client Singleton
            $stores = \App\DB\Stores::find($storeId); //initialsize first store
            $baseUrl = $stores->domain;
            $pass = $stores->access_token;

            $magento = new \App\Sap\Magento($baseUrl,$pass,true);

            // Store as a Singleton
            config(['magento' => $magento]);
        }

        return $magento;
    }
}

if (!function_exists('aclToClient')) {
    function aclToClient($userName)
    {
        // $disallow = ['jobs','subrange'];
        $user = App\Sap\Users::where('username', $userName)->first();
        if ($user->type == 'client')
            return true;

        return false;
    }
}

if (!function_exists('cylindoTypeList')) {
    function cylindoTypeList()
    {
        $cylindoType = [
            "TIMBER SHELVES VENEERS",
            "UPHOLSTERY","CHAISE SIDE",
            "STORAGE","SMART POCKETS",
            "MEDIA CONSOLE",
            "LEG FINISH","LEGS TYPE",
            "CHAISE OPTION",
            "FINISH","LEGS",
            "HEADREST COLOR",
            "HEADREST UPHOLSTERY",
            "TRAY TOP TIMBER VENEER",
            "EXTERIOR","TIMBER FINISH",
            "CHARGE TABLE",
            "LUME LIGHT",
            "SEAT",
            "CHARGE TABLE + LIGHT",
            "PILLOW",
            "TIMBER EXTERIOR",
            "BASE",
            "PLATFORM",
            "POSITION",
            "TIMBER VENEER",
            "STATE",
            "SEAT CUSHION",
            "MARBLE",
            "HEADREST AND LEGS METAL EXTERIOR",
            "HEADREST AND PLATFORM UPHOLSTERY",
            "BACKREST",
            "CERAMIC"
        ];
        return $cylindoType;
    }
}
