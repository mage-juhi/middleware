<?php

namespace App\DB;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Accounts extends Model
{

}
