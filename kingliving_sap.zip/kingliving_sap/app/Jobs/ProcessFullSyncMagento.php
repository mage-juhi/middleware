<?php

namespace App\Jobs;

use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Sap\Services\Index\Products;
use Illuminate\Support\Facades\Log;
use App\Sap\Product;
use App\DB\Logger;
use Monolog\Handler\StreamHandler;

class ProcessFullSyncMagento implements ShouldQueue
{

    public $connection = 'database';
    public $queue = 'full_sync_magento';
    public $storeId = 1;

    /**
     * Create a new job instance.
     * @return void
     */
    public function __construct(int $storeId = 1)
    {
        $this->storeId = $storeId;
    }

    /**
     * Execute the job.
     * @return void
     */
    public function handle()
    {
        // Process uploaded podcast...
        $logger = self::getLogger();
        $time_start = microtime(true);
        $logger->info('------------Create Full Sync  Queue------------');

        $count_jobs = \DB::table('jobs')->where('queue', '=', 'full_sync_magento')->where('payload','like','%storeId\\\\";i:'.$this->storeId.'%')->count();

        if ($count_jobs == 1) {
            // set all product status to 0
            Product::where('store_id',$this->storeId)->where('status',1)->update(["magento_sync_status"=>0]);
            Products::syncToMagento($this->storeId);
            $logger->info('----> Synced');
        }

        $time_end = microtime(true);
        $execution_time = $time_end - $time_start;

        $logger->info("Queue COMPLETED in {$execution_time}");
    }

    static private function getLogger()
    {
        $logger = new Logger('Middleware_Log');
        $loggerFilename = storage_path(
            'logs/full_sync_magento.log'
        );
        $logger->pushHandler(new StreamHandler($loggerFilename), Logger::INFO);

        return $logger;
    }
}