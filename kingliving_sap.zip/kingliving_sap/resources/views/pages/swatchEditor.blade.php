<?php
use App\Sap\OptionEntityValue;
session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}

$groudOptionId = "null";
if(isset($_GET['groudOptionId'])){
    $groudOptionId = $_GET['groudOptionId'];
}
$sort = "null";
if(isset($_GET['sort'])){
    $sort = $_GET['sort'];
}

$status = [
    0 => 'False',
    1 => 'True'
]
?>

@extends('layouts.default')
@section('content')

<div class="container mt-3">
    <div class="dropdown-action">
            <div class="action-select-wrap">
                <button class="action-select">
                <span>Actions</span>
                </button>
                <div class="action-menu-items">
                    <ul class="action-menu">
                        <li><span class="btn-img action-menu-item">Update Image</span></li>
                        <li><span class="btn-name action-menu-item">Update Name</span></li>
                        <li><span class="btn-active action-menu-item">Update Status</span></li>
                    </ul>
                </div>
            </div>
    </div>

    <table class="table swatch-sort-parent">
        <thead>
        <tr>
            <th class="data-grid-multicheck-cell">
                <div class="action-multicheck-wrap">
                    <input id="select-all" class="input-checkbox" type="checkbox" >
                    <button class="action-multicheck-toggle" data-toggle="dropdown"></button>
                    <ul class="action-menu">
                        <li>
                            <span id="selectall" class="action-menu-item">Select All</span>
                        </li>

                        <li>
                            <span id="deselect-all" class="action-menu-item">Deselect All</span>
                        </li>

                    </ul>
                </div>
            </th>
            <th></th>
            <th>Id</th>
            <th class="width_30">Name</th>
            <th>Range Code</th>
            <th>Custom Image</th>
            <th></th>
            <th>Active</th>
            <th>Action</th>
        </tr>
        </thead>

        <?php foreach($material_group_options as $key => $option){?>
        <tbody id="<?php echo $option->id ?>">
            <form id="swatch-editor-<?php echo $option->id ?>" method="post" enctype="multipart/form-data">
                <tr>
                    <td class="data-grid-checkbox-cell">
                        <label class="data-grid-checkbox-cell-inner">
                        <input class="input-checkbox" type="checkbox" value="<?php echo $option->id;?>"/>
                        </label>
                    </td>
                    <td width="5%"  class="first-row"><div class="move-heading-item"></div></td>
                    <td><a data-toggle="collapse" href="option-value-<?php echo $option->id; ?>"><?php echo $option->id; ?></a></td>
                    <td class="width_30">
                        <?php
                            $get_name = OptionEntityValue::getValue($option,'material_group_option_name');
                            $material_group_option_name = $get_name ? $get_name->value : $option->name;
                        ?>
                        <a class="update_value check_click" id="materialgroupoption_value_<?php echo $option->id;?>" href="javascript:void();"><?php echo $material_group_option_name?></a>
                        <div class="div_hide div_material_group_option_name">
                            <input class="check_click" type="text" name="material_group_option_name_<?php echo $option->id;?>" value="<?php echo $material_group_option_name;?>"/>
                            <a href="javascript:void();" data-id="material_group_option_name_<?php echo $option->id;?>" entity_table="materialgroupoption" entity_id="<?php echo $option->id;?>" class="btn btn-primary update_btn_value check_click">Update</a>
                        </div>        
                    </td>
                    <td><?php echo $option->range_code;?></td>
                    <td><input type="file" id="custom_image" name="group_custom_image" value="<?php echo $option->custom_image; ?>"/></td>
                    <td class="pswatch-editor-custom-image-<?php echo $option->id;?> StyleCustomImage">
                        <?php if($option->custom_image):?>
                            <p><img style= "height:80px;" src="<?php echo "/upload/images/".$option->custom_image; ?>"/></p>
                            <a class="btn btn-danger deleteCustomImageSwatch" data-swatch="parents" data-id="<?php echo $option->id;?>" href="javascript:void();">X</a>
                        <?php endif;?>
                    </td>
                    <td <?php if ($option->is_active == 1) echo 'style="color: green;"'; else echo 'style="color: orange;"'; ?>><a data-swatch="parents" data-id="<?php echo $option->id;?>" href="javascript:void();" class="btn btn-primary updateActive"><?php echo $status[$option->is_active]; ?></a></td>
                    <input type = "hidden" name="group_id" value="<?php echo $option->id;?>"/>
                    <td><button type="button" class="btn btn-primary collapsed" data-toggle="collapse" data-target="#option-value-<?php echo $option->id; ?>" aria-expanded="false">Update Colour</button></td>
                </tr>
                <tr id="option-value-<?php echo $option->id; ?>" class="collapse">
                    <td colspan="7">
                        <div class="toolbar-sorter sorter">
                            <select data-id="<?php echo $option->id;?>" style="padding: 5px; margin: 10px;" id="sorter" name="sort" data-role="sorter" class="sorter-options">
                                <option value="null">Please choose sort</option>
                                <option <?php echo ($sort==1 && $groudOptionId==$option->id) ? "selected" : "" ?> value="1">A -> Z</option>
                                <option <?php echo ($sort==2 && $groudOptionId==$option->id) ? "selected" : "" ?> value="2">Z -> A</option>
                            </select>
                        </div>
                        <table class="table sortable-swatch" data-id="<?php echo $option->id;?>" style="background-color:#ddd;">
                            <thead>
                            <tr>
                                <th></th>
                                <th class="width_30">Colour Name</th>
                                <th>Colour Code</th>
                                <th>Cylindo Data</th>
                                <th>Custom Image</th>
                                <th>Image</th>
                                <th>Active</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <?php $option_values = $material_group_option_value->getOptionValue($option->id);
                            foreach($option_values as $key => $val){ ?>
                            <tbody id="<?php echo $val->id;?>" class="children-swatch">
                                <tr>
                                    <td width="5%"  class="first-row"><div class="move-heading-item"></div></td>
                                   <td class="width_20">
                                        <?php
                                            $get_colour_name = OptionEntityValue::getValue($val,'material_group_option_colour_name');
                                            $material_group_option_colour_name = $get_colour_name ? $get_colour_name->value : $val->colour_name;
                                        ?>
                                        <a class="update_value check_click" id="materialgroupoptionvalue_value_<?php echo $val->id;?>" href="javascript:void();"><?php echo $material_group_option_colour_name?></a>
                                        <div class="div_hide div_material_group_option_colour_name">
                                            <input class="check_click" type="text" name="material_group_option_colour_name_<?php echo $val->id;?>" value="<?php echo $material_group_option_colour_name;?>"/>
                                            <a href="javascript:void();" data-id="material_group_option_colour_name_<?php echo $val->id;?>" entity_table="materialgroupoptionvalue" entity_id="<?php echo $val->id;?>" class="btn btn-primary update_btn_value check_click">Update</a>
                                        </div>
                                    </td>
                                    <td><?php echo $val->colour_code;?></td>
                                    <td>
                                        <textarea class="cylindo_data" name="cylindo_data[<?php echo $val->id;?>]"><?php echo $val->cylindo_data; ?></textarea>
                                        <textarea class="cylindo_data_optional" name="cylindo_data_optional[<?php echo $val->id;?>]"><?php echo $val->cylindo_data_optional; ?></textarea>
                                    </td>
                                    <td><input type="file" class='option_value_custom_image_<?php echo $val->id;?>' id="option_value_custom_image" name="option_value_custom_image[<?php echo $val->id;?>]" value="<?php echo $val->custom_image; ?>"/></td>
                                    <td class="swatch-editor-custom-image-<?php echo $val->id;?> StyleCustomImage">
                                        <?php if($val->custom_image):?>
                                            <p><img style= "height:80px;" src="<?php echo "/upload/images/".$val->custom_image; ?>"/></p>
                                            <a class="btn btn-danger deleteCustomImageSwatch" data-swatch="swatch" data-id="<?php echo $val->id;?>" href="javascript:void();">X</a>
                                        <?php endif;?>
                                    </td>
                                    <td <?php if ($val->is_active == 1) echo 'style="color: green;"'; else echo 'style="color: orange;"'; ?>><a data-id="<?php echo $val->id;?>" href="javascript:void();" data-swatch="child" class="btn btn-primary updateActive"><?php echo $status[$val->is_active]; ?></a></td>
                                    <td><button type="button" class="btn btn-primary collapsed" data-toggle="collapse" data-target="#des-value-<?php echo $val->id; ?>" aria-expanded="false">Description</button></td>
                                </tr>
                                <tr id="des-value-<?php echo $val->id; ?>" class="collapse">
                                    <td colspan="7">
                                        <table class="table" style="background-color:#ddd;">
                                            <thead>
                                                <tr>
                                                    <th class="width_30">Colour Description</th>
                                                    <th class="width_30">Upload Colour Description Image</th>
                                                    <th>Colour Description Image</th>
                                                </tr>
                                            </thead>
                                                <tr>
                                                    <td class="width_40">
                                                        <textarea cols="50" name="material_group_option_colour_description_<?php echo $val->id;?>" id="description-colour" data-id="<?php echo $val->id;?>"><?php echo $val->colour_description; ?></textarea>
                                                        <div class="div_material_group_option_colour_des" style="display: none;">
                                                            <a href="javascript:void();" data-id="material_group_option_colour_description_<?php echo $val->id;?>" entity_table="materialgroupoptionvaluedes" entity_id="<?php echo $val->id;?>" class="btn btn-primary update_btn_value check_click">Update Description</a>
                                                        </div>
                                                        </td>
                                                    <td style="width: 32%;"><input type="file" id="des_value_custom_image" name="des_value_custom_image[<?php echo $val->id;?>]" value="<?php echo $val->colour_description_image; ?>"/></td>
                                                    <td class="swatch-description-colour-image-<?php echo $val->id;?> StyleCustomImage">
                                                        <?php if($val->colour_description_image):?>
                                                            <p><img style= "height:80px;" src="<?php echo "/upload/images/".$val->colour_description_image; ?>"/></p>
                                                            <a class="btn btn-danger deleteCustomImageSwatch" data-swatch="childc" data-id="<?php echo $val->id;?>" href="javascript:void();">X</a>
                                                        <?php endif;?>
                                                    </td>
                                                </tr>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                            <?php } ?>
                            <tr>
                                <td align="right" colspan="10"><button style=" margin-right: 25px; width: 100px; " data-id="<?php echo $option->id; ?>" type="submit" class="submit-swatches btn btn-danger">Save Data</button></td>
                            <tr>
                        </table>
                    </td>
                </tr>
            </form>
        </tbody>
        <?php } ?>
        <?php echo $material_group_options->links(); ?>
    </table>

    <div id="myModalName" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h3 class="modal-title">Update Name</h3>
            <button type="button" class="close" data-dismiss="modal">
                &times;
            </button>
            </div>
            <div class="modal-body">
                <input id="name-swatch" type="text">
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                Cancel
            </button>
            <button type="button" entity_table="materialgroupoption" entity_id="<?php echo $option->id;?>" class="update-name-swatch btn btn-primary">Save</button>
            </div>
        </div>
        </div>
    </div>

    <div id="myModalImage" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="" enctype="multipart/form-data">
            <div class="modal-header">
            <h3 class="modal-title">Update Image</h3>
            <button type="button" class="close" data-dismiss="modal">
                &times;
            </button>
            </div>
            <div class="modal-body">
                <input type="file" id="image-swatch" name="legs_custom_image" value="<?php echo $option->custom_image; ?>"/>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                Cancel
            </button>
            <button type="button" class="update-image-swatch btn btn-primary">Save</button>
            </div>
            </form>
        </div>
        </div>
    </div>

    <div id="myModalActive" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Update Status</h3>
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>
                <div class="modal-body">
                    <select name="active-swatch" id="active-swatch">
                        <option value="">CHOOSE STATUS</option>
                        <option value="1">TRUE</option>
                        <option value="0">FALSE</option>
                    </select>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        Cancel
                    </button>
                    <button type="button" class="update-active-swatches btn btn-primary">Save</button>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function($) {

    if(<?php echo $groudOptionId; ?> != null) {
        var groudOptionId = <?php echo $groudOptionId; ?>;
        var typeSort = <?php echo $sort; ?>;
        console.log(groudOptionId);
        console.log(typeSort);
  $("#option-value-"+groudOptionId).addClass("in");
        $('html,body').animate({
            scrollTop: $("#option-value-"+groudOptionId).offset().top
        });
    }

    $('.submit-swatches').click(function(e) {
        e.preventDefault();
        var idSwatch = $(this).data('id');
        let myForm = document.getElementById('swatch-editor-'+idSwatch);
        let formData = new FormData(myForm);
        formData.append('id',idSwatch);
        $.ajax(
        {
            url: "/swatch-editor",
            type: 'post',
            dataType: "json",
            cache: false,
            contentType: false,
            processData: false,
            data: formData,
            success: function (response)
            {
                console.log(response.data);
                $.each(response.data, function( key, value ) {
                    if(key.includes("pswatch-editor-custom-image-")) {
                        var id = key.replace("pswatch-editor-custom-image-", "");
                        $("."+key).html('<p><img style= "height:80px;" src="/upload/images/'+value+'"/></p><a class="btn btn-danger deleteCustomImageSwatch" data-swatch="parents" data-id="'+id+'" href="javascript:void();">X</a>');
                    } else if (key.includes("swatch-editor-custom-image-")) {
                        var id = key.replace("swatch-editor-custom-image-", "");
                        $("."+key).html('<p><img style= "height:80px;" src="/upload/images/'+value+'"/></p><a class="btn btn-danger deleteCustomImageSwatch" data-swatch="swatch" data-id="'+id+'" href="javascript:void();">X</a>');
                    } else {
                        var id = key.replace("swatch-description-colour-image-", "");
                        $("."+key).html('<p><img style= "height:80px;" src="/upload/images/'+value+'"/></p><a class="btn btn-danger deleteCustomImageSwatch" data-swatch="childc" data-id="'+id+'" href="javascript:void();">X</a>');
                    }
                });
                alert("You have successfully updated!");
            },
            error: function(xhr) {
                console.log(xhr.responseText);
            }
        });
    });


    $('.sorter-options').change(function(){
        var groudOptionId = $(this).data("id");
        var typeSort =  $(this).val();
        $.ajax(
            {
                url: "/sorter-swatch-options",
                type: 'post',
                dataType: "json",
                data: {
                    "groudOptionId": groudOptionId,
                    "typeSort":  typeSort
                },
                success: function (response)
                {
                    console.log(response);
                    window.location.href = "/swatch-editor/?groudOptionId="+groudOptionId+'&sort='+typeSort;
                },
                error: function(xhr) {
                 console.log(xhr.responseText);
               }
            });
    });

    $(".btn-name").click(function(){
        $("#myModalName").modal('show');
    });

    $(".btn-img").click(function(){
        $("#myModalImage").modal('show');
    });

    $(".btn-active").click(function(){
        $("#myModalActive").modal('show');
    });

    $(".update-active-swatches").click(function() {
        var status = $("#active-swatch").val();
        if(status == '') {
            alert("Please choose your option?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var data = [];
            $.each($("input[type='checkbox']:checked"), function() {
                data.push($(this).val());
            });

            $.ajax(
            {
                url: "/update-active-swatches",
                type: 'post',
                dataType: "json",
                data: {
                    "swatch_id" : data,
                    "status": status,
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        }
    });

    $(".update-name-swatch").click(function() {
        var name_swatch = $("#name-swatch").val();

        if(name_swatch == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var name = [];
            $.each($("input[type='checkbox']:checked"), function() {
                if ($(this).attr('id') != 'select-all')  name.push($(this).val());
            });

            var entity_table = $(this).attr("entity_table");

            $.ajax(
            {
                url: "/updateselect-swatch-name",
                type: 'post',
                dataType: "json",
                data: {
                    "entity_id" : name,
                    "entity_table": entity_table,
                    "entity_field": "",
                    "entity_value": name_swatch
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        }
    });

    $(".update-image-swatch").click(function() {
        var path = $("#image-swatch").val();
        var image_swatch = path.replace(/C:\\fakepath\\/, '');

        if(image_swatch == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var image = [];
            $.each($("input[type='checkbox']:checked"), function() {
                if ($(this).attr('id') != 'select-all')  image.push($(this).val());
            });
            var formData = new FormData();
            var imageFile = $('#image-swatch')[0].files;
            formData.append('custom_image',imageFile[0]);
            formData.append('swatch_id',image);

            $.ajax(
            {
                url: "/updateselect-swatch-image",
                type: 'post',
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false,
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        }
    });

    $( ".StyleCustomImage" ).on( "click", ".deleteCustomImageSwatch" ,function(e) {
        e.preventDefault();
        var result = confirm("Are you sure?");
        if(result)
        {
            var id = $(this).data("id");
            var get_swatch = $(this).data("swatch");
            var swatch = "swatch";
            var class_swatch = ".swatch-editor-custom-image-"+id;
            if(get_swatch == "parents")
            {
                swatch = "pswatch";
                class_swatch = ".pswatch-editor-custom-image-"+id;
            } else if(get_swatch == "childc") {
                swatch = "childc";
                class_swatch = ".swatch-description-colour-image-"+id;
            }
            $.ajax(
            {
                url: "/delete-custom-image",
                type: 'post',
                dataType: "json",
                data: {
                    "id": id,
                    "option": swatch
                },
                success: function (response)
                {
                    console.log(response);
                    $(class_swatch).html("");
                },
                error: function(xhr) {
                 console.log(xhr.responseText);
               }
            });
        }
   });

   $(".updateActive").click(function(e){
        e.preventDefault();
        var result = confirm("Are you sure?");
        if(result)
        {
            var id = $(this).data("id");
            var button = $(this);
            var get_swatch = $(this).data("swatch");
            var swatch = "swatch";
            if(get_swatch == "child")
            {
                swatch = "cswatch";
            }
            $.ajax(
                {
                    url: "/update-active",
                    type: 'post',
                    dataType: "json",
                    data: {
                        "id": id,
                        "option": swatch
                    },
                    success: function (response)
                    {
                        if (response.value == true){
                            button.text('True');
                        }else button.text('False');

                        // $(this).html(response.value);
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    }
                });
        }
    });
 $(".update_value").click(function(e){
    e.preventDefault();
    $(".div_hide.active").removeClass("active");
    $(".update_value").show();
    if($(this).parent().find(".div_hide.active").length < 1)
    {
        $(this).hide();
        $(this).parent().find(".div_hide").addClass("active");
    }
    else
    {
        $(this).parent().find(".div_hide").removeClass("active");
    }
  });
    $(document).on("focus","textarea#description-colour", function(){
        $(this).siblings(".div_material_group_option_colour_des").show();
    });

  $(".update_btn_value").click(function(e){
    e.preventDefault();
    var result = confirm("Are you sure?");
    if(result)
    {
        var input_name = $(this).attr("data-id");
        var entity_id = $(this).attr("entity_id");
        var entity_table = $(this).attr("entity_table");
        var entity_value = $("input[name="+input_name+"]").val();
        var description_colour = $("textarea[name="+input_name+"]").val();
        $.ajax(
        {
            url: "/update-option-entity-value",
            type: 'post',
            dataType: "json",
            data: {
                "entity_id" : entity_id,
                "entity_table": entity_table,
                "entity_field": "",
                "entity_value"     : entity_value,
                "description_colour": description_colour
            },
            success: function (response)
            {
                console.log(response);
                $("#"+entity_table+"_value_"+entity_id).html(entity_value);
                $(".div_hide.active").removeClass("active");
                $(".update_value").show();
                $("textarea[name="+input_name+"]").siblings(".div_material_group_option_colour_des").hide();
            },
            error: function(xhr) {
             console.log(xhr.responseText);
           }
        });
    }
  });
  $('body').click(function(e){
    if(!$(e.target).hasClass('check_click')) {
       $(".div_hide.active").removeClass("active");
       $(".update_value").show();
    }
  });
});
</script>
@stop