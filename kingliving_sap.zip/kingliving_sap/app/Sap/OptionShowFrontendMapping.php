<?php

namespace App\Sap;

use Illuminate\Database\Eloquent\Model;

class OptionShowFrontendMapping extends Model
{
    protected $table = 'option_show_on_frontend_mapping';

    protected $guarded = [];
}