# Shopify Onion Nav App
A custom Layered Navigation solution for Shopify

### Implemented Features

* Product Indexer
* Store Installation
* Accounts tied to Stores
* Job Queues
* Scheduling
* All Shopify API Endpoints
* Polaris Implementation

### Future Roadmap

* Collection Indexing
* Dynamic Database Mappers

### Project Server Requirements
* PHP 7.1 and above
* MySQL 5.6 and above

### Project setup
After you have pulled down the project and setup the database and environment, please run the following two commands

Installation of all required vendor modules defined
```
sudo composer install
```

Installation of all the required database tables 
```
php artisan migrate
```

This will give you a ready to go framework from this point forward to start coding

Enjoy :)

### Official Documentation
Documentation for the framework can be found [here](https://docs.google.com/document/d/1pV96f_E5_nV24v1tnW6Adn6VRrU8ITX8BD19kZkkRTs).

Here you can find the correct way to utilise the framework to best suit the needs for your 
application and extend the current functionality correctly.

### Maintainers
If you discover any issues or want to raise any new features you would like to see implemented, please contact one of the below

* John Vella - [email](mailto:johnv@mindarc.com.au)
* Peter Acevski - [email](mailto:petera@mindarc.com.au)
* Siddhartha Shrestha  - [email](mailto:sidds@mindarc.com.au)

### License
**This code is developed for use on MindArc products only.** 
Utilising the [MIT](https://opensource.org/licenses/MIT) Open source license from the Lumen framework.

