<?php

namespace App\Console\Commands;

use App\Console\AbstractCommand;
use App\Jobs\ProcessSyncFromSap;
use App\DB\Logger;
use Monolog\Handler\StreamHandler;
use App\Sap\Services\Index\Products;
use App\Sap\ParentProductPackage;

class SapSubrange extends AbstractCommand
{
    const PROGRESS_BAR_FORMAT = 'debug';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:sap:subrange
                              {store_id : The integrations Store ID for the Sap Store}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync sub range from SAP with status = 0';

    /**
     * Execute the console command.
     *
     * @param  \App\DripEmailer $drip
     * @return mixed
     */
    public function handle()
    {
        parent::handle();
        $logger = self::getLogger();

        $logger->info('Sap Products::handle() EXECUTED');
        $time_start = microtime(true);

        $store_id = $this->argument('store_id');
        
        $subRanges = ParentProductPackage::where('store_id',$store_id)->where('sync_status', 0)->get();
        if (count($subRanges) > 0 ){
            foreach ($subRanges as $subRange) {
                $item_data = Products::generateProductSubRange($store_id,$subRange->sub_range_code,0);
            }
        }

        $time_end = microtime(true);
        $execution_time = $time_end - $time_start;

        $logger->info("Sap Products COMPLETED in {$execution_time}");
        return;
    }

    static private function getLogger()
    {
        $logger = new Logger('Sap_Log');
        $loggerFilename = storage_path(
            'logs/Sap_Subrange.log'
        );
        $logger->pushHandler(new StreamHandler($loggerFilename), Logger::INFO);

        return $logger;
    }
}