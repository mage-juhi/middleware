<?php

namespace App\Console\Commands;

use App\Console\AbstractCommand;
use App\Jobs\ProcessGetSwatchImages;
use App\Sap\Product\Material\Option;
use App\Sap\Product\Material\Option\Value;
use Illuminate\Http\Request;


class SapGetSwatchImages extends AbstractCommand
{
    const PROGRESS_BAR_FORMAT = 'debug';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:sap:swatch-image
                              {store_id : The integrations Store ID for the Sap Store}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get Sap Swatch Image from KINGLIVING AU-UAT';

    protected $request_url = 'https://kingliving-auuat.testarc.com.au/middleware/index/getswatchimage';

    /**
     * Execute the console command.
     *
     * @param  \App\DripEmailer $drip
     * @return mixed
     */
    public function handle()
    {
        parent::handle();

        $this->info('Sap Swatch Images::handle() EXECUTED');
        $time_start = microtime(true);

        $store_id = $this->argument('store_id');
        $swatch_name = Option::all(['name'])->toArray();
        $destination_path = "upload/images";
        foreach($swatch_name as $s_name){
            $response = $this->getRequestImageLink($s_name['name']);
            $image_url = 'https://kingliving.com.au'. $response['image_src'];
            $split_image_str = explode('/', $image_url);
            $image_name = array_pop($split_image_str);

            $handle = curl_init($image_url);
            curl_setopt($handle,  CURLOPT_RETURNTRANSFER, TRUE);

            /* Get the HTML or whatever is linked in $url. */
            $response = curl_exec($handle);

            /* Check for 404 (file not found). */
            $httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
            if($httpCode == 404) {
                continue;
                //$image_url = 'https://kingliving.com.au'. $response['image_src'];
            }
            curl_close($handle);


            $image = file_get_contents($image_url);


//            $destination_path = "upload/images";
//            if($this->createPath($destination_path)){
                file_put_contents('public/upload/images/'.$image_name, $image);
                Option::where('name', $s_name['name'])
                    ->update(['custom_image' => $image_name]);
//            }

        }


        $time_end = microtime(true);
        $execution_time = $time_end - $time_start;

        $this->info("Sap Get Swatch Images COMPLETED in {$execution_time}");
        return;
    }


    public function getRequestImageLink($name){
        $postData = array(
            "swatch_name" => $name
        );

        $context = stream_context_create(array(
            'http' => array(
                'method' => 'POST',
                'header' => "Content-Type: application/json\r\n",
                'content' => json_encode($postData)
            )
        ));

        // Send the request
        $response = file_get_contents($this->request_url, FALSE, $context);

        // Check for errors
        if($response === FALSE){
            die('Error');
        }

        // Decode the response
        $responseData = json_decode($response, TRUE);
        return $responseData;

    }

    protected function responseRequestError($message = 'Bad request', $statusCode = 200)
    {
        return response()->json(['status' => 'error', 'error' => $message], $statusCode)
            ->header('Access-Control-Allow-Origin', '*')
            ->header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    }

    protected function createPath($dir){
        if ( !file_exists( $dir ) && !is_dir( $dir ) ) {
            mkdir( $dir, 0777, true );
            return true;
        }else{
            return false;
        }
    }
}