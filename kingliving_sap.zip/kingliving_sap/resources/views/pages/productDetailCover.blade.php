<?php
use App\Sap\OptionEntityValue;
use App\Sap\ProductOptionIndex;
$optionTypeValue = "";
if(isset($_GET['optionTypeValue'])){
    $optionTypeValue = $_GET['optionTypeValue'];
}
$sort = "";
if(isset($_GET['sort'])){
    $sort = $_GET['sort'];
}
$optionType = 'null';
if(isset($_GET['optionType'])){
    $optionType = $_GET['optionType'];
}
$legs = ProductOptionIndex::sortOptions($product->legs,$product->id,'legs');
$cushionings = ProductOptionIndex::sortOptions($product->cushioning,$product->id,'cushionings');
$extraOptions = $product->extraOptions;
$exteriorLinks = $product->exteriorLinks;
$finishLinks = $product->finishLinks;
$materialTypes = DB::table('material_group_types')->get();
$materialLinks = $product->materialLinks;
$cylindoType = cylindoTypeList();
?>
@section('cover')
    <?php if (count($materialLinks) > 0) : ?>
    <li id = 'cover' class="border-table">
        <div class="move-heading"></div>
        <a class="card-link" data-toggle="collapse" href="#collapseSix">Cover</a>
        <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionExample">
            <?php  foreach ($materialTypes as $materialType): ?>
            <form action="/swatch-sort" method="post" enctype="multipart/form-data">
                <h3><?= $materialType->title ?></h3>
                <div class="toolbar-sorter sorter">
                    <select id="sorter" name="sort" data-role="sorter" class="sorter-options" onchange='this.form.submit()'>
                        <?php
                        $sort = "";
                        if(isset($_GET['sort'])){
                            $sort = $_GET['sort'];
                        }
                        ?>
                        <option value="#">Please choose sort</option>
                        <option <?php echo ($sort==1 && $optionTypeValue==$materialType->title) ? "selected" : "" ?> value="1">A -> Z</option>
                        <option <?php echo ($sort==2 && $optionTypeValue==$materialType->title) ? "selected" : "" ?> value="2">Z -> A</option>
                        <option <?php echo ($sort==3 && $optionTypeValue==$materialType->title) ? "selected" : "" ?> value="3">Price low to high</option>
                        <option <?php echo ($sort==4 && $optionTypeValue==$materialType->title) ? "selected" : "" ?> value="4">Price high to low</option>
                        <option <?php echo ($sort==5 && $optionTypeValue==$materialType->title) ? "selected" : "" ?> value="5">Code</option>
                    </select>
                    <noscript><input type="submit" value="Submit"></noscript>
                    <input type = "hidden" name="option_type" value="cover"/>
                    <input type = "hidden" name="option_type_value_id" value="<?= $materialType->id ?>"/>
                    <input type = "hidden" name="option_type_value" value="<?= $materialType->title ?>"/>
                    <input type = "hidden" name="product_id" value="<?= $product->id ?>"/>
                </div>
                <table class="table table-cover sortable-index">
                    <thead>
                    <tr>
                        <th>Option ID</th>
                        <th>Option Name</th>
                        <th>Range Code</th>
                        <th>Option Custom Image</th>
                    </tr>
                    </thead>
                    
                    <?php
                    $options = [];
                    foreach ($materialLinks as $materialLink) {
                        $option = $materialLink->option;
                        if ($option->is_active == 0)
                            continue;
                        if ($option->type_id == $materialType->id)
                            $options[] = $option;
                    }
                    $options = ProductOptionIndex::sortOptions($options,$product->id,$materialType->title);
                    foreach($options as $option) :?>
                    <tbody id="<?php echo $option->id;?>">
                    <tr>
                        <td class="first-row"><div class="move-heading-item"></div><?= $option->id;?></td>
                        <td><?= $option->name;?></td>
                        <td><?= $option->range_code;?></td>
                        <td class="option-custom-image-<?php echo $option->id;?> StyleCustomImage">
                            <?php if($option->custom_image):?>
                            <p><img style= "height:80px;" src="<?php echo "/upload/images/".$option->custom_image; ?>"/></p>
                            <?php endif;?>
                        </td>
                    </tr>
                    </tbody>
                    <?php endforeach ?>
                </table>
            </form>
            <?php endforeach; ?>
        </div>
    </li>
    <?php endif; ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {

            if(<?php echo $optionType; ?> != null) {
                var optionType = '<?php echo $optionType; ?>';
                $("#"+optionType+' > .collapse').addClass("in");
                $('html,body').animate({
                    scrollTop: $("#"+optionType+' > .collapse').offset().top
                });
            }
        });
    </script>
@stop
