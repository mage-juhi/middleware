import React from 'react';
import {Layout, TextField} from '@shopify/polaris';

const API_BASE_URL = '/settings/';

class SettingsApiDetails extends React.Component {
    state = {
        isLoading: false,
        error: null,
        data: []
    };

    componentDidMount() {
        this.getApiDetials();
    }

    async getApiDetials() {
        try {
            this.setState({isLoading: true});
            const response = await fetch(API_BASE_URL + 'api_details');
            const apiData = await response.json();

            this.setState({data: apiData, isLoading: false});
        } catch (err) {
            this.setState({isLoading: false});
            console.error(err);
        }
    }

    render() {
        const {data} = this.state;

        return (
            < Layout.AnnotatedSection
                title="API Connection Details">
                < TextField
                    label="Store Name"
                    value={data.name}
                    disabled/>
                < TextField
                    label="API Scope"
                    value={data.scope}
                    disabled/>
            </Layout.AnnotatedSection>
        );
    }
}

export default SettingsApiDetails;