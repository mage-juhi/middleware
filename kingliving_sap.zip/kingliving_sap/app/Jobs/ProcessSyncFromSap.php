<?php

namespace App\Jobs;

use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Sap\Services\Index\Products;
use Illuminate\Support\Facades\Log;
use App\Jobs\ProcessSubRangeLines;
use App\Sap\ParentProductPackage;
use App\DB\Logger;
use Monolog\Handler\StreamHandler;

class ProcessSyncFromSap implements ShouldQueue
{

    public $connection = 'database';
    public $queue = 'product_sync_from_sap';
    public $storeId = 1;

    /**
     * Create a new job instance.
     * @return void
     */
    public function __construct(int $storeId = 1)
    {
        $this->storeId = $storeId;
    }

    /**
     * Execute the job.
     * @return void
     */
    public function handle()
    {
        // Process uploaded podcast...
        $logger = self::getLogger();
        $time_start = microtime(true);
        $logger->info('Create Product Sync Queue');

        $count_jobs = \DB::table('jobs')->where('queue', '=', 'product_sync_from_sub_range')->where('attempts',0)->where('payload','like','%storeId\\\\";i:'.$this->storeId.'%')->count();

        if (!$count_jobs) {
            // get data from DB
            $syncedProducts = ParentProductPackage::where("store_id", $this->storeId)->where('sync_status','0')->count();
            $logger->info('Synced product s'.$syncedProducts);
            if ($syncedProducts == 0) {
                //allow update only when able
                ParentProductPackage::where("store_id", $this->storeId)->update(["sync_status"=>0]);
            }

            Products::populatePackageSubRange($this->storeId);
            $subRange = ParentProductPackage::where('store_id',$this->storeId)->where('sync_status', 0)->first();
            if ($subRange){
                $productSubRange = new \App\Jobs\ProcessSubRangeLines($this->storeId, $subRange->sub_range_code);
                dispatch($productSubRange);
            }
        }

        $time_end = microtime(true);
        $execution_time = $time_end - $time_start;

        $logger->info("Queue COMPLETED in {$execution_time}");
    }

    static private function getLogger()
    {
        $logger = new Logger('Sap_Log');
        $loggerFilename = storage_path(
            'logs/Sap_SyncProduct.log'
        );
        $logger->pushHandler(new StreamHandler($loggerFilename), Logger::INFO);

        return $logger;
    }
}