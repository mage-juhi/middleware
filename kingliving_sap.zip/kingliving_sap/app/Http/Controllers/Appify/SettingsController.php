<?php

namespace App\Http\Controllers\Appify;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function index(Request $request)
    {
        $data = array('dashboard' => 'settingsBoard');
        return view('master', $data);
    }

    public function getApiConnectionDetails()
    {
        $connDetails = [
            'name' => store()->name,
            'scope' => store()->scope
        ];

        return $connDetails;
    }
}
