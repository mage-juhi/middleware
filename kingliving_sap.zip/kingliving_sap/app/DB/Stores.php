<?php

namespace App\DB;

use Illuminate\Database\Eloquent\Model;

class Stores extends Model
{

    protected $table = 'stores';
    protected $primaryKey = 'id';
}