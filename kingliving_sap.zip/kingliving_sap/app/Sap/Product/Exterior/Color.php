<?php

namespace App\Sap\Product\Exterior;

use Illuminate\Database\Eloquent\Model;

class Color extends Model
{
    protected $table = 'exterior_group_color';
    protected $primaryKey = 'id';

    protected $fillable = [
        'exterior_id',
        'colour_name',
        'colour_code',
        'colour_image',
        'custom_image'
    ];
    public function exterior()
    {
        return $this->belongsTo('App\Sap\Product\Exterior', 'exterior_id');
    }

    public function getColourValue($id)
    {
        return self::where('exterior_id', '=', $id)->get();
    }

}