<!doctype html>
<html>
<head>
    @include('includes.head')
</head>
<body>
<div class="container">

    <header class="row">
        @include('includes.header')
    </header>

    <div id="main" class="row">
        @yield('before')
        @if (count($productTypeOptions) > 0)
            @foreach ($productTypeOptions as $productTypeOption)
            @yield($productTypeOption)
                @endforeach
        @else
            @yield('legs')
            @yield('cushionings')
            @yield('exterior')
            @yield('extraOptions')
            @yield('finish')
            @yield('cover')
            @yield('optionalUpgrades')
        @endif
        @yield('after')
    </div>

    <footer class="row">
        @include('includes.footer')
    </footer>

</div>
</body>
</html>
