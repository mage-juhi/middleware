<?php
use App\Sap\OptionEntityValue;
session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}
//if (aclToClient($_SESSION['username']))
//    header("Location:/dashboard");
$status = [
    0 => 'False',
    1 => 'True'
];
$cylindoType = cylindoTypeList();
?>
@extends('layouts.default')
@section('content')
    <div class="container mt-3">
        <div class="row">
            <div class="col-md-6">
                @include('includes.search')
            </div>
            <div class="col-md-6">
                <?php echo $cushionings->links(); ?>
            </div>
        </div>
        <div class="dropdown-action">
            <div class="action-select-wrap">
                <button class="action-select">
                <span>Actions</span>
                </button>
                <div class="action-menu-items">
                    <ul class="action-menu">
                        <li><span class="btn-des action-menu-item">Update Description</span></li>
                        <li><span class="btn-img action-menu-item">Update Image</span></li>
                        <li><span class="btn-name action-menu-item">Update Name</span></li>
                        <li><span class="btn-cylindo-data action-menu-item">Update Cylindo Data</span></li>
                        <li><span class="btn-cylindo-type action-menu-item">Update Cylindo Type</span></li>
                        <li><span class="btn-active action-menu-item">Update Status</span></li>
                    </ul>
                </div>
            </div>
        </div>
        <?php if(count($cushionings) > 0) {?>
        <table class="table" id="cushioning_table">
            <thead>
            <tr>
                <th class="data-grid-multicheck-cell">
                    <div class="action-multicheck-wrap">
                        <input id="select-all" class="input-checkbox" type="checkbox" >
                        <button class="action-multicheck-toggle" data-toggle="dropdown"></button>
                        <ul class="action-menu">
                            <li>
                                <span id="selectall" class="action-menu-item">Select All On This Pag</span>
                            </li>
                            <li>
                                <span id="selectallpages" class="action-menu-item">Select All</span>
                                <input id='selectallpagesFlag' type='checkbox' style='display:none;'>
                            </li>
                            <li>
                                <span id="deselect-all" class="action-menu-item">Deselect All</span>
                            </li>

                        </ul>
                    </div>
                </th>
                <th>Id</th>
                <th>Cushioning Code</th>
                <th class="width_40">Cushioning Name</th>
                <th>Package SKU</th>
                <th>Image</th>
                <th>Custom Image</th>
                <th>Description</th>
                <th>Cylindo Data</th>
                <th>Active</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <div id = 'search-count-result'><?php echo $cushioningall->count() . ' records found'?> <i><small class="counter"></small></i></div>
            <?php foreach($cushionings as $key => $cushioning){?>
            <form action="/cushioning" method="post" enctype="multipart/form-data">
                <tr>
                    <td class="data-grid-checkbox-cell">
                        <label class="data-grid-checkbox-cell-inner">
                        <input class="input-checkbox-child" type="checkbox" value="<?php echo $cushioning->id; ?>"/>
                        </label>
                    </td>
                    <td><?php echo $cushioning->id;?></td>
                    <td><?php echo $cushioning->cushioning_code; ?></td>
                    <td class="width_40">
                        <?php
                            $get_name = OptionEntityValue::getValue($cushioning,'cushioning_name');
                            $cushioning_name = $get_name ? $get_name->value : $cushioning->cushioning_name;
                        ?>
                        <a class="update_value check_click" id="cushioning_value_<?php echo $cushioning->id;?>" href="javascript:void();"><?php echo $cushioning_name?></a>
                        <div class="div_hide div_cushioning_name">
                            <input class="check_click" type="text" name="cushioning_name_<?php echo $cushioning->id;?>" value="<?php echo $cushioning_name;?>"/>
                            <a href="javascript:void();" data-id="cushioning_name_<?php echo $cushioning->id;?>" entity_table="cushioning" entity_id="<?php echo $cushioning->id;?>" class="btn btn-primary update_btn_value check_click">Update</a>
                        </div>        
                    </td>
                    <td><?php echo $cushioning->product->sku; ?></td>
                    <td id="custom-image-<?php echo $cushioning->id;?>" class="cushioning-custom-image-<?php echo $cushioning->id;?> StyleCustomImage">
                        <?php if($cushioning->custom_image):?>
                        <p><img style= "height:80px;" src="/upload/images/cushioning/<?php echo $cushioning->custom_image != null ? $cushioning->custom_image : "noimage.jpg" ?>"/></p>
                        <a class="btn btn-danger deleteCustomImage" data-type="cushioning" data-id="<?php echo $cushioning->id;?>" href="javascript:void();">X</a>
                        <?php endif;?>
                    </td>
                    <td><input style=" width: 200px; " type="file" class="custom-image-<?php echo $cushioning->id;?>" name="cushioning_custom_image" value="<?php echo $cushioning->custom_image; ?>"/></td>
                    <input type = "hidden" name="cushioning_id" value="<?php echo $cushioning->id;?>"/>

                    <td><textarea id="description" name="description" class="description-<?php echo $cushioning->id;?>"><?php echo $cushioning->description; ?></textarea></td>
                    <td>
                        <div class="custom-select">
                            <select name="cylindo_type" id="cylindo_type" class="cylindo-type-<?php echo $cushioning->id;?>">
                                <option value="">CHOOSE CYLINDO TYPE</option>
                                <?php foreach ($cylindoType as $value) { ?>
                                <option <?= $cushioning->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <textarea name="cylindo_data" id="cylindo_data" class="cylindo-data-<?php echo $cushioning->id;?>"><?php echo $cushioning->cylindo_data; ?></textarea>
                        <div class="custom-select">
                            <select name="cylindo_type_optional" id="cylindo_type_optional" class="cylindo-type-optional-<?php echo $cushioning->id;?>">
                                <option value="">CHOOSE CYLINDO TYPE</option>
                                <?php foreach ($cylindoType as $value) { ?>
                                <option <?= $cushioning->cylindo_type_optional == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <textarea name="cylindo_data_optional" id="cylindo_data_optional" class="cylindo-data-optional-<?php echo $cushioning->id;?>"><?php echo $cushioning->cylindo_data_optional; ?></textarea>
                    </td>
                    <td <?php if ($cushioning->is_active == 1) echo 'style="color: green;"'; else echo 'style="color: orange;"'; ?>><a data-id="<?php echo $cushioning->id;?>" href="javascript:void();" class="btn btn-primary updateActive"><?php echo $status[$cushioning->is_active]; ?></a></td>
                    <td><button type="submit-edit" class="btn btn-primary btn-update" product-type="cushioning" data-id="<?php echo $cushioning->id;?>">Update</button></td>
                </tr>
            </form>
            <?php } ?>
            </tbody>
        </table>
        <div id="myModalDes" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Description</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <textarea id="des-cushioning"></textarea>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-des-cushioning btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalName" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Name</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <input id="name-cushioning" type="text">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" entity_table="cushioning" entity_id="<?php echo $cushioning->id;?>" class="update-name-cushioning btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalImage" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <form method="post" action="" enctype="multipart/form-data">
                <div class="modal-header">
                <h3 class="modal-title">Update Image</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <input type="file" id="image-cushioning" name="cushioning_custom_image" value="<?php echo $cushioning->custom_image; ?>"/>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-image-cushioning btn btn-primary">Save</button>
                </div>
                </form>
            </div>
            </div>
        </div>

        <div id="myModalCylindoData" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Cylindo Data</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <textarea id="cylindoData-cushioning"></textarea>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-cylindoData-cushioning btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalCylindoType" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Cylindo Type</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <select name="cylindoType-cushioning" id="cylindoType-cushioning">
                        <option value="">CHOOSE CYLINDO TYPE</option>
                        <?php foreach ($cylindoType as $value) { ?>
                            <option <?= $cushioning->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-cylindoType-cushioning btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalActive" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title">Update Status</h3>
                        <button type="button" class="close" data-dismiss="modal">
                            &times;
                        </button>
                    </div>
                    <div class="modal-body">
                        <select name="active-cushioning" id="active-cushioning">
                            <option value="">CHOOSE STATUS</option>
                            <option value="1">TRUE</option>
                            <option value="0">FALSE</option>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            Cancel
                        </button>
                        <button type="button" class="update-active-cushioning btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>
        <?php } else { ?>
            <div style="margin-top: 20px;">No data found!</div>
        <?php } ?>
    </div>
<script type="text/javascript">
jQuery(document).ready(function($) {
    $(".btn-des").click(function(){
        $("#myModalDes").modal('show');
    });

    $(".btn-name").click(function(){
        $("#myModalName").modal('show');
    });

    $(".btn-img").click(function(){
        $("#myModalImage").modal('show');
    });

    $(".btn-active").click(function(){
        $("#myModalActive").modal('show');
    });

    $('#selectallpages').click(function(event) {
        $('.input-checkbox').each(function() {
            this.checked = true;
        });
        $('.input-checkbox-child').each(function() {
            this.checked = true;
        });
        $('#selectallpagesFlag').each(function() {
            this.checked = true;
        });
        updateCounterAllPages();
    });

    function updateCounterAllPages() {
        var len = '<?php echo $cushioningall->count();?>';
        if(len>0){$("#search-count-result i .counter").text('('+len+' selected)');}else{$("#search-count-result i .counter").text(' ');}
    }

    $(".update-active-cushioning").click(function() {
        var status = $("#active-cushioning").val();
        if(status == '') {
            alert("Please choose your option?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var data = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($cushioningall as $key => $cushioning) {?>
                data.push('<?php echo $cushioning->id;?>');
                <?php } ?>
            }else
            {
                $.each($("input[type='checkbox']:checked"), function () {
                    data.push($(this).val());
                });
            }

            $.ajax(
            {
                url: "/update-active-cushioning",
                type: 'post',
                dataType: "json",
                data: {
                    "cushioning_id" : data,
                    "status": status,
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

    $(".btn-update").click(function(e) {
        e.preventDefault();
        var id = $(this).attr('data-id');
        var type = $(this).attr('product-type');
        var des = $('.description-'+id).val();
        var cylindoData = $('.cylindo-data-'+id).val();
        var cylindoType = $('.cylindo-type-'+id).val();
        var cylindoDataOptional = $('.cylindo-data-optional-'+id).val();
        var cylindoTypeOptional = $('.cylindo-type-optional-'+id).val();
        var formData = new FormData();
        var imageFile = $('.custom-image-'+id)[0].files;
        if(imageFile.length > 0) {
            formData.append('cushioning_custom_image',imageFile[0]);
        }

        formData.append('cushioning_id',id);
        formData.append('type',type);
        formData.append('description',des);
        formData.append('cylindo_data',cylindoData);
        formData.append('cylindo_type',cylindoType);
        formData.append('cylindoDataOptional',cylindoDataOptional);
        formData.append('cylindoTypeOptional',cylindoTypeOptional);
        $.ajax(
        {
            url: "/cushioning",
            type: 'post',
            dataType: "json",
            cache: false,
            contentType: false,
            processData: false,
            data: formData,
            success: function (response)
            {
                console.log(response);
                // document.getElementById("option-id-"+id+"").innerHTML = response.template_table;
                document.getElementById("custom-image-"+id+"").innerHTML = response.template_image;
                alert("You have successfully updated!");
                // location.reload();
            },
            error: function(xhr) {
                console.log(xhr.responseText);
                alert("Update failed!");
            }
        });
    });
    $(".update-name-cushioning").click(function() {
        var name_cushioning = $("#name-cushioning").val();

        if(name_cushioning == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var name = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($cushioningall as $key => $cushioning) {?>
                name.push('<?php echo $cushioning->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    if ($(this).attr('id') != 'select-all') name.push($(this).val());
                });
            }

            var entity_table = $(this).attr("entity_table");

            $.ajax(
            {
                url: "/updateselect-cushioning-name",
                type: 'post',
                dataType: "json",
                data: {
                    "entity_id" : name,
                    "entity_table": entity_table,
                    "entity_field": "",
                    "entity_value"     : name_cushioning
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

    $(".update-des-cushioning").click(function() {
        var des_cushioning = $("#des-cushioning").val();

        if(des_cushioning == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var des = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($cushioningall as $key => $cushioning) {?>
                des.push('<?php echo $cushioning->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    if ($(this).attr('id') != 'select-all') des.push($(this).val());
                });
            }

            $.ajax(
            {
                url: "/updateselect-cushioning-desc",
                type: 'post',
                dataType: "json",
                data: {
                    "cushioning_id" : des,
                    "description": des_cushioning,
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

    $(".update-image-cushioning").click(function() {
        var path = $("#image-cushioning").val();
        var image_cushioning = path.replace(/C:\\fakepath\\/, '');

        if(image_cushioning == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var image = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($cushioningall as $key => $cushioning) {?>
                image.push('<?php echo $cushioning->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    if ($(this).attr('id') != 'select-all') image.push($(this).val());
                });
            }
            var formData = new FormData();
            var imageFile = $('#image-cushioning')[0].files;
            formData.append('custom_image',imageFile[0]);
            formData.append('cushioning_id',image);

            $.ajax(
            {
                url: "/updateselect-cushioning-image",
                type: 'post',
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false,
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });


    $(".btn-cylindo-data").click(function(){
        $("#myModalCylindoData").modal('show');
    });

    $(".btn-cylindo-type").click(function(){
        $("#myModalCylindoType").modal('show');
    });

    $(".update-cylindoData-cushioning").click(function() {
        var cylindoData = $("#cylindoData-cushioning").val();
        if(cylindoData == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var data = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($cushioningall as $key => $cushioning) {?>
                data.push('<?php echo $cushioning->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    data.push($(this).val());
                });
            }

            $.ajax(
                    {
                        url: "/update-cushioning-cylindodata",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "cushioning_id" : data,
                            "cylindoData": cylindoData,
                        },
                        success: function (response)
                        {
                            console.log(response);
                            alert("You have successfully updated!");
                            location.reload();

                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });

    $(".update-cylindoType-cushioning").click(function() {
        var cylindoType = $("#cylindoType-cushioning").val();
        if(cylindoType == '') {
            alert("Please choose your option?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var type = [];
            if($('#selectallpagesFlag').is(":checked")){
                <?php foreach($cushioningall as $key => $cushioning) {?>
                type.push('<?php echo $cushioning->id;?>');
                <?php } ?>
            }else {
                $.each($("input[type='checkbox']:checked"), function () {
                    type.push($(this).val());
                });
            }

            $.ajax(
                    {
                        url: "/update-cushioning-cylindotype",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "cushioning_id" : type,
                            "cylindoType": cylindoType,
                        },
                        success: function (response)
                        {
                            console.log(response);
                            alert("You have successfully updated!");
                            location.reload();

                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
            $('#selectallpagesFlag').each(function() {
                this.checked = false;
            });
        }
    });



   $(".updateActive").click(function(e){
        e.preventDefault();
        var result = confirm("Are you sure?");
        if(result)
        {
            var id = $(this).data("id");
            var button = $(this);
            $.ajax(
            {
                url: "/update-active",
                type: 'post',
                dataType: "json",
                data: {
                    "id": id,
                    "option": "cushioning"
                },
                success: function (response)
                {
                    if (response.value == true){
                        button.text('True');
                    }else button.text('False');
                       
                    // $(this).html(response.value);
                },
                error: function(xhr) {
                 console.log(xhr.responseText);
               }
            });
        }
   });
  $(".update_value").click(function(e){
    e.preventDefault();
    $(".div_hide.active").removeClass("active");
    $(".update_value").show();
    if($(this).parent().find(".div_hide.active").length < 1)
    {
        $(this).hide();
        $(this).parent().find(".div_hide").addClass("active");
    }
    else
    {
        $(this).parent().find(".div_hide").removeClass("active");
    }
  });
  $(".update_btn_value").click(function(e){
    e.preventDefault();
    var result = confirm("Are you sure?");
    if(result)
    {
        var input_name = $(this).attr("data-id");
        var entity_id = $(this).attr("entity_id");
        var entity_table = $(this).attr("entity_table");
        var entity_value = $("input[name="+input_name+"]").val();
        $.ajax(
        {
            url: "/update-option-entity-value",
            type: 'post',
            dataType: "json",
            data: {
                "entity_id" : entity_id,
                "entity_table": entity_table,
                "entity_field": "",
                "entity_value"     : entity_value
            },
            success: function (response)
            {
                console.log(response);
                $("#"+entity_table+"_value_"+entity_id).html(entity_value);
                $(".div_hide.active").removeClass("active");
                $(".update_value").show();
            },
            error: function(xhr) {
             console.log(xhr.responseText);
           }
        });
    }
  });
  $('body').click(function(e){
    if(!$(e.target).hasClass('check_click')) {
       $(".div_hide.active").removeClass("active");
       $(".update_value").show();
    }
  });   
});
</script>
@stop