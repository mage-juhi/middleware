<?php

namespace App\Console\Commands;

use App\Console\AbstractCommand;
use App\Sap\Client;

class SapClient extends AbstractCommand
{
    protected $signature = 'app:sap-client
                                {store_id : The integrations Store ID for the Sap Store}';

    protected $description = 'Find out the total number of Products and Variants in Shopify';

    public function handle()
    {
        parent::handle();

       Client::getIsConnectionAvailable();
    }
}
