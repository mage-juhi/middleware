<?php

namespace App\Sap\Product;

use Illuminate\Database\Eloquent\Model;

class Legs extends Model
{
    protected $table = 'legs';
    protected $primaryKey = 'id';

    protected $fillable = [
        'product_id',
        'legs_code',
        'legs_name',
        'quantity',
        'is_default',
        'is_included',
        'custom_image',
        'unit_price',
        'total_price'
    ];


    public function product()
    {
        return $this->belongsTo('App\Sap\Product', 'product_id');
    }


}