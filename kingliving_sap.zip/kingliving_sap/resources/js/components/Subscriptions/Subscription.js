import React from 'react';
//import SubscriptionsList from '../../routes/SubscriptionsList';
import GeneralSubscriptions from '../../routes/GeneralSubscriptions';

class Subscription extends React.Component{

    render(){
        //var renderFunctions = [
        //    function(item, rowIndex, offset){return offset + rowIndex + 1;},
        //    function(item){
        //        return <a target="_blank" href={item.a}>{item.b}</a>
        //    },
        //    function(item){return item.c}
        //];
        //var tableHeaders = ["S.No", "Header 1", "Header 2"];
        //var items = [{a: "X", b: "Y", c: "Z"}];

        return (
            /*<SubscriptionsList />*/
            <GeneralSubscriptions />
            /*<GeneralisedTable
            //    noDataPlaceholderText="No data found"
            //    doPagination={false}
            //    tableData={items}
            //    attributeRenderFunctions={renderFunctions}
            //    tableHeaders={tableHeaders}
            />*/
        );
    }
}



export default Subscription;