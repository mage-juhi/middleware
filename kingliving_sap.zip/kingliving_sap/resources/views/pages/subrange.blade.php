<?php

session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}
// if (aclToClient($_SESSION['username']))
// header("Location:/dashboard");

$status = [
        0 => 'Syncing',
        1 => 'Synced',
        2 => 'N/A',
]
?>
@extends('layouts.default')
@section('content')

    <div class="container mt-3">
        <div class="row">
            <div class="col-md-6">
                @include('includes.search')
            </div>
            <div class="col-md-6">
                <?php echo $package_product_parent->appends(array('store' => $store_id))->links(); ?>
            </div>
        </div>
        <div>
            <form id="subrange-select-store" action="" method="post">
                <label for="store">Store</label>
                <select name="store">
                    <?php foreach($stores as $key => $store){?>
                    <option <?php if ($store_id == $store->id ) echo 'selected';?> value="<?php echo $store->id;?>"><?php echo $store->name.' '.$store->id;?></option>
                    <?php } ?>
                </select>
            </form>
        </div>

        <table class="table" id="package_products_table">
            <thead>
            <tr>
                <th>Id</th>
                <th>Sub Range Name</th>
                <th>Sub Range Code</th>
                <th>Status</th>
                <th>Magento Sync Status</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($package_product_parent as $key => $product){
            $magentoStatus = 2;
            $hasProductSync = DB::table('package_products')->where('store_id', $store_id)->where('sub_range_code',$product->sub_range_code)->exists();
            if ($hasProductSync) {
                $product_sync_status = DB::table('package_products')->where('store_id', $store_id)->where('sub_range_code',$product->sub_range_code)->where('status', 1)->where('magento_sync_status', 0)->first();
                $magentoStatus = count($product_sync_status) > 0 ? 0 : 1;
            }
            ?>
            <form action="/subrange/sync/<?php echo $product->id;?>" method="get" enctype="multipart/form-data">
                <tr>
                    <td><?php echo $product->id;?></td>
                    <td><?php echo $product->name; ?></td>
                    <td><?php echo $product->sub_range_code; ?></td>
                    <td <?php if ($product->sync_status == 1) echo 'style="color: green;"'; else echo 'style="color: orange;"'; ?>><?php echo $status[$product->sync_status]; ?></td>
                    <td <?php if ($magentoStatus == 1) echo 'style="color: green;"'; else echo 'style="color: orange;"'; ?>><?php echo $status[$magentoStatus]; ?></td>
                    <td>
                        <button type="submit" class="btn btn-primary">Sync from SAP</button>
                        <a type="submit" class="btn btn-primary syncsubrangetomagento" data-sub-range-code="<?php echo $product->sub_range_code;?>" data-store-id="<?php echo $product->store_id;?>">Sync to Magento</a>
                    </td>
                </tr>
            </form>
            <?php } ?>
            </tbody>
        </table>
    </div>
@stop
