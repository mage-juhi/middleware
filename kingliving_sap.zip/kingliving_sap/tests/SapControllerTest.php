<?php

use Laravel\Lumen\Testing\DatabaseMigrations;
use Laravel\Lumen\Testing\DatabaseTransactions;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

use GuzzleHttp\Exception\RequestException;
use Illuminate\Http\Request;
use App\Http\Controllers\SapHomeController;


class SapControllerTest extends TestCase
{
    use DatabaseTransactions;

    /**
     * A basic test example.
     *
     * @return void
     */
    public function testUploadSwatchImages()
    {

        $file1 = UploadedFile::fake()->create('test1.jpg', 5*100);
        $file = UploadedFile::fake()->create('test.jpg', 5*100);



        $response = $this->call('POST', '/swatch-editor',['group_id' => '2'],[],['group_custom_image'=> $file1, 'option_value_custom_image'=> array('6'=>$file)]);
        //302 redirect test
        $this->assertEquals(302, $response->status());

        //database check
        $this->seeInDatabase('material_group_options', ['id' => '2']);
        $this->seeInDatabase('material_group_options', ['custom_image' => 'test1.jpg']);
        $this->seeInDatabase('material_group_option_value', ['custom_image' => 'test.jpg']);
    }

    public function testUploadLegsImages()
    {

        $file = UploadedFile::fake()->create('test.jpg', 5*100);



        $response = $this->call('POST', '/legs',['leg_id' => '2'],[],['legs_custom_image' => $file]);
        //302 redirect test
        $this->assertEquals(302, $response->status());

        //database check
        $this->seeInDatabase('legs', ['id' => '2']);
        $this->seeInDatabase('legs', ['custom_image' => 'test.jpg']);
    }

    public function testUploadCushioningImages()
    {

        $file = UploadedFile::fake()->create('test.jpg', 5*100);



        $response = $this->call('POST', '/cushioning',['cushioning_id' => '2'],[],['cushioning_custom_image' => $file]);
        //302 redirect test
        $this->assertEquals(302, $response->status());

        //database check
        $this->seeInDatabase('cushioning', ['id' => '2']);
        $this->seeInDatabase('cushioning', ['custom_image' => 'test.jpg']);
    }

    public function testUploadExteriorImages()
    {

        $file = UploadedFile::fake()->create('test.jpg', 5*100);



        $response = $this->call('POST', '/exterior',['exterior_id' => '2'],[],['exterior_custom_image' => $file]);
        //302 redirect test
        $this->assertEquals(302, $response->status());

        //database check
        $this->seeInDatabase('exterior', ['id' => '2']);
        $this->seeInDatabase('exterior', ['custom_image' => 'test.jpg']);
    }


    public function testUploadExtraOptionsImages()
    {

        $file = UploadedFile::fake()->create('test.jpg', 5*100);



        $response = $this->call('POST', '/extraOptions',['extraOption_id' => '2'],[],['extraOption_custom_image' => $file]);
        //302 redirect test
        $this->assertEquals(302, $response->status());

        //database check
        $this->seeInDatabase('extra_group_option_value', ['id' => '2']);
        $this->seeInDatabase('extra_group_option_value', ['custom_image' => 'test.jpg']);
    }

    public function testDoTriggerMangeto(){
        $response = $this->call('GET', '/jobs/triggerSyncMagento',['store' => '1']);
        $this->assertEquals(200, $response->status());
    }

    public function testDoTriggerSAP(){
        $response = $this->call('GET', '/jobs/triggerSyncSap',['store' => '1']);
        $this->assertEquals(200, $response->status());
    }

    public static function callMethod($obj, $name, array $args) {
        $class = new \ReflectionClass($obj);
        $method = $class->getMethod($name);
        $method->setAccessible(true);
        return $method->invokeArgs($obj, $args);
    }

    public function testCreatePath(){
        $destination_path = "public/mkdirtest";

        $SapHomeController = new SapHomeController();

        $returnVal = SapControllerTest::callMethod(
            $SapHomeController,
            'createPath',
            array($destination_path)
        );

        $this->assertFalse(is_dir($returnVal));
        rmdir($destination_path);

    }

    public function testDoLogin(){
        $response = $this->call('GET', '/',['username' => 'mindarc', 'pwd' => 'QWEasdZXC123']);
        $this->assertEquals(200, $response->status());
    }

}
