<?php

namespace App\Console\Commands;

use App\Console\AbstractCommand;
use App\Sap\Services\Index\Products;
use App\Jobs\ProcessSyncToMagento;

class MagentoProducts extends AbstractCommand
{
    const PROGRESS_BAR_FORMAT = 'debug';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:magento:product
                              {store_id : The integrations Store ID for the Sap Store}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Function process sync to magento command';

    /**
     * Execute the console command.
     *
     * @param  \App\DripEmailer $drip
     * @return mixed
     */
    public function handle()
    {
        parent::handle();

        $store_id = $this->argument('store_id');
        $process = new ProcessSyncToMagento($store_id);
        dispatch($process);
        

        return;
    }
}