<?php

namespace App\DB;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class TransactionLog extends Model
{
    public $timestamps = false;

}