<?php

namespace App\Jobs;

use App\Mail\FailedJobNotification;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Sap\Services\Index\Products;
use Illuminate\Support\Facades\Log;
use Exception;
use Illuminate\Support\Facades\Mail;

class ProcessProductLines implements ShouldQueue
{

    use InteractsWithQueue;

    public $connection = 'database';
    public $queue = 'product_sync_to_magento';
    public $storeId = 1;
    public $tries = 1;

    /**
     * Create a new job instance.
     * @return void
     */
    public function __construct(int $storeId = null, int $productId)
    {
        $this->storeId = $storeId;
        $this->productId = $productId;
    }

    /**
     * Execute the job.
     * @return void
     */
    public function handle()
    {

        try {

            $data = Products::syncProductToMagento($this->storeId, $this->productId);
            $time_start = microtime(true);
            Log::info('Sync product to magento '. $this->productId);
            Log::info('Sync response: ' . $data);
            $resp = json_decode($data);
            if ($resp->error == 'false'){
                $product = \App\Sap\Product::where('store_id',$this->storeId)->where('id',$this->productId)->first();
                $product->magento_sync_status = 1;
                $product->save();
            }

            $time_end = microtime(true);
            $execution_time = $time_end - $time_start;

        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    public function failed(Exception $e)
    {
        Mail::to(env('ADMIN_EMAIL'))
            ->send(new FailedJobNotification([
                'error_message' => $e->getMessage(),
                'job' => [
                    'attempts' => $this->tries,
                    'store_id' => $this->storeId,
                    'queue' => $this->queue,
                    'product_id' => $this->productId
                ]
            ]));
    }

}