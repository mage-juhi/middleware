<?php

namespace App\Console\Commands;

use App\Console\AbstractCommand;
use App\Sap\Product;
use App\Sap\Product\ConfigurableMapping;
use App\Sap\ProductEntityValue;

class ProcessConfigurableMapper extends AbstractCommand
{
    const PROGRESS_BAR_FORMAT = 'debug';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:processconfigurablemap
                              {store_id : The id the CSV file store should map to}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Takes a CSV file and generates possible configurable mappings';

    private $csv_file = "/import/configmappernew.csv";

    /**
     * Execute the console command.
     *
     * @param  \App\DripEmailer $drip
     * @return mixed
     */
    public function handle()
    {
        parent::handle();

        $store_id = $this->argument('store_id');

        $storage_path = storage_path();
        $csv_file = fopen ($storage_path . $this->csv_file, "r");

        $i=0;
        $groupProductId = null;
        $groupSku = null;
        $groupType = 'color';
        if ($csv_file !== false)
        {
            while (($row = fgetcsv($csv_file, 1000, ",")) !== FALSE) {
                //assume all rows are sorted alpha
                echo "---------Checking row data------------\n";
                print_r(implode(",",$row));
                echo "\n";
                if (!empty($row[0]) && $row[0] != 'sku')
                {
                    if (empty($row[1])){
                        // new group sku 
                        $product = Product::where('sku',trim($row[0]))->where('store_id', $store_id)->first();
                        if ($product){
                            $groupProductId = $product->id;
                            $groupSku = trim($row[0]);
                            continue;
                            // $groupType = trim($row[3]);
                        }
                        else{
                            echo "create parent product $row[0] \n";
                            $product = new Product();
                            $product->sku = trim($row[0]);
                            $product->name = trim($row[0]);
                            $product->item_type = trim($row[0]);
                            $product->store_id = $store_id;
                            $product->sub_range_code = "CONFIGURABLE";
                            $product->sub_range_name = $groupType;
                            $product->has_material = 0;
                            $product->status = 1;
                            $product->magento_sync_status = 0;
                            $product->save();
                            $groupProductId = $product->id;
                            $groupSku = trim($row[0]);
                            // $groupType = trim($row[3]);
                        }
                        echo "Parent product id $groupProductId \n";
                    }
                    else{
                        $product = Product::where('sku',trim($row[0]))->where('store_id', $store_id)->first();
                        if ($product)
                        {
                            $link = new ConfigurableMapping();
                            $link->product_id = $product->id;
                            $link->parent_id = $groupProductId;
                            $link->save();
                            echo "Mapper child $product->id to $groupProductId \n";
                            switch ($groupType) {
                                case 'color':
                                    # color id is 6
                                    ProductEntityValue::updateOrCreate(
                                        ['attribute_id' => 6, 'store_id' => $store_id, 'product_id' => $product->id],
                                        ['value' => trim($row[1])]
                                    );
                                    break;
                                case 'size':
                                    # size id is 7
                                    ProductEntityValue::updateOrCreate(
                                        ['attribute_id' => 7, 'store_id' => $store_id, 'product_id' => $product->id],
                                        ['value' => trim($row[1])]
                                    );
                                    break;
                            }
                            $product->magento_sync_status = 0;
                            $product->save();
                            echo "Create EAV data\n";
                        }
                    }
                }
                // $i++;
                // if ($i == 4) exit;
            }
        }

        return;
    }
}