<?php

namespace App\Shopify\Collection;

use App\BasicEnum;

abstract class Type extends BasicEnum
{
    const CUSTOM = 0;
    const SMART = 1;
}
