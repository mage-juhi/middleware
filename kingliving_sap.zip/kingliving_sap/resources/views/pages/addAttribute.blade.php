@extends('layouts.default')
@section('content')
<!-- <div class="container" id="modal-add">
	<div class="modal-dialog">
		<div class="modal-content">
			<form action="" id="form-add" method="POST" role="form">
				<div class="modal-header">
					<h4 class="modal-title">Add Product Attribute</h4>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label for="">Code</label>
						<input name="code" type="text" class="form-control" id="code-add" placeholder="Add Code">
					</div>

					<div class="form-group">
						<label for="">Name</label>
						<input name="name" type="text" class="form-control" id="name-add" placeholder="Add Name">
					</div>

					<div class="form-group">
						<label for="">Type</label>
						<input name="type" type="text" class="form-control" id="type-add" placeholder="Add Type">
					</div>

					<div class="form-group">
						<label for="">Is Required</label>
						<input name="isrequired" type="number" class="form-control" id="isrequired-add" placeholder="Add Is-Required">
					</div>

					<div class="form-group">
						<label for="">Default Value</label>
						<input name="defaultvalue" type="text" class="form-control" id="defaultvalue-add" placeholder="Add default-value">
					</div>

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Add</button>
				</div>
			</form>
		</div>
	</div>
</div> -->
<div class="row">
 <div class="col-sm-8 offset-sm-2">
    <h1 class="display-3">Add Product Attribute</h1>
  <div>
      <form method="post" action="">
          <div class="form-group">    
              <label for="code">Code</label>
              <input type="text" class="form-control" name="code"/>
          </div>

          <div class="form-group">
              <label for="name">Name</label>
              <input type="text" class="form-control" name="name"/>
          </div>

          <div class="form-group">
              <label for="type">Type:</label>
              <input type="text" class="form-control" name="type"/>
          </div>
          <div class="form-group">
              <label for="isrequired">Is Required:</label>
              <input type="boolean" class="form-control" name="isrequired"/>
          </div>
          <div class="form-group">
              <label for="defaultvalue">Default Value:</label>
              <input type="text" class="form-control" name="defaultvalue"/>
          </div>                        
          <button type="submit" class="btn btn-primary-outline">Add</button>
      </form>
  </div>
</div>
</div>

@stop