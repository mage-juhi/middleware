<?php

namespace App\Sap\Product;
use App\Sap\Product\ExteriorLink;
use Illuminate\Database\Eloquent\Model;

class Exterior extends Model
{
    protected $table = 'exterior';
    protected $primaryKey = 'id';

    protected $fillable = [
        'exterior_code',
        'exterior_name',
        'custom_image'
    ];

    /**
     * Allows the retrieval of Exterior from the Product Object
     *
     * @return mixed
     */
    public function exteriorColor()
    {
        return $this->hasMany('App\Sap\Product\Exterior\Color', 'exterior_id');
    }

    public function indexExterior($product){
        $exteriorArray= array();
        $storeId = $product['item']['store_id'];
        $prod = \App\Sap\Product::where('store_id', $storeId)->where('sku', $product['item']['sku'])->first();

        if (isset($product['exterior'])){
            $exteriorData = $product['exterior'];
            if (!empty($exteriorData))
            {

                // List Old Exterior
                $exteriorLinks = ExteriorLink::select('exterior_id')->where('product_id', $prod->id)->where('store_id', $storeId)->get();
                $arrayExteriorId = [];
                foreach ($exteriorLinks as $value) {
                    array_push($arrayExteriorId, $value->exterior_id);
                }
                $arrayExteriorObjectId = [];
                foreach ($exteriorData as $exterior){
                    $exteriorObject = self::where('exterior_code', $exterior['code'])->first();
                    if ($exteriorObject) {
                        // exterior Exists, Update Data
                        $colours = $exterior['colours'];
                        $codes = array();
                        foreach($colours as $colour){
                            if (!isset($colour['code']))
                                continue;
                            $colourFill = array();
                            $colourFill['colour_name'] = $colour['name'];
                            $colourFill['colour_image'] = $colour['image'];
                            //$colourFill['custom_image'] = '';
                            $colourFull[] =$colourFill;
                            $exteriorObject->exteriorColor()->updateOrCreate(['colour_code' => $colour['code']], $colourFill);
                            $codes[] = $colour['code'];
                        }
                        // delete unused
                        foreach ($exteriorObject->exteriorColor as $middleExteriorColor) {
                            if (!in_array($middleExteriorColor->colour_code, $codes)){
                                $middleExteriorColor->delete();
                            }
                        }

                        if ($prod){
                            array_push($arrayExteriorObjectId,$exteriorObject->id);
                            $exteriorLink = ExteriorLink::where('product_id', $prod->id)->where('exterior_id', $exteriorObject->id)->where('store_id', $storeId)->first();
                            if (!$exteriorLink)
                            {
                                $exteriorLink = new ExteriorLink();
                                $exteriorLink->product_id = $prod->id;
                                $exteriorLink->exterior_id = $exteriorObject->id;
                                $exteriorLink->store_id = $storeId;
                                $exteriorLink->save();
                            }
                        }
                    } 
                }
                //Remove Old Exterior
                if(count($arrayExteriorId) > 0 && count($arrayExteriorObjectId) > 0) {
                    foreach ($arrayExteriorId as $value) {
                        if(!in_array($value, $arrayExteriorObjectId)) {
                            ExteriorLink::where('product_id',$prod->id)->where('store_id', $storeId)->where('exterior_id', $value)->delete();
                        }
                    }
                }
            }else{
                if ($prod){
                    foreach ($prod->exteriorLinks as $link) {
                        if ($link->store_id == $storeId){
                            $link->delete();
                        }
                    }
                }
            }
        }
    }
}