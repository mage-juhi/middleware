<?php

namespace App\Sap\Product\ExtraOption;

use Illuminate\Database\Eloquent\Model;

class Type extends Model
{
    protected $table = 'extra_group_types';
    protected $primaryKey = 'id';

    protected $fillable = [
        'option_group_name'
    ];




}