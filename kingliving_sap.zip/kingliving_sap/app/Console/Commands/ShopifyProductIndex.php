<?php

namespace App\Console\Commands;

use App\Console\AbstractCommand;

use App\Services\Base\Indexer\ProductIndex;

class ShopifyProductIndex extends AbstractCommand
{
    const PROGRESS_BAR_FORMAT = 'debug';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:shopify:product-index
                                {store_id : The integrations Store ID for the Shopify Store}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Retrieve all products from Shopify and index them within the App DB';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        parent::handle();

        ProductIndex::generate();
    }
}