<html>
    <head>
        <link rel="stylesheet" href="{{asset('css/app.css', true)}}">
    </head>
    <body>
        <div id="app" class="content" data-apikey="{{env('SHOPIFY_APP_API_KEY')}}" data-view="{{$dashboard}}"></div>
        <script>
            let params = [{!! json_encode($data) !!}];
        </script>
        <script src="{{asset('js/app.js', true)}}"></script>
    </body>
    <footer>
        <div class="copyright" style="">Developed by the creatures of <a href="https://www.mindarc.com.au/">MindArc</a>
        </div>
    </footer>
</html>