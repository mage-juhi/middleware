<?php

namespace App\Shopify\Collection;

use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    protected $table = 'shopify_collection_images';
    protected $primaryKey = 'id';

    protected $fillable = [
        'collection_id',
        'created_at',
        'alt',
        'width',
        'height',
        'src'
    ];

    public $timestamps = false;

    public function collection()
    {
        return $this->belongsTo('App\Shopify\Collection');
    }
}
