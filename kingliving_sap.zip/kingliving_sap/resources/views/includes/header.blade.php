<?php
$isClient = false;
try {
    if (isset($_SESSION['username']))
        $isClient = aclToClient($_SESSION['username']);
} catch (\Exception $e) {
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: /");
    exit();
}
$menu = [
    'product' => 'Products',
    'subrange' => 'Sub Range',
    'product-attribute' => 'Attribute',
    'jobs' => 'Jobs'
];

$dropdown_menu = [
    'swatch-editor' => 'Swatches',
    'legs' => 'Legs',
    'cushioning' => 'Cushioning',
    'exterior' => 'Exterior',
    'extraOptions' => 'Extra Options',
    'finish' => 'Finish',
];

if ($isClient){
    unset($menu['subrange']);
    unset($menu['product-attribute']);
//    unset($dropdown_menu['legs']);
//    unset($dropdown_menu['cushioning']);
//    unset($dropdown_menu['exterior']);
//    unset($dropdown_menu['extraOptions']);
    unset($menu['jobs']);
}
?>
<div id="topheader">
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="/dashboard">KL Sap Integration</a>
            </div>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="nav navbar-nav">
                <?php foreach ($menu as $link => $name): ?>
                    <li><a href="/<?php echo $link ?>"><?php echo $name ?></a></li>
                <?php endforeach; ?>
                    <li class="nav-item dropdown">
                    <a class="dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        Options
                        <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                        <?php foreach ($dropdown_menu as $link => $name): ?>
                            <li><a href="/<?php echo $link ?>"><?php echo $name ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if(isset($_SESSION['username'])){?>
                    <li class="nav navbar-nav navbar-right"><a href="/logout">Logout</a></li>
                    <?php } ?>
            </ul>
            </div>
        </div>
    </nav>
</div>



<blockquote style="display: none;">
        <pre>There are blade variables: <?php
            echo count(get_defined_vars()['__data']);
            ?>
            <?php
            foreach(get_defined_vars()['__data'] as $key => $value)
            {
                if (count($value) > 1)
                {
                    echo "\n". $key . " count : " . count($value) ;
                }
            }
            ?>
        </pre>
</blockquote>