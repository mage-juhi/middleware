<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddStatusToFinishExterior extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('exterior', function (Blueprint $table) {
            $table->integer('is_active')->default('1');
        });

        if (Schema::hasTable('exterior_group_color')) {
            //
            Schema::table('exterior_group_color', function (Blueprint $table) {
                $table->integer('is_active')->default('1');
            });
        }

        Schema::table('finish', function (Blueprint $table) {
            $table->integer('is_active')->default('1');
        });

        if (Schema::hasTable('finish_group_color')) {
            //
            Schema::table('finish_group_color', function (Blueprint $table) {
                $table->integer('is_active')->default('1');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

    }
}
