<?php

namespace App\Events\Shopify;

use App\Events\ShopifyEventAbstract;

class ProductsCreate extends ShopifyEventAbstract
{
    // For a list of valid event topics, visit:
    // https://help.shopify.com/en/api/reference/events/webhook#events
    static protected $shopifyTopic = 'products/create';

    public $product;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(array $product)
    {
        parent::__construct();
        $this->product = $product;
    }
}
