<?php

namespace App\Shopify\Product;

use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    protected $table = 'shopify_product_images';
    protected $primaryKey = 'id';

    protected $fillable = [
        'id',
        'product_id',
        'position',
        'created_at',
        'updated_at',
        'alt',
        'width',
        'height',
        'src',
    ];
//    protected $guarded = [];

    public $incrementing = false;
    public $timestamps = false;

    public function product()
    {
        return $this->belongsTo('App\Shopify\Product', 'product_id');
    }

    /**
     * Allows the retrieval of Options from the Product Object
     *
     * @return mixed
     */
    public function variants()
    {
        return $this->hasMany('App\Shopify\Product\Image\Variant', 'image_id');
    }
}
