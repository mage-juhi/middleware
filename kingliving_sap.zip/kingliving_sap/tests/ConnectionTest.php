<?php

use Laravel\Lumen\Testing\DatabaseMigrations;
use Laravel\Lumen\Testing\DatabaseTransactions;

use \App\DB\Store;

use GuzzleHttp\Client as httpClient;
use GuzzleHttp\Pool as httpPool;
use GuzzleHttp\Psr7\Request as httpRequest;
use GuzzleHttp\Psr7\Uri as httpUri;
use GuzzleHttp\Exception\RequestException;

class ConnectionTest extends TestCase
{
    private $storeIdArray = [1];

    private $httpClient;

    /**
     * A basic test example.
     *
     * @return void
     */
    public function testConnections()
    {
        foreach ($this->storeIdArray as $storeId)
        {

            $store = Store::findOrFail($storeId);

            $this->httpClient = new httpClient([
                'headers' => [
                    'User-Agent' => 'SAP Middleware UnitTest by MindArc',
                    "Content-Type"=> "application/json",
                    "X-Requested-With"=> "XMLHttpRequest",
                    'Accept' => 'application/json',
                    'Authorization' => "Bearer {$store->access_token}"
                ],
                'base_uri' => $store->domain,
                'verify' => false
            ]);

            $response = $this->httpClient->request("POST",'sync');
            $response = json_decode($response->getBody()->getContents());
            $response = json_decode($response);

            //test that api is returning a response for error
            $this->assertEquals(
                "true", $response->error
            );
        }
    }
}
