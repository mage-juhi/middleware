<?php

namespace App\Sap\Product;

use Illuminate\Database\Eloquent\Model;

class ExteriorLink extends Model
{
    protected $table = 'exterior_link';
    protected $primaryKey = 'id';

    protected $fillable = [
        'store_id',
        'product_id',
        'exterior_id'
    ];

    public function product()
    {
        return $this->belongsTo('App\Sap\Product', 'product_id');
    }

    public function exterior()
    {
        return $this->belongsTo('App\Sap\Product\Exterior', 'exterior_id');
    }

}