<?php

namespace App\DB;

use Monolog\Logger as MonologLogger;
use App\TransactionLog;

class Logger extends MonologLogger
{
    protected $_disabled = false;

    public function addRecord($level, $message, array $context = [])
    {
//        $transLogObj = new TransactionLog;
//        $transLogObj->store_id = store()->id;
//        $transLogObj->caller = $this->getCallingClass();
//        $transLogObj->level = $level;
//        $transLogObj->message = $message;
//        $transLogObj->data = json_encode($context);
//        $transLogObj->save();

        if ($this->_disabled) {
            return false;
        }

        return parent::addRecord($level, $message, $context);
    }

    private function getCallingClass()
    {
        //get the trace
        $trace = debug_backtrace();

        // Get the class that is asking for who awoke it
        $class = $trace[1]['class'];

        // +1 to i because we have to account for calling this function
        for ($i = 3; $i < count($trace); ++$i) {
            if (isset($trace[$i])) {
                if ($class != $trace[$i]['class']) {
                    return "{$trace[$i]['class']}::{$trace[$i]['function']}";
                }
            }
        }
    }
}
