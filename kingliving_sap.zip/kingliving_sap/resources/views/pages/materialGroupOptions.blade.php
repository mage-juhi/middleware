<?php
use App\Sap\OptionEntityValue;
session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}
?>
@extends('layouts.default')
@section('content')
<div class="container mt-3">
    <table class="table">
        <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Range Code</th>
            <th>Custom Image</th>
        </tr>
        </thead>
        <tbody>
            <?php foreach($material_group_options as $key => $option){?>
                <tr data-toggle="collapse" data-target="#option-value-<?php echo $option->id; ?> ">
                    <td><a data-toggle="collapse" href="option-value-<?php echo $option->id; ?>"><?php echo $option->id; ?></a></td>
                    <td><?php echo $option->name; ?></td>
                    <td>
                        <?php 
                            $name = OptionEntityValue::getValueByTable($option,'material_group_option','material_group_option_name'); 
                            echo $name ? $name->value : $option->name;
                        ?>
                    </td>
                    <td><?php if($option->custom_image):?><img style= "height:80px;" src="<?php echo "/upload/images/".$option->custom_image; ?>"/><?php endif;?></td>
                    <input type = "hidden" name="group_id" value="<?php echo $option->id;?>?>"/>
                </tr>
                <tr id="option-value-<?php echo $option->id; ?>" class="collapse">
                    <td colspan="5">
                        <table class="table" style="background-color:#ddd;">
                        <thead>
                            <tr>
                                <th>Colour Name</th>
                                <th>Colour Code</th>
                                <th>Custom Image</th>
                            </tr>
                        </thead>
                                <?php $option_values = $material_group_option_value->getOptionValue($option->id);
                                foreach($option_values as $key => $val){ ?>
                            <tr>
                                <td>
                                    <?php 
                                        $name = OptionEntityValue::getValueByTable($val,'material_group_option_value','material_group_option_colour_name');
                                        echo $name ? $name->value : $val->colour_name; 
                                    ?>
                                </td>
                                <td><?php echo $val->colour_code; ?></td>
                                <td><?php if($val->custom_image):?><img style= "height:80px;" src="<?php echo "/upload/images/".$val->custom_image; ?>"/><?php endif;?></td>
                            </tr>
                                <?php } ?>
                        </table>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
@stop
