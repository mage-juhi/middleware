<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class SetDefaultCustomImage extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('legs', function (Blueprint $table) {
            $table->string('custom_image')->default('')->change();
        });

        Schema::table('cushioning', function (Blueprint $table) {
            $table->string('custom_image')->default('')->change();
        });

        Schema::table('exterior', function (Blueprint $table) {
            $table->string('custom_image')->default('')->change();
        });

        Schema::table('extra_group_option_value', function (Blueprint $table) {
            $table->string('custom_image')->default('')->change();
        });

        if (Schema::hasTable('material_group_option_value')) {
            //
            Schema::table('material_group_option_value', function (Blueprint $table) {
                $table->string('custom_image')->default('')->change();
            });
        }

        if (Schema::hasTable('material_group_options')) {
            //
            Schema::table('material_group_options', function (Blueprint $table) {
                $table->string('custom_image')->default('')->change();
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
