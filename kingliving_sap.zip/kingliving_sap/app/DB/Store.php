<?php

namespace App\DB;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use App\Account;

class Store extends Model
{
    private $_nonceLife;
    private $_nonceSalt;

    protected $_shopify;

    public function __construct()
    {
        $this->_nonceLife = env('SHOPIFY_NONCE_LIFE');
        $this->_nonceSalt = env('SHOPIFY_NONCE_SALT');
    }

    public function prepareNonce()
    {
        // Generate Nonce
        $oneTimeNonce = hash(
            'sha256',
            $this->_nonceSalt . (string)microtime() . $this->hostname . $this->_makeRandomString()
        );

        // Get current timestamp
        $currentTime = Carbon::now();

        // Update Store
        $this->nonce = $oneTimeNonce;
        $this->nonce_created_at = $currentTime->toDateTimeString();
        $this->save();

        //return Nonce
        return $this;
    }

    public function clearNonce()
    {
        $this->nonce = null;
        $this->nonce_created_at = null;
        $this->save();

        return $this;
    }

    private function _makeRandomString($bits = 256)
    {
        $bytes = ceil($bits / 8);
        $return = '';

        for ($i = 0; $i < $bytes; $i++) {
            $return .= chr(mt_rand(0, 255));
        }

        return $return;
    }

    public function getShopify()
    {
        if (!isset($this->_shopify) || empty($this->_shopify)) {
            $this->_shopify = new \App\Shopify\Client();
            $this->_shopify->setShop($this->hostname);
            $this->_shopify->setAccessToken($this->access_token);
            $this->_shopify->setVersion(env('SHOPIFY_APP_API_VERSION'));
        }
        
        return $this->_shopify;
    }

    public function getSiblingStores()
    {
        $globalAccount = Account::find($this->account_id);
        if (!isset($globalAccount)) {
            throw new \Exception('This store does not belong to a Account');
        }

        $siblingStores = static::where('account_id', $globalAccount->id)
            ->where('id', '!=',$this->id)
            ->get();

        return $siblingStores;
    }
}
