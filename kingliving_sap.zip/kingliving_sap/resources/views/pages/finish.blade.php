<?php
use App\Sap\OptionEntityValue;
session_start();
if(!isset($_SESSION['username'])){
    header("Location:/");
}
//if (aclToClient($_SESSION['username']))
//    header("Location:/dashboard");

$status = [
    0 => 'False',
    1 => 'True'
];
$cylindoType = cylindoTypeList();
?>
@extends('layouts.default')
@section('content')
    <div class="container mt-3">
        <div class="dropdown-action">
            <div class="action-select-wrap">
                <button class="action-select">
                <span>Actions</span>
                </button>
                <div class="action-menu-items">
                    <ul class="action-menu">
                        <li><span class="btn-name action-menu-item">Update Name</span></li>
                        <li><span class="btn-cylindo-data action-menu-item">Update Cylindo Data</span></li>
                        <li><span class="btn-cylindo-type action-menu-item">Update Cylindo Type</span></li>
                        <li><span class="btn-active action-menu-item">Update Status</span></li>
                    </ul>
                </div>
            </div>
        </div>
        <table class="table" id="finish_table">
            <thead>
            <tr>
                <th class="data-grid-multicheck-cell">
                    <div class="action-multicheck-wrap">
                        <input id="select-all" class="input-checkbox" type="checkbox" >
                        <button class="action-multicheck-toggle" data-toggle="dropdown"></button>
                        <ul class="action-menu">
                            <li>
                                <span id="selectall" class="action-menu-item">Select All</span>
                            </li>

                            <li>
                                <span id="deselect-all" class="action-menu-item">Deselect All</span>
                            </li>

                        </ul>
                    </div>
                </th>
                <th>Id</th>
                <th>Finish Code</th>
                <th class="width_50">Finish Name</th>
                <th>Active</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($finish as $key => $value){?>
            <form action="/finish" method="post" enctype="multipart/form-data">
                <tr>
                    <td class="data-grid-checkbox-cell">
                        <label class="data-grid-checkbox-cell-inner">
                        <input class="input-checkbox" type="checkbox" value="<?php echo $value->id; ?>" name="<?php echo $value->finish_code; ?>"/>
                        </label>
                    </td>
                    <td><?php echo $value->id;?></td>
                    <td><?php echo $value->finish_code; ?></td>
                    <td class="width_50">
                        <?php
                            $get_name = OptionEntityValue::getValue($value,'finish_name');
                            $finish_name = $get_name ? $get_name->value : $value->finish_name;
                        ?>
                        <a class="update_value check_click" id="finish_value_<?php echo $value->id;?>" href="javascript:void();"><?php echo $finish_name?></a>
                        <div class="div_hide div_finish_name">
                            <input class="check_click" type="text" name="finish_name_<?php echo $value->id;?>" value="<?php echo $finish_name;?>"/>
                            <a href="javascript:void();" data-id="finish_name_<?php echo $value->id;?>" entity_table="finish" entity_id="<?php echo $value->id;?>" class="btn btn-primary update_btn_value check_click">Update</a>
                        </div>        
                    </td>
                    <td <?php if ($value->is_active == 1) echo 'style="color: green;"'; else echo 'style="color: orange;"'; ?>><a data-id="<?php echo $value->id;?>" href="javascript:void();" class="btn btn-primary updateActive"><?php echo $status[$value->is_active]; ?></a></td>
                    <td><button type="button" class="btn btn-primary collapsed" data-toggle="collapse" data-target="#finish-value-<?php echo $value->id; ?>" aria-expanded="false">Update Image</button></td>
                </tr>
                 <tr id="finish-value-<?php echo $value->id; ?>" class="collapse">
                    <td colspan="5">
                        <table class="table" style="background-color:#ddd;">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th class="width_30">Colour Name</th>
                                <th>Colour Code</th>
                                <th>Colour Image</th>
                                <th></th>
                                <th>Description</th>
                                <th>Cylindo Data</th>
                                <th>Active</th>
                                <th>Custom Image</th>
                            </tr>
                            </thead>
                            <?php $colour_values = $finish_group_color->getColourValue($value->id);
                            foreach($colour_values as $key => $val){ ?>
                                <tr class="color">
                                    <td><?php echo $val->id; ?></td>
                                    <td class="width_30">
                                        <?php
                                            $get_colour_name = OptionEntityValue::getValue($val,'finish_colour_name');
                                            $finish_colour_name = $get_colour_name ? $get_colour_name->value : $val->colour_name;
                                        ?>
                                        <a class="update_value check_click" id="finishgroupcolor_value_<?php echo $val->id;?>" href="javascript:void();"><?php echo $finish_colour_name?></a>
                                        <div class="div_hide div_finish_name">
                                            <input class="check_click" type="text" name="finish_colour_name_<?php echo $val->id;?>" value="<?php echo $finish_colour_name;?>"/>
                                            <a href="javascript:void();" data-id="finish_colour_name_<?php echo $val->id;?>" entity_table="finishgroupcolor" entity_id="<?php echo $val->id;?>" class="btn btn-primary update_btn_value check_click">Update</a>
                                        </div>
                                    </td>
                                    <td><?php echo $val->colour_code; ?></td>
                                    <td>
                                        <?php
                                        $path = base_path('public/upload/images/finish/'.$val->colour_image);
                                        $isExists = file_exists($path);
                                         if($isExists) { ?>
                                            <img style= "height:80px;" src="<?php echo "/upload/images/finish/".$val->colour_image; ?>"/>
                                        <?php } ?>
                                    </td>
                                    <td><input type="file" id="colour_value_custom_image" name="colour_value_custom_image[<?php echo $val->id;?>]" value="<?php echo $val->custom_image; ?>"/></td>

                                    <td><textarea class="description" name="description[<?php echo $val->id;?>]"><?php echo $val->description; ?></textarea></td>

                                    <td>
                                        <div class="custom-select">
                                            <select name="cylindo_type[<?php echo $val->id;?>]" id="cylindo_type">
                                                <option value="">CHOOSE CYLINDO TYPE</option>
                                                <?php foreach ($cylindoType as $value) { ?>
                                                <option <?= $val->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <textarea class="cylindo_data" name="cylindo_data[<?php echo $val->id;?>]"><?php echo $val->cylindo_data; ?></textarea>
                                        <div class="custom-select">
                                            <select name="cylindo_type_optional[<?php echo $val->id;?>]" id="cylindo_type_optional">
                                                <option value="">CHOOSE CYLINDO TYPE</option>
                                                <?php foreach ($cylindoType as $value) { ?>
                                                <option <?= $val->cylindo_type_optional == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <textarea class="cylindo_data_optional" name="cylindo_data_optional[<?php echo $val->id;?>]"><?php echo $val->cylindo_data_optional; ?></textarea>
                                    </td>
                                    <td <?php if ($val->is_active == 1) echo 'style="color: green;"'; else echo 'style="color: orange;"'; ?>><a data-id="<?php echo $val->id;?>" href="javascript:void();" data-swatch="child" class="btn btn-primary updateActive"><?php echo $status[$val->is_active]; ?></a></td>
                                    <td class="finish-group-color-custom-image-<?php echo $val->id;?> StyleCustomImage" id="custom-image-<?php echo $val->id;?>">
                                        <?php if($val->custom_image):?>
                                            <p><img style= "height:80px;" src="/upload/images/finish/<?php echo $val->custom_image == "" ? "noimage.jpg" :  $val->custom_image ?>"/></p>
                                            <a class="btn btn-danger deleteCustomImage" data-type="finishgroupcolor" data-id="<?php echo $val->id;?>" href="javascript:void();">X</a>
                                        <?php endif;?>
                                    </td>
                                </tr>
                            <?php } ?>
                            <tr>
                                <td colspan="5"><button type="submit" class="btn btn-primary btn-update">Update</button></td>
                            <tr>
                        </table>
                    </td>
                </tr>
            </form>
            <?php } ?>
            <?php echo $finish->links(); ?>
            </tbody>
        </table>

        <div class="modal fade" id="popup-update" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Update Name</h3>
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>
                <div class="modal-body">
                    <input class="content-update-finish" type="text">
                    <p class="err-mess"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        Cancel
                    </button>
                    <button type="button" class="btn-save btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>


        <div id="myModalCylindoData" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Cylindo Data</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <textarea id="cylindoData-finish"></textarea>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-cylindoData-finish btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>

        <div id="myModalCylindoType" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h3 class="modal-title">Update Cylindo Type</h3>
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                </div>
                <div class="modal-body">
                    <select name="cylindoType-finish" id="cylindoType-finish">
                        <option value="">CHOOSE CYLINDO TYPE</option>
                        <?php foreach ($cylindoType as $value) { ?>
                            <option <?= $val->cylindo_type == $value ? 'selected' : ''; ?> value="<?= $value ?>"><?= $value ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="update-cylindoType-finish btn btn-primary">Save</button>
                </div>
            </div>
            </div>
        </div>
        <div id="myModalActive" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title">Update Status</h3>
                        <button type="button" class="close" data-dismiss="modal">
                            &times;
                        </button>
                    </div>
                    <div class="modal-body">
                        <select name="active-finish" id="active-finish">
                            <option value="">CHOOSE STATUS</option>
                            <option value="1">TRUE</option>
                            <option value="0">FALSE</option>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            Cancel
                        </button>
                        <button type="button" class="update-active-finish btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script type="text/javascript">
jQuery(document).ready(function($) {
    $('form[action="/finish"]').each(function() {
        $(this).submit(function(event) {
            event.preventDefault();
            // console.log($(this).serialize());
            var formData = new FormData($(this)[0]);
            $.ajax(
                {
                    url: "/finish",
                    type: 'post',
                    dataType: 'json',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response){
                        response.template_image.forEach(array => {
                            document.getElementById("custom-image-"+array.name).innerHTML = '<p><img style="height:80px;" src="/upload/images/finish/'+array.image+'"/></p><a class="btn btn-danger deleteCustomImage" data-type="finishgroupcolor" data-id="'+array.name+'">X</a>';        
                        });
                        alert("You have successfully updated!");
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                        alert("You have successfully updated!");
                    }
            });
        })
    });
    $('.btn-save').click(function(){
        finish_name = $('.content-update-finish').val();
        if(finish_name == ''){
            alert('Please enter your content?');
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            finish_id = [];
            $.each($('.input-checkbox'), function(){
                if(this.checked == true){
                    if ($(this).attr('id') != 'select-all') finish_id.push($(this).val());
                }
            })

            $.ajax(
                {
                url: "/update-finish-name",
                type: 'post',
                dataType: 'json',
                data: {
                    "entity_id" : finish_id,
                    "entity_table": "finish",
                    "entity_field": "",
                    "entity_value": finish_name
                },
                success: function(response){
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();
                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        }
    });
    $('.btn-name').click(function(){
        $('#popup-update').modal('show');
    });

    $(".btn-cylindo-data").click(function(){
        $("#myModalCylindoData").modal('show');
    });

    $(".btn-cylindo-type").click(function(){
        $("#myModalCylindoType").modal('show');
    });

    $(".update-cylindoData-finish").click(function() {
        var cylindoData = $("#cylindoData-finish").val();
        if(cylindoData == '') {
            alert("Please enter your content?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var data = [];
            $.each($("input[type='checkbox']:checked"), function() {
                data.push($(this).val());
            });

            $.ajax(
                    {
                        url: "/update-finish-cylindodata",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "finish_id" : data,
                            "cylindoData": cylindoData,
                        },
                        success: function (response)
                        {
                            console.log(response);
                            alert("You have successfully updated!");
                            location.reload();

                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
        }
    });

    $(".update-cylindoType-finish").click(function() {
        var cylindoType = $("#cylindoType-finish").val();
        if(cylindoType == '') {
            alert("Please choose your option?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var type = [];
            $.each($("input[type='checkbox']:checked"), function() {
                type.push($(this).val());
            });

            $.ajax(
                    {
                        url: "/update-finish-cylindotype",
                        type: 'post',
                        dataType: "json",
                        data: {
                            "finish_id" : type,
                            "cylindoType": cylindoType,
                        },
                        success: function (response)
                        {
                            console.log(response);
                            alert("You have successfully updated!");
                            location.reload();

                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
        }
    });
    $(".btn-active").click(function(){
        $("#myModalActive").modal('show');
    });

    $(".update-active-finish").click(function() {
        var status = $("#active-finish").val();
        if(status == '') {
            alert("Please choose your option?");
            return false;
        }
        var result = confirm("Are you sure?");
        if (result) {
            var data = [];
            $.each($("input[type='checkbox']:checked"), function() {
                data.push($(this).val());
            });

            $.ajax(
            {
                url: "/update-active-finish",
                type: 'post',
                dataType: "json",
                data: {
                    "finish_id" : data,
                    "status": status,
                },
                success: function (response)
                {
                    console.log(response);
                    alert("You have successfully updated!");
                    location.reload();

                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        }
    });
  $(".update_value").click(function(e){
    e.preventDefault();
    $(".div_hide.active").removeClass("active");
    $(".update_value").show();
    if($(this).parent().find(".div_hide.active").length < 1)
    {
        $(this).hide();
        $(this).parent().find(".div_hide").addClass("active");
    }
    else
    {
        $(this).parent().find(".div_hide").removeClass("active");
    }
  });
  $(".update_btn_value").click(function(e){
    e.preventDefault();
    var result = confirm("Are you sure?");
    if(result)
    {
        var input_name = $(this).attr("data-id");
        var entity_id = $(this).attr("entity_id");
        var entity_table = $(this).attr("entity_table");
        var entity_value = $("input[name="+input_name+"]").val();
        $.ajax(
        {
            url: "/update-option-entity-value",
            type: 'post',
            dataType: "json",
            data: {
                "entity_id" : entity_id,
                "entity_table": entity_table,
                "entity_field": "",
                "entity_value"     : entity_value
            },
            success: function (response)
            {
                console.log(response);
                $("#"+entity_table+"_value_"+entity_id).html(entity_value);
                $(".div_hide.active").removeClass("active");
                $(".update_value").show();
            },
            error: function(xhr) {
             console.log(xhr.responseText);
           }
        });
    }
  });
  $('body').click(function(e){
    if(!$(e.target).hasClass('check_click')) {
       $(".div_hide.active").removeClass("active");
       $(".update_value").show();
    }
  });

  $(".updateActive").click(function(e){
        e.preventDefault();
        var result = confirm("Are you sure?");
        if(result)
        {
            var id = $(this).data("id");
            var button = $(this);
            var get_swatch = $(this).data("swatch");
            var option = "finish";
            if(get_swatch == "child")
            {
                option = "finish_group_color";
            }
            $.ajax(
            {
                url: "/update-active",
                type: 'post',
                dataType: "json",
                data: {
                    "id": id,
                    "option": option
                },
                success: function (response)
                {
                    if (response.value == true){
                        button.text('True');
                    }else button.text('False');
                       
                    // $(this).html(response.value);
                },
                error: function(xhr) {
                 console.log(xhr.responseText);
               }
            });
        }
   });
});
</script>
@stop