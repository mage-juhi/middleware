<?php

namespace App\Services\Base\Indexer;

use App\Console\ConsoleCommand;
use App\DB\Logger;
use Monolog\Handler\StreamHandler;

use App\Shopify\Product;

class ProductIndex
{
    static public function generate()
    {
        $logger = new Logger('App_Services_ProductIndex_generate');
        $loggerFilename = storage_path(
            'logs/App_Services_ProductIndex_generate.log'
        );
        $logger->pushHandler(new StreamHandler($loggerFilename), Logger::INFO);

        $isCli = app()->runningInConsole();
        $cli = new ConsoleCommand;

        $storeId = store()->id;

        if ($isCli) {
            $cli->line('');
            $cli->info("Commencing Shopify Product Index Process for Store ID {$storeId}");
        }

        // Fetch all products from Shopify
        $shopifyProducts = shopify()->getAllProducts();

        if (is_object($shopifyProducts) && $shopifyProducts->errors) {
            if ($isCli) {
                $cli->line('');
                $cli->error("Processing of product index halted");
                $cli->error("Please review the error log: {$loggerFilename}");
                $cli->line('');
            }

            $errorObj = [
                'shopify_response' => $shopifyProducts,
                'message' => 'There was an issue while retrieving all products from Shopify'
            ];
            $logger->error('Processing of product index halted', $errorObj);

            return;
        }

        if ($isCli) {
            $cli->line('');
            $cli->info("Indexing " . count($shopifyProducts) . " Shopify Products");
            $bar = $cli->getOutput()->createProgressBar(count($shopifyProducts));
            $bar->setFormat('debug');
            $bar->start();
        }

        foreach ($shopifyProducts as $shopifyProduct) {
            $prodObj = new Product();
            $prodObj->loadFromShopifyProduct($shopifyProduct);

            if ($isCli) {
                $bar->advance();
            }
        }

        // Reindex Shopify Products Array
        $newShopifyProducts = [];
        foreach ($shopifyProducts as $shopifyProduct) {
            $newShopifyProducts[$shopifyProduct['id']] = $shopifyProduct;
        }
        $shopifyProducts = $newShopifyProducts;

        $indexedIds = \DB::table('shopify_products')->where('store_id', $storeId)->pluck('id');

        // Delete products missing in Shopify
        $productsToDelete = [];
        foreach ($indexedIds as $id) {
            if (!isset($shopifyProducts[$id])) {
                $productsToDelete[] = $id;
            }
        }
        if (!empty($productsToDelete)) {
            \DB::table('shopify_products')->whereIn('id', $productsToDelete)->delete();
        }

        if ($isCli) {
            $bar->finish();
            $cli->line('');
        }

        if ($isCli) {
            $cli->line('');
            $cli->info("Shopify Product Index Process for Store ID {$storeId} Complete");
            $cli->line('');
        }
    }

    static public function indexSingleProduct(array $product)
    {
        $logger = new Logger('App_Services_ProductIndex_generate');
        $loggerFilename = storage_path(
            'logs/App_Services_ProductIndex_generate.log'
        );
        $logger->pushHandler(new StreamHandler($loggerFilename), Logger::INFO);

        $shopifyProduct = new Product();
        $shopifyProduct->loadFromShopifyProduct($product);
    }

    static public function indexSingleProductDelete(array $product)
    {
        $logger = new Logger('App_Services_ProductIndex_generate');
        $loggerFilename = storage_path(
            'logs/App_Services_ProductIndex_generate.log'
        );
        $logger->pushHandler(new StreamHandler($loggerFilename), Logger::INFO);

        if (isset($product['id']) && !empty($product['id'])) {
            $shopifyProduct = Product::find($product['id']);
            if ($shopifyProduct) {
                $shopifyProduct->delete();
            }
        }
    }
}