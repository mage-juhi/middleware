<?php

namespace App\Shopify\Product;

use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
    protected $table = 'shopify_product_tags';
    protected $primaryKey = 'id';

    protected $fillable = [
        'id',
        'product_id',
        'value'
    ];
//    protected $guarded = [];

    public $timestamps = false;

    public function product()
    {
        return $this->belongsTo('App\Shopify\Product', 'product_id');
    }
}
