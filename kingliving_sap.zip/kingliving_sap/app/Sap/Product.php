<?php

namespace App\Sap;
use App\Sap\ProductEntityValue;
use App\Sap\Product\Exterior;
use App\Sap\Product\Finish;
use App\DB\Stores;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    const AVAILABLE = 0; // product status = 0, the SAP data is AVAILABLE
    const SYNCED = 1; // product status = 1, the SAP data is AVAILABLE and SYNCED to middleware
    const UNAVAILABLE = 2; // product status = 2, the SAP data is UNAVAILABLE
    const DISABLED = 3; // product status = 3, the SAP data is UNAVAILABLE and DISABLED on Magento

    protected $table = 'package_products';
    protected $primaryKey = 'id';

    protected $fillable = [
        'store_id',
        'sku',
        'item_type',
        'part_code',
        'name',
        'product_image',
        'item_group_name',
        'sub_range_code',
        'sub_range_name',
        'country_of_manufacture',
        'has_material',
        'magento_sync_status',
        'status',
    ];

    protected $attributes = [
        'status' => 0,
        'has_material' => 0,
        'magento_sync_status' => 0,
    ];

    /**
     * Allows the retrieval of MaterialLinks from the Product Object
     *
     * @return mixed
     */
    public function materialLinks()
    {
        return $this->hasMany('App\Sap\Product\MaterialLink', 'product_id');
    }

    public function exteriorLinks()
    {
        return $this->hasMany('App\Sap\Product\ExteriorLink', 'product_id');
    }

    public function finishLinks()
    {
        return $this->hasMany('App\Sap\Product\FinishLink', 'product_id');
    }



    /**
     * Allows the retrieval of ExtraOptions from the Product Object
     *
     * @return mixed
     */
    public function extraOptions()
    {
        return $this->hasMany('App\Sap\Product\ExtraOption', 'product_id');
    }

    /**
     * Allows the retrieval of Cushioning from the Product Object
     *
     * @return mixed
     */
    public function cushioning()
    {
        return $this->hasMany('App\Sap\Product\Cushioning', 'product_id');
    }

    /**
     * Allows the retrieval of Legs from the Product Object
     *
     * @return mixed
     */
    public function legs()
    {
        return $this->hasMany('App\Sap\Product\Legs', 'product_id');
    }

    /**
     * Allows the retrieval of Exterior from the Product Object
     *
     * @return mixed
     */
    public function exterior()
    {
        return $this->hasMany('App\Sap\Product\Exterior', 'product_id');
    }

    /**
     * Allows the retrieval of Finish from the Product Object
     *
     * @return mixed
     */
    public function finish()
    {
        return $this->hasMany('App\Sap\Product\Finish', 'product_id');
    }

    public function optionalUpgrades()
    {
        return $this->hasMany('App\Sap\OptionalUpgrades', 'product_id')->where('active',1);
    }

    public function delete()
    {
        // delete all related
        $this->deleteRelate($this->finishLinks);
        $this->deleteRelate($this->exteriorLinks);
        $this->deleteRelate($this->legs);
        $this->deleteRelate($this->cushioning);
        $this->deleteRelate($this->extraOptions);
        $this->deleteRelate($this->materialLinks);

        // delete the user
        return parent::delete();
    }

    public function deleteRelate($data)
    {
        if (count($data) > 0)
            foreach ($data as $option) {
                $option->delete();
            }
    }

    public function indexPackageProduct($product)
    {
        $fillArray = array();
        $store_id = $product['item']['store_id'];
        $fillArray['store_id'] = $product['item']['store_id'];
        $fillArray['sku'] = $product['item']['sku'];
        $fillArray['item_type'] = $product['item']['type'];
        $fillArray['part_code'] = $product['item']['part_code'];
        $fillArray['name'] = $product['item']['name'];
        $fillArray['item_group_name'] = $product['item']['item_group_name'];
        $fillArray['sub_range_code'] = $product['item']['sub_range_code'];
        $fillArray['status'] = self::SYNCED;
        $fillArray['has_material'] = $product['item']['is_covered'];
        // if (isset($product['material']['range']))
        //     $fillArray['has_material'] = 1;
        // else
        //     $fillArray['has_material'] = 0;

        $newProd = self::where('store_id', $fillArray['store_id'])->where('sku', $product['item']['sku'])->first();

        if ($newProd) {
            $newProd->fill($fillArray);
            $newProd->save();
            // Product Exists, Update Data
            /* backup jamie's code
            if (isset($product['extra_options'])){
                $extraOptions = $product['extra_options'];
                if (!empty($extraOptions)) {
                    foreach ($extraOptions as $k => $extraOption) {
                        $type = $extraOption['type'];
                        $is_required = $extraOption['is_required'];
                        if (!empty($extraOption['options'])) {
                            foreach ($newProd->extraOptions as $middleOption) {
                                $didOptionExist = false;
                                foreach ($extraOption['options'] as $k => $option) {
                                    if ($middleOption->sku == $option['sku']) {
                                        $didOptionExist = true;
                                        $optionFill = array();
                                        $optionFill['type'] = $type;
                                        $optionFill['sku'] = $option['sku'];
                                        $optionFill['name'] = $option['name'];
                                        $optionFill['quantity'] = $option['quantity'];
                                        $optionFill['sell_price'] = $option['sell_price'];
                                        $optionFill['is_required'] = $is_required;
                                        $middleOption->fill($optionFill);
                                        $middleOption->save();
                                    }
                                }
                                if (!$didOptionExist) {
                                    $middleOption->delete();
                                }
                            }
                            $Skus = array();
                            foreach ($newProd->extraOptions as $middleOption) {
                                $Skus[] = $middleOption->sku;
                            }

                            $optionArray = array();
                            foreach ($extraOption['options'] as $k => $option) {
                                    $didOptionExist = false;
                                    if (in_array($option['sku'], $Skus)) {
                                        $didOptionExist = true;
                                    } else {
                                        $optionFill = array();
                                        $optionFill['type'] = $type;
                                        $optionFill['sku'] = $option['sku'];
                                        $optionFill['name'] = $option['name'];
                                        $optionFill['quantity'] = $option['quantity'];
                                        $optionFill['sell_price'] = $option['sell_price'];
                                        $optionFill['is_required'] = $is_required;
                                    }
                                    if (!$didOptionExist) {
                                        $optionArray[] = $optionFill;
                                    }
                                }

                            if(!empty($optionArray)) {
                                $newProd->extraOptions()->createMany($optionArray);
                            }

                        }


                    }

                }   // Update the Extra options if exists
            }

            */

            // update the Cushion options if exist
            /* comment out this logic to use lumen base function updateOrCreate
            $cushioningData = $product['cushioning'];
            if (!empty($cushioningData)){
                // update exist and remove unused cushioning
                foreach ($newProd->cushioning as $middleCushioning){
                    $didExist = false;
                    foreach ($cushioningData as $k => $cushioning) {
                        if ($middleCushioning->cushioning_code == $cushioning['code']){
                            // update exist
                            $didExist = true;
                            $cushioningArray = array(
                                'cushioning_code' => $cushioning['code'],
                                'cushioning_name' => $cushioning['name'],
                            );
                            $middleCushioning->fill($cushioningArray);
                            $middleCushioning->save();
                        }
                    }
                    if (!$didExist) {
                        // remove unused cushioning
                        $middleCushioning->delete();
                    }
                }

                // add new cushioning
                $codes = array();
                foreach ($newProd->cushioning as $middleCushioning) {
                    $codes[] = $middleCushioning->cushioning_code;
                }

                $cushioningArray = array();
                foreach ($cushioningData as $k => $cushioning) {
                    if (!in_array($cushioning['code'], $codes)){
                        $cushioningArray[] = array(
                            'cushioning_code' => $cushioning['code'],
                            'cushioning_name' => $cushioning['name'],
                        );
                    }
                }
                if(!empty($optionArray)) {
                    $newProd->cushioning()->createMany($cushioningArray);
                }
            }
            */
            $codes = array();
            if (isset($product['extra_options'])){
                $extraOptionsData = $product['extra_options'];
                if (!empty($extraOptionsData)){
                    foreach ($extraOptionsData as $extraOption) {
                        if (!empty($extraOption['options'])) {
//                            $extraOptionRequired = $extraOption['is_required'] ? 1 : 0;
                            foreach ($extraOption['options'] as $option) {
                                $optionFill = array();
                                $optionFill['type'] = $extraOption['type'];
                                $optionFill['name'] = $option['name'];
//                                $optionFill['is_required'] = $extraOptionRequired;
                                $optionFill['package_sku'] = $newProd->sku;
                                $optionValueFill = array();
                                $optionValueFill['quantity'] = $option['quantity'];
                                $optionValueFill['store_id'] = $product['item']['store_id'];
                                $optionValueFill['sell_price'] = $option['sell_price'];
                                $optionValueFill['rrp_price'] = isset($option['full_price']) ? $option['full_price'] : 0;
//                                $optionValueFill['is_required'] = $extraOptionRequired;
                                $extraOption = $newProd->extraOptions()->updateOrCreate(['sku' => $option['sku'],'type' => $extraOption['type']], $optionFill);
                                $extraOption->extraOptionValue()->updateOrCreate(['store_id' => $optionValueFill['store_id']], $optionValueFill);
                                $codes[] = $option['sku'];
                            }
                        }
                    }
                }
            }
            // delete unused
            // foreach ($newProd->extraOptions as $middleOption) {
            //     if (!in_array($middleOption->sku, $codes)){
            //         $middleOption->delete();
            //     }
            // }

            // update to inactive for unused extra option
            foreach ($newProd->extraOptions as $middleOption) {
                if (!in_array($middleOption->sku, $codes)){
                    $middleOption->is_active = 0;
                    $middleOption->save();
                }
            }

            $codes = array();
            if (isset($product['cushioning'])){
                $cushioningData = $product['cushioning'];
                if (!empty($cushioningData)){
                    foreach ($cushioningData as $cushioning) {
                        $newProd->cushioning()->updateOrCreate(['cushioning_code' => $cushioning['code']], ['cushioning_name' => $cushioning['name']]);
                        $codes[] = $cushioning['code'];
                    }
                }
            }
            // delete unused
            foreach ($newProd->cushioning as $middleCushioning) {
                if (!in_array($middleCushioning->cushioning_code, $codes)){
                    $middleCushioning->delete();
                }
            }

            $codes = array();
            if (isset($product['legs'])){
                $legsData = $product['legs'];
                if (!empty($legsData)){
                    foreach ($legsData as $legs) {
                        $legsArray = array(
                            'legs_name' => ($legs['name']) ? $legs['name'] : " ",
                            'quantity' => $legs['quantity'],
                            'is_default' => $legs['is_default'],
                            'is_included' => $legs['is_included'],
                            'unit_price' => isset($legs['unit_price']) ? $legs['unit_price'] : 0,
                            'total_price' => isset($legs['total_price']) ? $legs['total_price'] : 0,
                        );
                        $newProd->legs()->updateOrCreate(['legs_code' => $legs['code']], $legsArray);
                        $codes[] = $legs['code'];
                    }
                }
            }
            // delete unused
            foreach ($newProd->legs as $middleLegs) {
                if (!in_array($middleLegs->legs_code, $codes)){
                    $middleLegs->delete();
                }
            }

            $codes = array();
            if (isset($product['exterior'])){
                $exteriorData = $product['exterior'];
                if (!empty($exteriorData)){
                    foreach ($exteriorData as $exterior) {
                        if ($exterior['name'] == null)
                            continue;
                        Exterior::updateOrCreate(['exterior_code' => $exterior['code']], ['exterior_name' => $exterior['name']]);
                        $codes[] = $exterior['code'];
                    }
                }
            }
            // delete unused
            // foreach ($newProd->exterior as $middleExterior) {
            //     if (!in_array($middleExterior->exterior_code, $codes)){
            //         $middleExterior->exteriorColor()->delete();
            //         $middleExterior->delete();
            //     }
            // }

            $codes = array();
            if (isset($product['finish'])){
                $finishData = $product['finish'];
                if (!empty($finishData)){
                    foreach ($finishData as $finish) {
                        if ($finish['name']){
                            Finish::updateOrCreate(['finish_code' => $finish['code']], ['finish_name' => $finish['name']]);
                            $codes[] = $finish['code'];
                        }
                    }
                }
            }
            // delete unused
            // foreach ($newProd->finish as $middleFinish) {
            //     if (!in_array($middleFinish->finish_code, $codes)){
            //         $middleFinish->finishColor()->delete();
            //         $middleFinish->delete();
            //     }
            // }
        } else {
            // New Product
            $fillArray['status'] = self::SYNCED;;
            $newProd = new self($fillArray);
            $newProd->save();

            // create Extra option
            if (isset($product['extra_options'])){
                $extraOptions = $product['extra_options'];
                if (!empty($extraOptions)) {
                    $optionArray = array();
                    foreach ($extraOptions as $extraOption) {
                        $type = $extraOption['type'];
//                        $is_required = $extraOption['is_required'];
                        foreach ($extraOption['options'] as $option) {
                            $optionFill = array();
                            $optionFill['type'] = $type;
                            $optionFill['sku'] = $option['sku'];
                            $optionFill['name'] = $option['name'];
                            $optionFill['package_sku'] = $newProd->sku;
//                            $optionFill['is_required'] = $is_required;
                            $optionValueFill = array();
                            $optionValueFill['quantity'] = $option['quantity'];
                            $optionValueFill['sell_price'] = $option['sell_price'];
                            $optionValueFill['rrp_price'] = $option['full_price'];
                            $optionValueFill['store_id'] = $product['item']['store_id'];
//                            $optionValueFill['is_required'] = $is_required ? 1 : 0;
                            $optionArray[] = $optionFill;
                            $extraOption = $newProd->extraOptions()->updateOrCreate(['sku' => $option['sku'],'type' => $type], $optionFill);
                            $extraOption->extraOptionValue()->updateOrCreate(['store_id' => $optionValueFill['store_id']], $optionValueFill);
                        }
                    }
                    // $newProd->extraOptions()->createMany($optionArray);

                }
            }

            //Create many Cushion
            if (isset($product['cushioning'])){
                $cushioningData = $product['cushioning'];
                if (!empty($cushioningData)){
                    $cushioningArray = array();
                    foreach ($cushioningData as $cushioning) {
                        $cushioningArray[] = array(
                            'cushioning_code' => $cushioning['code'],
                            'cushioning_name' => $cushioning['name'],
                        );
                    }
                    $newProd->cushioning()->createMany($cushioningArray);
                }
            }

            //Create many Legs
            if (isset($product['legs'])){
                $legsData = $product['legs'];
                if (!empty($legsData)){
                    $legsArray = array();
                    foreach ($legsData as $legs) {
                        $legsArray[] = array(
                            'legs_code' => $legs['code'],
                            'legs_name' => ($legs['name']) ? $legs['name'] : " ",
                            'quantity' => $legs['quantity'],
                            'is_default' => $legs['is_default'],
                            'is_included' => $legs['is_included'],
                            'unit_price' => isset($legs['unit_price']) ? $legs['unit_price'] : 0,
                            'total_price' => isset($legs['total_price']) ? $legs['total_price'] : 0,
                        );
                    }
                    $newProd->legs()->createMany($legsArray);
                }
            }

            //Create many Exterior
            if (isset($product['exterior'])){
                $exteriorData = $product['exterior'];
                if (!empty($exteriorData)){
                    foreach ($exteriorData as $exterior) {
                        if ($exterior['name']){
                            Exterior::updateOrCreate(['exterior_code' => $exterior['code']], ['exterior_name' => $exterior['name']]);
                        }
                    }
                    
                    // $newProd->exterior()->createMany($exteriorArray);
                }
            }

            //Create many Finish
            if (isset($product['finish'])){
                $finishData = $product['finish'];
                if (!empty($finishData)){
                    foreach ($finishData as $finish) {
                        if ($finish['name']){
                            Finish::updateOrCreate(['finish_code' => $finish['code']], ['finish_name' => $finish['name']]);
                        }
                    }
                    // $newProd->finish()->createMany($finishArray);
                }
            }
        }

        // set price
        if ($newProd->has_material == 0){
            // sell price
            if (isset($product['material']['']['sell_price'])) {
                $sell_price = ProductEntityValue::where('store_id',$store_id)->where('attribute_id', 3)->where('product_id', $newProd->id)->first();
                if ($sell_price){
                    $sell_price->value = $product['material']['']['sell_price'];
                    $sell_price->save();
                }else{
                    $sell_price = new ProductEntityValue();
                    $sell_price->attribute_id = 3;
                    $sell_price->store_id = $store_id;
                    $sell_price->product_id = $newProd->id;
                    $sell_price->value = $product['material']['']['sell_price'];
                    $sell_price->save();
                }
            }

            // rrr price
            if (isset($product['material']['']['rrp_price'])) {
                $rrp_price = ProductEntityValue::where('store_id',$store_id)->where('attribute_id', 4)->where('product_id', $newProd->id)->first();
                if ($rrp_price){
                    $rrp_price->value = $product['material']['']['rrp_price'];
                    $rrp_price->save();
                }else{
                    $rrp_price = new ProductEntityValue();
                    $rrp_price->attribute_id = 4;
                    $rrp_price->store_id = $store_id;
                    $rrp_price->product_id = $newProd->id;
                    $rrp_price->value = $product['material']['']['rrp_price'];
                    $rrp_price->save();
                }
            }

            // set sale type to EAV data
            $sale_type = ProductEntityValue::where('store_id',$store_id)->where('attribute_id', 8)->where('product_id', $newProd->id)->first();
            if (isset($product['material']['']['sale_type']) && isset($product['material']['']['code'])) {
                $code = $product['material']['']['code'];
                if ($code == 'F GL 2') {
                    if ($sale_type) {
                        $canSave = true;
                        //$caStoreId = Stores::where('magento_store_code', 'ca')->first();
                        // if (isset($caStoreId->id) && $sale_type->value == 'Ongoing' && $store_id == $caStoreId->id)
                        //    $canSave = false;

                        if ($canSave) {
                            $sale_type->value = $product['material']['']['sale_type'];
                            $sale_type->save();
                        }
                    } else {
                        $sale_type = new ProductEntityValue();
                        $sale_type->attribute_id = 8;
                        $sale_type->store_id = $store_id;
                        $sale_type->product_id = $newProd->id;
                        $sale_type->value = $product['material']['']['sale_type'];
                        $sale_type->save();
                    }
                }
            }

            // Ongoing case reset rrp_price to sell price for no material type with 
            /*if ($sale_type->value == 'Ongoing'){
                $rrp_price->value = $sell_price->value;
                $rrp_price->save();
            }*/
        }
    }
}