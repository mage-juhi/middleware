<?php

namespace App\Sap;

use Illuminate\Database\Eloquent\Model;

class ProductEntityValue extends Model {
	protected $table = 'product_entity_value';
    protected $primaryKey = 'id';

	protected $fillable = [
        'id',
        'attribute_id',
        'store_id',
        'product_id',
        'value',
    ];
}