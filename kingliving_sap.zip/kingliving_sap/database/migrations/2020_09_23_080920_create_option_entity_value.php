<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOptionEntityValue extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('option_entity_value', function (Blueprint $table) {
            $table->increments('id');
            $table->string('entity_table');
            $table->integer('entity_id')->unsigned();
            $table->string('entity_field');
            $table->text('value');
            $table->timestamps();
            $table->unique(['entity_table','entity_id','entity_field'],'unique_option_entity_value');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('option_entity_value');
    }
}
