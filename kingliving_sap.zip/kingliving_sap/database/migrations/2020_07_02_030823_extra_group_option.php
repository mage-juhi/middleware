<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ExtraGroupOption extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('extra_group_option', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('store_id')->unsigned();
            $table->integer('product_id')->unsigned();
            $table->integer('value_id')->unsigned();
            $table->string('sku');
            $table->double('sell_price',10,2);
            $table->unique(['store_id', 'product_id','value_id']);
        });

        Schema::table('extra_group_option', function (Blueprint $table) {
            $table->foreign('product_id')->references('id')->on('package_products');
            $table->foreign('store_id')->references('id')->on('stores');
            $table->foreign('value_id')->references('id')->on('extra_group_option_value');
        });

        Schema::table('extra_group_option_value', function (Blueprint $table) {
            // $table->dropForeign('product_id');
            $table->dropColumn('sku');
            $table->dropColumn('product_id');
            $table->dropColumn('sell_price');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('extra_group_option');
    }
}
