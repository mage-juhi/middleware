<?php

namespace App\Console\Commands;

use App\Console\AbstractCommand;

use Illuminate\Console\Command;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;

class BackupDB extends AbstractCommand
{
    const PROGRESS_BAR_FORMAT = 'debug';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:backupsapdb
                              ';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Function backup database';

    protected $process;

    public function __construct()
    {
        parent::__construct();

        $db_backup_name = 'backups/backup'.env('APP_ENV').date("Y-m-d").'.sql';
        $table_name = env('DB_DATABASE');
        $this->process = new Process(sprintf(
            'mysqldump -u%s -p%s %s --ignore-table='.$table_name.'.failed_jobs --ignore-table='.$table_name.'.jobs --ignore-table='.$table_name.'.cache > %s',
            env('DB_USERNAME'),
            env('DB_PASSWORD'),
            env('DB_DATABASE'),
            storage_path($db_backup_name)
        ));
    }

    /**
     * Execute the console command.
     *
     * @param  \App\DripEmailer $drip
     * @return mixed
     */
    public function handle()
    {
        parent::handle();

        try {
            $this->process->mustRun();

            $this->info('The backup has been proceed successfully.');
        } catch (ProcessFailedException $exception) {
            $this->error('The backup process has been failed.' . $exception->getMessage());
        }
        return;
    }
}