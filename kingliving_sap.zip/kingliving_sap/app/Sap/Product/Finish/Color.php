<?php

namespace App\Sap\Product\Finish;

use Illuminate\Database\Eloquent\Model;

class Color extends Model
{
    protected $table = 'finish_group_color';
    protected $primaryKey = 'id';

    protected $fillable = [
        'finish_id',
        'colour_name',
        'colour_code',
        'colour_image'
    ];
    public function finish()
    {
        return $this->belongsTo('App\Sap\Product\Finish', 'finish_id');
    }
    public function getColourValue($id)
    {
        return self::where('finish_id', '=', $id)->get();
    }


}